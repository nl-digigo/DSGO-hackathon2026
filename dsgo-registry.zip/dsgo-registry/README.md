# DSGO Autorisatieservice

Proof of Concept-implementatie van een autorisatievoorziening voor het Datastelsel Gebouwde Omgeving (DSGO), conform de **OpenID AuthZen 1.0 Draft 04** specificatie.

## Wat doet deze service?

Deze service biedt een centraal autorisatiepunt (PDP — Policy Decision Point) waar externe systemen (PEP's) runtime autorisatiebeslissingen kunnen opvragen:

- **Mag Bedrijf A data opvragen bij Bedrijf B?** → `POST /api/evaluation` → `{ "decision": true }`
- **Welke delegaties bestaan er?** → `POST /api/search` → delegatie-evidence
- **Gedeeltelijke toegang?** → `{ "decision": true, "context": { "resource": { ... } } }`

Het volgt het subject–resource–action model met uitbreidingen voor delegaties, gedeeltelijke autorisatie en DSGO-specifieke properties.

## Snel starten

### Lokaal (PHP)

```bash
cp .env.example .env
make setup
make serve
```

Open http://localhost:8000/admin/policies om policies te beheren.

### Docker

```bash
docker compose up -d
```

Open http://localhost:8080/admin/policies.

### Demo-scenario uitvoeren

```bash
make demo                              # Docker (poort 8080)
make demo BASE_URL=http://localhost:8000  # Lokaal (poort 8000)
```

Dit draait het volledige Bedrijf A/B/C-scenario: toestemming, weigering en PRP-opvraag.

## Architectuur

```
Client (extern systeem)
    │
    ├─ POST /token ────────────→ TokenController
    │                               ├─ JWT client_assertion validatie (x5c)
    │                               ├─ ParticipantRegistryService (Digigo)
    │                               └─ Uitgifte Bearer access_token
    │
    ├─ POST /api/evaluation ──→ IshareJWTAuthenticator (Bearer token check)
    │                            └─ EvaluationProcessor
    │                                 ├─ CallerIdentityExtractor
    │                                 ├─ ParticipantRegistry
    │                                 └─ EvaluationService
    │                                      ├─ RequestMapper
    │                                      ├─ CasbinAuthorizer (sub/obj/act)
    │                                      ├─ PropertyMatcher (v3–v5 + partial_context)
    │                                      ├─ DelegationService
    │                                      └─ ResponseBuilder
    │
    └─ POST /api/search ─────→ IshareJWTAuthenticator (Bearer token check)
                                 └─ PolicySearchProcessor
                                      └─ DelegationService (PRP)
```

### Hoe werkt een autorisatieverzoek?

1. **API-laag** (Processor): extraheert caller identity, valideert API key, controleert participantenregister
2. **RequestMapper**: vertaalt AuthZen-verzoek naar Casbin-argumenten (sub/obj/act) + uitgebreide properties
3. **CasbinAuthorizer**: evalueert sub/obj/act-matching via Casbin met `keyMatch2` voor resourcepaden
4. **PropertyMatcher**: matcht uitgebreide properties (service_provider, method, license) tegen de v3–v5-velden van matching policies
5. **DelegationService**: valideert delegatieketen (max. diepte 5), slaat evidence op
6. **ResponseBuilder**: bouwt het antwoord op met decision + context (weigeringsredenen, gedeeltelijke autorisatie)

## Authenticatie

Alle `/api/*` endpoints (behalve `/api/health`) zijn beveiligd met **iSHARE OAuth2 Bearer tokens**. De authenticatieflow werkt als volgt:

1. **Client Assertion**: de aanroepende partij maakt een ondertekende JWT (RFC 7523) met hun private key en x5c-certificaatketen.
2. **Token ophalen**: `POST /token` met de client assertion. De server valideert de handtekening, controleert het certificaat en checkt het participantenregister (Digigo).
3. **API aanroepen**: gebruik het verkregen `access_token` als Bearer token in de `Authorization`-header.

```bash
# Stap 1: Token ophalen
TOKEN=$(curl -s -X POST http://localhost:8080/token \
  -d "grant_type=client_credentials" \
  -d "client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer" \
  -d "client_assertion=<signed-jwt>" \
  -d "client_id=<your-did>" \
  -d "scope=iSHARE" | jq -r '.access_token')

# Stap 2: API aanroepen met token
curl -s http://localhost:8080/api/evaluation \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ ... }'
```

De **Token Creator** (`/token/creator`) is een testpagina om tokens te genereren via een formulier.

## API-endpoints

| Methode | Endpoint | Beschrijving | Authenticatie |
|---------|----------|-------------|---------------|
| POST | `/token` | OAuth2 token-endpoint (iSHARE) | Geen (ontvangt tokens) |
| GET | `/token/creator` | Testpagina voor token-generatie | Geen |
| POST | `/api/evaluation` | Autorisatiebeslissing (AuthZen) | Bearer token vereist |
| POST | `/api/search` | Policy Retrieval Point (delegatie-evidence) | Bearer token vereist |
| GET | `/api/health` | Gezondheidscontrole | Publiek |
| GET | `/api/status` | Policy-status | Bearer token vereist |
| GET | `/api/docs` | Swagger UI (interactieve API-documentatie) | Bearer token vereist |

## Demo-scenario

Drie deelnemers:

| EORI | Rol | Naam |
|------|-----|------|
| `EU.EORI.NL000000001` | Juridisch datadienstgebruiker | Bedrijf A |
| `EU.EORI.NL000000002` | Datadienstaanbieder | Bedrijf B |
| `EU.EORI.NL000000003` | Gemachtigd datadienstgebruiker | Bedrijf C |

- **Bedrijf A** mag `/products` lezen bij **Bedrijf B** (volledige toestemming)
- **Bedrijf C** mag lezen via delegatie van A (licentie DSGO.0008)
- **Onbekend bedrijf** wordt geweigerd (weigering met redenen)

## Technische stack

| Component | Versie | Functie |
|-----------|--------|---------|
| Symfony | 7.4 | PHP-framework |
| API Platform | 4.x | REST API + Swagger UI |
| Casbin | 4.1 | Policy-engine (sub/obj/act) |
| lcobucci/jwt | 5.6 | JWT-token parsing, validatie en generatie |
| Doctrine ORM | — | Database (SQLite) |
| PHPUnit | 11 | Testen |
| Docker | — | Containerisatie |

## Documentatie

| Document | Beschrijving |
|----------|-------------|
| [API-referentie](docs/API.md) | Endpoints, verzoek/antwoord-voorbeelden, statuscodes |
| [Beleidsmodel](docs/POLICY_MODEL.md) | AuthZen-model, Casbin-ontwerpkeuzes, evaluatieflow |
| [Integratiegids](docs/INTEGRATION.md) | Hoe een PEP integreert met deze service |
| [AuthZen-mapping](docs/AUTHZEN.md) | OpenID AuthZen → DSGO-mapping en vergelijking met XACML |
| [Demo-walkthrough](docs/DEMO.md) | Stap-voor-stap demo met alle scenario's |

## Testen

```bash
make test            # Alle tests (unit + functioneel)
make test-unit       # Alleen unit tests
make test-functional # Alleen functionele tests
make lint            # Code-kwaliteitscontrole
```

## Projectstructuur

```
src/
├── ApiResource/        # API Platform-resources (Evaluation, PolicySearch, Health, Status)
├── Command/            # CLI-commando's (policy:import, policy:list, policy:reload)
├── Controller/         # TokenController (OAuth2), TokenCreatorController (test UI)
│   └── Admin/          # Admin GUI (PolicyController, DelegationController)
├── Dto/                # AuthZen DTO's (EvaluationRequest, Subject, Resource, Action, etc.)
├── Entity/             # Doctrine-entiteiten (PolicyRule, DelegationEvidence)
├── Evidence/           # Non-repudiation (CanonicalDecisionPayload, EvidenceRecorderInterface)
├── EventListener/      # Correlation ID-listener
├── Form/               # Symfony-formulieren (PolicyRuleType, DelegationEvidenceType)
├── Repository/         # Doctrine-repositories
├── Service/
│   ├── Casbin/         # Casbin-integratie (Authorizer, Adapter, EnforcerFactory)
│   ├── Delegation/     # Delegatieketen-validatie + PRP
│   ├── Evaluation/     # Kern-evaluatie (EvaluationService, RequestMapper, PropertyMatcher)
│   ├── Identity/       # Caller identity-extractie + API key-validatie
│   ├── Logging/        # Gestructureerde logging van autorisatiebeslissingen
│   └── Registry/       # Participantenregister-integratie
├── Security/           # IshareJWTAuthenticator (Bearer token validatie)
└── State/              # API Platform-processors (EvaluationProcessor, PolicySearchProcessor)
```
