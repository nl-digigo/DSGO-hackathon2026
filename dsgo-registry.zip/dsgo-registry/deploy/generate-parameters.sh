#!/bin/bash

echo "# This file is auto-generated the bitbucket piplines run, using the environment variables with APP_ prefix"

prefix="APP_"
params=$(printenv | grep "^${prefix}")

while read -r key_value_pair; do
    IFS='=' read -a param <<< "$key_value_pair"

    param_name=${param[0]#"${prefix}"}
    param_value=${param[1]}
    param_value=${param_value//|IS|/=}

    if [[ $param_name == *_unquoted ]]; then
        param_name=${param_name%_unquoted}
    else
        param_value=\'$param_value\'
    fi

    if [[ $param_name ]]; then
        echo "$param_name=$param_value"
    fi
done <<<"$params"

prefix="${APP_APP_LOCALE}_"
params=$(printenv | grep "^${prefix}")

while read -r key_value_pair; do
    IFS='=' read -a param <<< "$key_value_pair"

    param_name=${param[0]#"${prefix}"}
    param_value=${param[1]}
    param_value=${param_value//|IS|/=}

    if [[ $param_name == *_unquoted ]]; then
        param_name=${param_name%_unquoted}
    else
        param_value=\'$param_value\'
    fi

    if [[ $param_name ]]; then
        echo "$param_name=$param_value"
    fi
done <<<"$params"

echo "VERSION=$BITBUCKET_BUILD_NUMBER"
