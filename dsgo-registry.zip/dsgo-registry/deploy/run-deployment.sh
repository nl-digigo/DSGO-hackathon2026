#!/bin/bash
set -euo pipefail

export IFS=";"
apk add openssh-client git gettext pigz

export COMPOSER_ALLOW_SUPERUSER=1

if [ -z "${SHARED_DIR:-}" ]; then
  SHARED_DIR="$(echo "${DEPLOY_DIR}" | sed 's/_current$/_shared/')"
fi

# Keep SQLite outside release folders by default.
if [ -z "${APP_DATABASE_URL:-}" ]; then
  export APP_DATABASE_URL="sqlite:////${SHARED_DIR#/}/data.db"
fi

curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
composer install -o --no-dev --no-scripts
composer dump-autoload --no-dev --classmap-authoritative

tar --use-compress-program="pigz" -cf /tmp/new.tar.gz .

for host in $DEPLOY_HOST; do
  ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "mkdir -p $RELEASE_DIR $SHARED_DIR $SHARED_DIR/log"
  ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "if [ ! -f $SHARED_DIR/data.db ] && [ -f $DEPLOY_DIR/var/data.db ]; then cp $DEPLOY_DIR/var/data.db $SHARED_DIR/data.db; fi"
  ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "touch $SHARED_DIR/data.db"
  scp -o StrictHostKeyChecking=no /tmp/new.tar.gz $DEPLOY_USER@$host:/$RELEASE_DIR
done

rm /tmp/new.tar.gz

for host in $DEPLOY_HOST; do
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "mkdir -p $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER"
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "tar -I pigz -xf $RELEASE_DIR/new.tar.gz -C $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER/"
	/bin/bash ./deploy/generate-parameters.sh > .env
	scp -o StrictHostKeyChecking=no .env $DEPLOY_USER@$host:/$RELEASE_DIR/$BITBUCKET_BUILD_NUMBER

	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "mkdir -p $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER/var $SHARED_DIR/log"
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "rm -rf $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER/var/log && ln -sfn $SHARED_DIR/log $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER/var/log"
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "cd $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER && APP_ENV=prod APP_DEBUG=0 php -r \"if (!extension_loaded('pdo_sqlite')) {fwrite(STDERR, 'Missing PHP extension pdo_sqlite. Install php8.4-sqlite3 and restart php8.4-fpm.' . PHP_EOL); exit(1);} \""
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "cd $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER && APP_ENV=prod APP_DEBUG=0 php bin/console assets:install public && APP_ENV=prod APP_DEBUG=0 php bin/console doctrine:migrations:migrate --no-interaction --allow-no-migration && APP_ENV=prod APP_DEBUG=0 php bin/console cache:clear && APP_ENV=prod APP_DEBUG=0 php bin/console cache:warmup"
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "ln -sfn $RELEASE_DIR/$BITBUCKET_BUILD_NUMBER $DEPLOY_DIR"
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "cd $RELEASE_DIR; ls -t1 ./ | tail -n +4 | xargs -r sudo rm -rf"

	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "rm $RELEASE_DIR/new.tar.gz"
	ssh -o StrictHostKeyChecking=no $DEPLOY_USER@$host "sudo systemctl restart php8.4-fpm"
done
