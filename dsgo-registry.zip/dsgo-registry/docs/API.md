# API Referentie

## Overzicht

| Methode | Endpoint | Beschrijving | Authenticatie |
|---------|----------|-------------|---------------|
| POST | `/token` | OAuth2 token-endpoint (iSHARE) | Geen |
| GET | `/token/creator` | Testpagina voor token-generatie | Geen |
| POST | `/api/evaluation` | Autorisatiebeslissing (AuthZen) | Bearer token |
| POST | `/api/search` | Policy Retrieval Point (delegatie-evidence) | Bearer token |
| GET | `/api/health` | Gezondheidscontrole | Publiek |
| GET | `/api/status` | Policy-status | Bearer token |
| GET | `/api/docs` | Swagger UI (interactieve API-documentatie) | Bearer token |

Alle `/api/*` endpoints accepteren en retourneren `application/json`.

---

## Authenticatie

API-endpoints (behalve `/api/health`) vereisen een geldig Bearer token in de `Authorization`-header. Tokens worden verkregen via het `/token` endpoint.

### Stap 1: Token aanvragen

Maak een JWT client_assertion (RFC 7523) ondertekend met je private key, met een `x5c`-header die je certificaatketen bevat. Stuur deze naar `POST /token`:

```bash
curl -X POST http://localhost:8080/token \
  -d "grant_type=client_credentials" \
  -d "client_assertion_type=urn:ietf:params:oauth:client-assertion-type:jwt-bearer" \
  -d "client_assertion=<signed-jwt>" \
  -d "client_id=<your-did>" \
  -d "scope=iSHARE"
```

Succesvol antwoord:

```json
{
  "access_token": "eyJ...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "scope": "iSHARE"
}
```

De server valideert:
1. De JWT-handtekening tegen de publieke sleutel uit de x5c-certificaatketen
2. De `iss`, `sub`, `aud`, `exp`, `nbf`, `iat` claims
3. Of de organisatie-identifier uit het certificaat overeenkomt met het subject
4. Of de organisatie geregistreerd is in het participantenregister (Digigo)

### Stap 2: API aanroepen

Gebruik het access_token als Bearer token:

```bash
curl -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  http://localhost:8080/api/evaluation -d '{ ... }'
```

### Foutcodes authenticatie

| Code | Betekenis |
|------|-----------|
| 400 | Ongeldig verzoek (ontbrekende `grant_type` of `client_assertion`) |
| 401 | Ongeldige of verlopen client_assertion / Bearer token |

### Token Creator (testpagina)

De pagina `/token/creator` biedt een formulier om tokens te genereren voor testtoepassingen. Vul je client ID, private key en certificaatketen in en het formulier bouwt automatisch een client_assertion, wisselt deze in bij het token-endpoint, en roept een data-endpoint aan.

---

---

## POST /api/evaluation

Evalueert een autorisatieverzoek conform de OpenID AuthZen 1.0 Draft 04 specificatie. Dit is het primaire endpoint: een extern systeem (PEP) stuurt een verzoek en ontvangt een permit/deny beslissing.

### Verzoek

| Veld | Type | Verplicht | Beschrijving |
|------|------|-----------|-------------|
| `subject` | object | Ja | Wie vraagt toegang (EORI identifier) |
| `subject.type` | string | Ja | Type subject, bijv. `service-consumer` |
| `subject.id` | string | Ja | EORI identifier, bijv. `EU.EORI.NL000000001` |
| `subject.properties` | object | Nee | Optionele eigenschappen, o.a. delegatie-info |
| `resource` | object | Ja | Waartoe wordt toegang gevraagd |
| `resource.type` | string | Ja | Type resource, bijv. `api` |
| `resource.id` | string | Ja | Pad van de resource, bijv. `/products` |
| `resource.properties` | object | Nee | Optioneel: `service_provider` (EORI van de aanbieder) |
| `action` | object | Ja | Welke actie wordt uitgevoerd |
| `action.name` | string | Ja | Actienaam: `can_read`, `can_create`, `can_update`, `can_delete`, `can_access` |
| `action.properties` | object | Nee | Optioneel: `method` (HTTP methode), `license` (licentiecode) |
| `context` | object | Nee | Optionele omgevingsdata (bijv. tijdstip) |

### Voorbeeld: volledig verzoek

```json
{
  "subject": {
    "type": "service-consumer",
    "id": "EU.EORI.NL000000001"
  },
  "resource": {
    "type": "api",
    "id": "/products",
    "properties": {
      "service_provider": "EU.EORI.NL000000002"
    }
  },
  "action": {
    "name": "can_read",
    "properties": {
      "method": "GET",
      "license": "DSGO.0001"
    }
  }
}
```

### Antwoord: volledige toestemming (permit)

De eenvoudigste positieve beslissing: het subject mag de gevraagde actie uitvoeren.

```json
{
  "decision": true
}
```

### Antwoord: gedeeltelijke toestemming (partial permit)

Het subject heeft toegang, maar alleen tot bepaalde identifiers en/of attributen. De PEP moet de response-data filteren op basis van deze restricties.

```json
{
  "decision": true,
  "context": {
    "resource": {
      "type": "api",
      "id": "/products",
      "properties": {
        "service_provider": "EU.EORI.NL000000002",
        "identifiers": ["PRODUCT001"],
        "attributes": ["PRODUCT.WEIGHT", "PRODUCT.PRICE"]
      }
    }
  }
}
```

### Antwoord: geweigerd (deny)

Geen matching policy gevonden. Het `context`-object bevat twee soorten redenen:

- `reason_admin`: technische reden voor beheerders
- `reason_user`: gebruiksvriendelijke melding voor eindgebruikers

```json
{
  "decision": false,
  "context": {
    "reason_admin": {
      "en": "No matching policy found"
    },
    "reason_user": {
      "en": "Insufficient privileges. Contact your administrator."
    }
  }
}
```

### HTTP-statuscodes

| Code | Betekenis |
|------|-----------|
| 200 | Autorisatiebeslissing succesvol (permit of deny) |
| 401 | API key is vereist maar ontbreekt of is ongeldig |
| 403 | Het subject is geen geregistreerde deelnemer in het participantenregister |
| 422 | Validatiefout in het verzoek (bijv. ongeldig EORI-formaat) |

### Verzoek met delegatie

Als het subject namens een andere organisatie handelt, wordt delegatie-informatie meegegeven in `subject.properties.delegation`:

```json
{
  "subject": {
    "type": "service-consumer",
    "id": "EU.EORI.NL000000003",
    "properties": {
      "delegation": {
        "issuer": {
          "type": "service-consumer",
          "id": "EU.EORI.NL000000001"
        },
        "license": "DSGO.0008",
        "url": "https://api.example.com/delegations/1"
      }
    }
  },
  "resource": {
    "type": "api",
    "id": "/products",
    "properties": { "service_provider": "EU.EORI.NL000000002" }
  },
  "action": {
    "name": "can_read",
    "properties": { "method": "GET", "license": "DSGO.0008" }
  }
}
```

---

## POST /api/search

Policy Retrieval Point (PRP): zoekt opgeslagen delegatie-evidence op basis van issuer, subject en resource. Dit endpoint biedt inzicht in welke machtigingen zijn geregistreerd.

### Verzoek

| Veld | Type | Verplicht | Beschrijving |
|------|------|-----------|-------------|
| `issuer` | object | Ja | De organisatie die de machtiging verleend heeft |
| `subject` | object | Ja | De organisatie die gemachtigd is |
| `resource` | object | Ja | De resource waarvoor de machtiging geldt |

```json
{
  "issuer": {
    "type": "service-consumer",
    "id": "EU.EORI.NL000000001"
  },
  "subject": {
    "type": "service-consumer",
    "id": "EU.EORI.NL000000003"
  },
  "resource": {
    "type": "api",
    "id": "/products"
  }
}
```

### Antwoord

```json
{
  "delegationEvidence": [
    {
      "issuer": { "type": "service-consumer", "id": "EU.EORI.NL000000001" },
      "subject": { "type": "service-consumer", "id": "EU.EORI.NL000000003" },
      "resource": {
        "type": "api",
        "id": "/products",
        "properties": { "service_provider": "EU.EORI.NL000000002" }
      },
      "action": {
        "name": "can_access",
        "properties": { "method": "GET", "license": "DSGO.0008" }
      },
      "context": { "url": "https://api.example.com/delegations/1" }
    }
  ]
}
```

Een leeg `delegationEvidence`-array betekent dat er geen matching machtigingen gevonden zijn.

---

## GET /api/health

Lichtgewicht gezondheidscontrole. Geschikt voor load balancers en monitoring.

```json
{
  "status": "ok",
  "service": "dsgo-authz",
  "timestamp": "2026-02-26T10:00:00+00:00"
}
```

## GET /api/status

Gedetailleerde statuscontrole met informatie over het beladen van policies.

```json
{
  "status": "ok",
  "policyLoadedAt": "2026-02-26T10:00:00+00:00"
}
```

Het `policyLoadedAt`-veld geeft aan wanneer de Casbin-enforcer voor het laatst policies uit de database geladen heeft. Kan `null` zijn als er nog geen evaluation heeft plaatsgevonden.

---

## Headers

| Header | Richting | Verplicht | Beschrijving |
|--------|----------|-----------|-------------|
| `Authorization` | Request | Ja* | Bearer token verkregen via `POST /token`. *Niet vereist voor `/api/health`. |
| `X-Correlation-Id` | Request/Response | Nee | Unieke request-identifier voor end-to-end tracing. Wordt automatisch gegenereerd als deze ontbreekt. |
| `X-Data-Service-Id` | Request | Nee | Identificatie van de aanroepende datadienst |

---

## Curl-voorbeelden

```bash
# Gezondheidscontrole (geen token vereist)
curl -s http://localhost:8080/api/health

# Volledige toestemming (Bearer token vereist)
curl -s -X POST http://localhost:8080/api/evaluation \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "subject": {"type": "service-consumer", "id": "EU.EORI.NL000000001"},
    "resource": {"type": "api", "id": "/products", "properties": {"service_provider": "EU.EORI.NL000000002"}},
    "action": {"name": "can_read", "properties": {"method": "GET", "license": "DSGO.0001"}}
  }'

# Weigering (onbekend bedrijf)
curl -s -X POST http://localhost:8080/api/evaluation \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "subject": {"type": "service-consumer", "id": "EU.EORI.NL999999999"},
    "resource": {"type": "api", "id": "/products"},
    "action": {"name": "can_read"}
  }'

# PRP opvraag
curl -s -X POST http://localhost:8080/api/search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "issuer": {"type": "service-consumer", "id": "EU.EORI.NL000000001"},
    "subject": {"type": "service-consumer", "id": "EU.EORI.NL000000003"},
    "resource": {"type": "api", "id": "/products"}
  }'

# Met correlation ID
curl -s -X POST http://localhost:8080/api/evaluation \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Correlation-Id: req-12345" \
  -d '{ ... }'
```
