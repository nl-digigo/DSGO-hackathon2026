# Integratiegids

## Hoe integreert een PEP met deze service?

Een Policy Enforcement Point (PEP) is het externe systeem dat autorisatiebeslissingen afdwingt. In de praktijk is dit de API van de datadienstaanbieder (bijv. Bedrijf B). De PEP stuurt bij elke inkomende API-aanroep een verzoek naar `/api/evaluation` en ontvangt een permit/deny-beslissing.

## Sequentiediagram

```
Bedrijf A             Bedrijf B (PEP)              AuthZ Service              Casbin
    │                      │                            │                       │
    │ GET /products        │                            │                       │
    │─────────────────────>│                            │                       │
    │                      │                            │                       │
    │                      │  POST /api/evaluation      │                       │
    │                      │  "Mag A /products lezen?"  │                       │
    │                      │───────────────────────────>│                       │
    │                      │                            │                       │
    │                      │                            │ 1. Caller identity     │
    │                      │                            │ 2. API key validatie   │
    │                      │                            │ 3. Deelnemer-check     │
    │                      │                            │                       │
    │                      │                            │ enforce(sub, obj, act) │
    │                      │                            │──────────────────────>│
    │                      │                            │  true/false           │
    │                      │                            │<──────────────────────│
    │                      │                            │                       │
    │                      │                            │ 4. Property matching   │
    │                      │                            │ 5. Logging             │
    │                      │                            │                       │
    │                      │  { "decision": true }      │                       │
    │                      │<───────────────────────────│                       │
    │                      │                            │                       │
    │  200 OK (data)       │                            │                       │
    │<─────────────────────│                            │                       │
```

## Stappen voor integratie

### 1. Configureer de AuthZ Service URL

Voeg de URL van de autorisatieservice toe als omgevingsvariabele:

```env
AUTHZ_SERVICE_URL=http://authz-service:8080
```

### 2. Stuur een evaluation-verzoek bij elke API-aanroep

Bij elke inkomende API-aanroep stuurt de PEP een autorisatieverzoek. Het subject is de aanvrager, de resource is het opgevraagde endpoint, en de service_provider is het eigen EORI van de PEP.

```php
$response = $httpClient->request('POST', $authzUrl . '/api/evaluation', [
    'json' => [
        'subject' => [
            'type' => 'service-consumer',
            'id' => $callerEori,
        ],
        'resource' => [
            'type' => 'api',
            'id' => $requestPath,
            'properties' => [
                'service_provider' => $myEori,
            ],
        ],
        'action' => [
            'name' => 'can_read',
            'properties' => [
                'method' => $request->getMethod(),
                'license' => $license,
            ],
        ],
    ],
]);

$result = $response->toArray();
if (!$result['decision']) {
    throw new AccessDeniedException(
        $result['context']['reason_user']['en'] ?? 'Access denied'
    );
}
```

### 3. Verwerk gedeeltelijke autorisatie

Als `decision` gelijk is aan `true` maar het `context.resource`-object aanwezig is, bevat dit restricties. De PEP moet de response-data filteren op basis van deze beperkingen:

```php
if (isset($result['context']['resource']['properties'])) {
    $restrictions = $result['context']['resource']['properties'];

    if (isset($restrictions['identifiers'])) {
        $allowedIds = $restrictions['identifiers'];
        $data = array_filter($data, fn($item) => in_array($item['id'], $allowedIds));
    }

    if (isset($restrictions['attributes'])) {
        $allowedAttributes = $restrictions['attributes'];
        $data = array_map(function($item) use ($allowedAttributes) {
            return array_intersect_key($item, array_flip($allowedAttributes));
        }, $data);
    }
}
```

### 4. Stuur delegatie-informatie mee (optioneel)

Als de aanvragende partij via delegatie namens een andere organisatie handelt, voeg dan de delegatie-informatie toe aan het subject:

```json
{
  "subject": {
    "type": "service-consumer",
    "id": "EU.EORI.NL000000003",
    "properties": {
      "delegation": {
        "issuer": {
          "type": "service-consumer",
          "id": "EU.EORI.NL000000001"
        },
        "license": "DSGO.0008"
      }
    }
  }
}
```

De autorisatieservice valideert automatisch de delegatieketen en slaat het bewijs op.

### 5. Verwerk fouten

De service retourneert standaard HTTP-statuscodes bij fouten:

```php
try {
    $response = $httpClient->request('POST', $authzUrl . '/api/evaluation', [...]);
    $result = $response->toArray();
} catch (\Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface $e) {
    $statusCode = $e->getResponse()->getStatusCode();

    match ($statusCode) {
        401 => throw new AuthenticationException('AuthZ service: API key vereist'),
        403 => throw new AccessDeniedException('AuthZ service: onbekende deelnemer'),
        422 => throw new BadRequestException('AuthZ service: ongeldig verzoek'),
        default => throw new \RuntimeException('AuthZ service onbereikbaar'),
    };
}
```

## Authenticatie

Alle `/api/*` endpoints (behalve `/api/health`) zijn beveiligd met iSHARE OAuth2 Bearer tokens. Een aanroepende partij moet eerst een access token ophalen via `POST /token` voordat API-verzoeken gedaan kunnen worden.

### Token ophalen

De aanroepende partij maakt een JWT client_assertion (RFC 7523) ondertekend met hun private key, inclusief een `x5c`-header met de certificaatketen:

```php
$config = Configuration::forAsymmetricSigner(new Sha256(), $privateKey, $privateKey);
$now = new \DateTimeImmutable();

$assertion = $config->builder()
    ->issuedBy($clientId)
    ->permittedFor($authzServiceId)
    ->relatedTo($clientId)
    ->issuedAt($now)
    ->canOnlyBeUsedAfter($now)
    ->expiresAt($now->modify('+30 seconds'))
    ->withHeader('x5c', $certChain)
    ->getToken($config->signer(), $config->signingKey())
    ->toString();

$tokenResponse = $httpClient->request('POST', $authzUrl . '/token', ['body' => [
    'grant_type' => 'client_credentials',
    'client_assertion_type' => 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
    'client_assertion' => $assertion,
    'client_id' => $clientId,
    'scope' => 'iSHARE',
]]);

$accessToken = $tokenResponse->toArray()['access_token'];
```

### API aanroepen met Bearer token

```php
$response = $httpClient->request('POST', $authzUrl . '/api/evaluation', [
    'headers' => [
        'Authorization' => 'Bearer ' . $accessToken,
    ],
    'json' => [
        'subject' => ['type' => 'service-consumer', 'id' => $callerEori],
        'resource' => ['type' => 'api', 'id' => $requestPath, 'properties' => ['service_provider' => $myEori]],
        'action' => ['name' => 'can_read', 'properties' => ['method' => $request->getMethod(), 'license' => $license]],
    ],
]);
```

### Token-validatie

De server valideert het Bearer token op:
- Geldige handtekening (RSA-SHA256)
- Niet verlopen (`exp`) en niet te vroeg gebruikt (`nbf`)
- Uitgegeven door de verwachte issuer

Bij een ongeldig of verlopen token wordt een `401 Unauthorized` geretourneerd.

## Correlation ID

Voor end-to-end tracing kan een `X-Correlation-Id` header worden meegestuurd:

```bash
curl -H "X-Correlation-Id: req-12345" -X POST http://authz-service/api/evaluation ...
```

Als deze header ontbreekt, genereert de service automatisch een UUID. De correlation ID wordt:

- Gelogd bij elke autorisatiebeslissing
- Teruggegeven in de response-headers
- Opgenomen in de non-repudiation evidence

## Identiteitsextractie

De primaire identificatie vindt plaats via het Bearer token: de `client_id` claim uit het access token identificeert de aanroepende organisatie. Daarnaast ondersteunt de service aanvullende headers:

| Methode | Header | Beschrijving |
|---------|--------|-------------|
| Bearer token | `Authorization` | Primaire authenticatie — `client_id` uit het JWT token |
| Service ID | `X-Data-Service-Id` | Aanvullende identificatie van de datadienst |
| Correlation ID | `X-Correlation-Id` | End-to-end tracing identifier |
