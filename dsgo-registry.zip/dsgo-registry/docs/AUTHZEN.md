# AuthZen-mapping

## OpenID AuthZen 1.0 Draft 04

Deze PoC implementeert het Authorization API-model uit de [OpenID AuthZen 1.0 Draft 04](https://openid.net/specs/openid-authzen-authorization-api-1_0.html) specificatie. AuthZen definieert een gestandaardiseerde API voor autorisatiebeslissingen, onafhankelijk van de onderliggende policy-engine.

### Waarom AuthZen?

AuthZen is gekozen boven alternatieven zoals XACML omdat het:

- **JSON-native** is — sluit direct aan op REST API's
- **Lichtgewicht** is — eenvoudige request/response structuur
- **Uitbreidbaar** is — properties en context bieden flexibiliteit
- **Vendor-onafhankelijk** is — de policy-engine (Casbin) is vervangbaar

## Mapping AuthZen → DSGO

| AuthZen-concept | DSGO-concept | Implementatie |
|----------------|-------------|---------------|
| Subject | Datadienstgebruiker | EORI-identifier (`EU.EORI.NLxxxxxxxxx`) |
| Resource | Datadienst / API-endpoint | Pad + `service_provider` property |
| Action | Operatie op de datadienst | `can_read`, `can_create`, `can_update`, `can_delete`, `can_access` |
| Context | Omgevingsdata | Tijdstip, locatie (optioneel, voor toekomstig gebruik) |
| Evaluation | Autorisatiebeslissing | `POST /api/evaluation` |
| PRP (Policy Retrieval Point) | Delegatie-opvraag | `POST /api/search` |

## Subject

Het subject vertegenwoordigt de organisatie die toegang aanvraagt tot een datadienst.

| Veld | Beschrijving | Voorbeeld |
|------|-------------|-----------|
| `type` | Soort deelnemer | `service-consumer` |
| `id` | EORI-identifier | `EU.EORI.NL000000001` |
| `properties` | Optioneel: delegatie-informatie | Zie delegatiemodel hieronder |

In het DSGO-ecosysteem worden alle deelnemers geidentificeerd met een EORI-nummer (Economic Operators Registration and Identification). Het formaat is altijd `EU.EORI.` gevolgd door de landcode en het registratienummer.

## Resource

De resource beschrijft de datadienst waartoe toegang wordt gevraagd.

| Veld | Beschrijving | Voorbeeld |
|------|-------------|-----------|
| `type` | Altijd `api` in deze PoC | `api` |
| `id` | Pad van het API-endpoint | `/products` |
| `properties.service_provider` | EORI van de datadienstaanbieder | `EU.EORI.NL000000002` |

De `service_provider` property maakt het mogelijk om policies te definieren per aanbieder. Zo kan Bedrijf A toegang hebben tot `/products` bij Bedrijf B, maar niet bij Bedrijf C.

## Action

De action beschrijft welke operatie het subject wil uitvoeren.

| Actie | DSGO-betekenis | Typische HTTP-methode |
|-------|---------------|----------------------|
| `can_read` | Lezen van data | GET |
| `can_create` | Aanmaken van data | POST |
| `can_update` | Bijwerken van data | PUT/PATCH |
| `can_delete` | Verwijderen van data | DELETE |
| `can_access` | Algemene toegang (alle operaties) | * |

De `properties.method` en `properties.license` velden bieden extra granulariteit: de HTTP-methode en de licentiecode waaronder de actie valt.

## Delegatiemodel

Het DSGO kent situaties waarin een organisatie namens een andere organisatie handelt. Dit wordt ondersteund via het delegatiemodel in `subject.properties.delegation`:

```json
{
  "subject": {
    "type": "service-consumer",
    "id": "EU.EORI.NL000000003",
    "properties": {
      "delegation": {
        "issuer": {
          "type": "service-consumer",
          "id": "EU.EORI.NL000000001"
        },
        "license": "DSGO.0008",
        "url": "https://api.example.com/delegations/1"
      }
    }
  }
}
```

| Veld | Beschrijving |
|------|-------------|
| `issuer` | De organisatie die de machtiging verleend heeft (de delegator) |
| `license` | De licentiecode waaronder de machtiging geldt |
| `url` | Optionele URL voor het ophalen van aanvullend delegatie-bewijs |

### Validatie van de delegatieketen

Bij een evaluatie met delegatie worden de volgende controles uitgevoerd:

1. De issuer wordt gevalideerd als geregistreerde deelnemer
2. Bij geneste delegaties (issuer heeft zelf ook een delegatie) wordt de keten recursief gevalideerd
3. De maximale nestingdiepte is 5 niveaus
4. Bij succesvolle validatie wordt de delegatie-evidence automatisch opgeslagen

### Policy Retrieval Point (PRP)

Via `POST /api/search` kunnen opgeslagen delegatie-records worden opgezocht. Dit biedt transparantie over welke machtigingen bestaan tussen organisaties.

## Verschil met XACML

| Aspect | XACML | AuthZen |
|--------|-------|---------|
| Formaat | XML | JSON |
| Complexiteit | Hoog (obligations, conditions, combining algorithms) | Laag (decision + context) |
| Antwoordtypen | Permit / Deny / NotApplicable / Indeterminate | `true` / `false` + context |
| Standaardisatie | OASIS | OpenID Foundation |
| Geschiktheid voor REST | Matig | Uitstekend |
| Gedeeltelijke autorisatie | Via obligations (complex) | Via context (eenvoudig) |

AuthZen is lichter en beter geschikt voor moderne API-architecturen. De `context` in het antwoord biedt flexibiliteit voor gedeeltelijke autorisatie en weigeringsredenen zonder de complexiteit van XACML obligations.
