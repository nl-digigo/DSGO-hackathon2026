# Beleidsmodel

## AuthZen-model

Het autorisatiemodel volgt de OpenID AuthZen 1.0 Draft 04 structuur met drie kernbegrippen:

- **Subject**: wie vraagt toegang? Geidentificeerd door een EORI-identifier.
- **Resource**: waartoe wordt toegang gevraagd? Een API-endpoint met optionele properties.
- **Action**: wat mag er gedaan worden? Een van de gedefinieerde acties.

## PolicyRule-structuur

Elke beleidsregel wordt opgeslagen als een `PolicyRule`-entiteit met de volgende velden:

| Veld | Casbin-veld | Beschrijving | Voorbeeld |
|------|-------------|-------------|-----------|
| `v0` | `sub` | Subject (EORI) | `EU.EORI.NL000000001` |
| `v1` | `obj` | Resource (pad) | `/products` |
| `v2` | `act` | Actie | `can_read` |
| `v3` | — | Dienstaanbieder (EORI) | `EU.EORI.NL000000002` |
| `v4` | — | HTTP-methode | `GET` |
| `v5` | — | Licentiecode | `DSGO.0001` |
| `partial_context` | — | JSON-restricties | `{"identifiers": ["P001"]}` |

**Velden v0–v2** worden door Casbin geevalueerd. **Velden v3–v5 en partial_context** worden door de `PropertyMatcher` in PHP geevalueerd. Deze scheiding is een bewust ontwerp (zie hieronder).

## Waarom Casbin alleen v0–v2 evalueert

Casbin gebruikt een 3-argument matcher:

```ini
[request_definition]
r = sub, obj, act

[policy_definition]
p = sub, obj, act

[matchers]
m = r.sub == p.sub && keyMatch2(r.obj, p.obj) && r.act == p.act
```

De uitgebreide AuthZen-properties (v3–v5, partial_context) worden bewust buiten Casbin om verwerkt door de `PropertyMatcher`. Dit ontwerp is gekozen om vier redenen:

1. **Uitbreidbaarheid**: AuthZen-properties zijn uitbreidbaar. Bij een 6-argument Casbin-model zou elke nieuwe property een modelwijziging vereisen.
2. **Gedeeltelijke autorisatie**: Casbin kent alleen boolean permit/deny. Gedeeltelijke autorisatie (beperkt tot specifieke identifiers of attributen) past niet in dat model.
3. **Geavanceerde matching**: De PropertyMatcher ondersteunt wildcards (`*`), case-insensitive vergelijking en contextopbouw — functionaliteit die Casbin niet biedt.
4. **Vervangbaarheid**: Casbin blijft een lichtgewicht, vervangbaar component. De AuthZen-logica zit volledig in PHP-services.

## Evaluatieflow

Een autorisatieverzoek doorloopt de volgende stappen:

```
EvaluationRequest
    │
    ▼
RequestMapper
    │  Vertaalt AuthZen-request naar Casbin-argumenten (sub, obj, act)
    │  en extraheert uitgebreide properties (service_provider, method, license)
    ▼
CasbinAuthorizer.getMatchingPolicies(sub, obj, act)
    │  Casbin evalueert sub/obj/act met keyMatch2 voor resources.
    │  Bij match worden de bijbehorende PolicyRule-entiteiten uit de database opgehaald.
    ▼
PropertyMatcher.match(policies, properties)
    │  Filtert de Casbin-matches op uitgebreide properties (v3, v4, v5).
    │  Bouwt eventueel een partial_context op uit matching policies.
    ▼
ResponseBuilder
    │  Bouwt het antwoord:
    │  - Volledige toestemming: decision=true, context=null
    │  - Gedeeltelijke toestemming: decision=true, context={resource-restricties}
    │  - Weigering: decision=false, context={reason_admin, reason_user}
    ▼
EvaluationResponse
```

## Gedeeltelijke autorisatie (Partial Authorization)

Als een PolicyRule een `partial_context`-veld heeft, wordt dit meegegeven in het antwoord. Dit beperkt de toegang tot specifieke identifiers en/of attributen:

```json
{
  "identifiers": ["PRODUCT001"],
  "attributes": ["PRODUCT.WEIGHT", "PRODUCT.PRICE"]
}
```

De PEP (het externe systeem) gebruikt deze restricties om alleen de toegestane data te retourneren. Meerdere matching policies met partial_context worden samengevoegd: identifiers en attributen worden gecombineerd.

## Wildcards en matching-gedrag

| Waarde in policy | Betekenis |
|-----------------|-----------|
| `null` (leeg) | Geen restrictie — matcht alles |
| `*` | Wildcard — matcht alles |
| Specifieke waarde | Exacte match (case-insensitive voor methodes) |

Resourcepaden ondersteunen Casbin `keyMatch2`-wildcards. Voorbeeld: het pad `/products/:id` in een policy matcht met elk specifiek product zoals `/products/123`.

### Permissief standaardgedrag

Als een verzoek een property **niet** meestuurt (bijv. geen `service_provider`), matcht dit met elke policy — ook policies die een specifieke waarde voor dat veld bevatten. Dit is een bewuste keuze voor de PoC (permissive default). In een productieomgeving zou dit restrictief moeten zijn: een verzoek zonder property matcht dan alleen met policies die `null` of `*` hebben voor dat veld.

## Voorbeeld: policy-evaluatie stap voor stap

Gegeven de policy:

| v0 (subject) | v1 (resource) | v2 (action) | v3 (provider) | v4 (method) | v5 (license) |
|---|---|---|---|---|---|
| `EU.EORI.NL000000001` | `/products` | `can_read` | `EU.EORI.NL000000002` | `GET` | `DSGO.0001` |

En het verzoek:

```json
{
  "subject": { "id": "EU.EORI.NL000000001" },
  "resource": { "id": "/products", "properties": { "service_provider": "EU.EORI.NL000000002" } },
  "action": { "name": "can_read", "properties": { "method": "GET", "license": "DSGO.0001" } }
}
```

1. **Casbin**: `NL000000001` == `NL000000001` (sub) && `keyMatch2("/products", "/products")` (obj) && `can_read` == `can_read` (act) → **match**
2. **PropertyMatcher**: `NL000000002` == `NL000000002` (v3) && `GET` == `GET` (v4) && `DSGO.0001` == `DSGO.0001` (v5) → **match**
3. **Resultaat**: `{ "decision": true }`
