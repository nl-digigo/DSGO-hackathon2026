# Demo-walkthrough

## Scenario: Bedrijf A, B en C

Drie organisaties in het DSGO-ecosysteem:

| Deelnemer | EORI | Rol | Beschrijving |
|-----------|------|-----|-------------|
| Bedrijf A | `EU.EORI.NL000000001` | Juridisch datadienstgebruiker | Heeft het recht om data op te vragen |
| Bedrijf B | `EU.EORI.NL000000002` | Datadienstaanbieder | Beheert de data en biedt de API aan |
| Bedrijf C | `EU.EORI.NL000000003` | Gemachtigd datadienstgebruiker | Handelt namens Bedrijf A via delegatie |

### Wat demonstreert dit scenario?

1. **Volledige toestemming** — Bedrijf A mag data lezen bij Bedrijf B
2. **Weigering met reden** — Een onbekend bedrijf wordt geweigerd met uitleg
3. **Delegatie** — Bedrijf C handelt namens A, inclusief validatie van de machtigingsketen
4. **PRP-opvraag** — Welke machtigingen bestaan er tussen A en C?
5. **Gedeeltelijke toestemming** — Alleen specifieke producten en attributen zijn toegankelijk

## Voorbereiding

```bash
# Optie 1: via Docker
docker compose up -d
# Wacht ~10 seconden, open http://localhost:8080/admin/policies

# Optie 2: lokaal
make setup && make serve
# Open http://localhost:8000/admin/policies
```

Bekijk de demo-policies in de admin GUI. Er zijn vijf regels voorgeladen die het volledige scenario ondersteunen.

### Token verkrijgen

Alle `/api/*` endpoints (behalve `/api/health`) vereisen een Bearer token. Gebruik de **Token Creator** (`/token/creator`) om een token te genereren, of maak een client_assertion en wissel deze in via `POST /token`. Sla het access_token op in een variabele:

```bash
TOKEN="<access_token uit /token response>"
```

## Stap 1: volledige toestemming

Bedrijf A wil productdata lezen bij Bedrijf B. Er bestaat een policy die dit toestaat.

```bash
curl -s -X POST http://localhost:8080/api/evaluation \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "subject": {"type": "service-consumer", "id": "EU.EORI.NL000000001"},
    "resource": {"type": "api", "id": "/products", "properties": {"service_provider": "EU.EORI.NL000000002"}},
    "action": {"name": "can_read", "properties": {"method": "GET", "license": "DSGO.0001"}}
  }' | python3 -m json.tool
```

Verwacht resultaat:

```json
{
  "decision": true
}
```

## Stap 2: weigering met reden

Een onbekend bedrijf (geen matching policy) probeert dezelfde data op te vragen:

```bash
curl -s -X POST http://localhost:8080/api/evaluation \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "subject": {"type": "service-consumer", "id": "EU.EORI.NL999999999"},
    "resource": {"type": "api", "id": "/products"},
    "action": {"name": "can_read"}
  }' | python3 -m json.tool
```

Verwacht resultaat:

```json
{
  "decision": false,
  "context": {
    "reason_admin": { "en": "No matching policy found" },
    "reason_user": { "en": "Insufficient privileges. Contact your administrator." }
  }
}
```

Het `context`-object bevat twee soorten redenen: een technische voor beheerders en een gebruiksvriendelijke voor eindgebruikers.

## Stap 3: delegatie

Bedrijf C handelt namens Bedrijf A. De delegatie-informatie wordt meegegeven in het subject:

```bash
curl -s -X POST http://localhost:8080/api/evaluation \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "subject": {
      "type": "service-consumer",
      "id": "EU.EORI.NL000000003",
      "properties": {
        "delegation": {
          "issuer": {"type": "service-consumer", "id": "EU.EORI.NL000000001"},
          "license": "DSGO.0008"
        }
      }
    },
    "resource": {"type": "api", "id": "/products", "properties": {"service_provider": "EU.EORI.NL000000002"}},
    "action": {"name": "can_read", "properties": {"method": "GET", "license": "DSGO.0008"}}
  }' | python3 -m json.tool
```

Verwacht resultaat:

```json
{
  "decision": true
}
```

De service valideert automatisch dat Bedrijf A (de issuer) een geregistreerde deelnemer is en slaat de delegatie-evidence op.

## Stap 4: PRP-opvraag

Zoek delegatie-bewijs voor de machtiging van A aan C:

```bash
curl -s -X POST http://localhost:8080/api/search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "issuer": {"type": "service-consumer", "id": "EU.EORI.NL000000001"},
    "subject": {"type": "service-consumer", "id": "EU.EORI.NL000000003"},
    "resource": {"type": "api", "id": "/products"}
  }' | python3 -m json.tool
```

Verwacht resultaat: een lijst met delegation evidence-records die de machtiging van A aan C bevestigen, inclusief licentiecode en eventuele evidence-URL.

## Stap 5: gedeeltelijke toestemming

De demo-policies bevatten een regel met een `partial_context`. Deze beperkt de toegang tot specifieke producten en attributen:

```bash
curl -s -X POST http://localhost:8080/api/evaluation \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "subject": {"type": "service-consumer", "id": "EU.EORI.NL000000001"},
    "resource": {"type": "api", "id": "/products", "properties": {"service_provider": "EU.EORI.NL000000002"}},
    "action": {"name": "can_read", "properties": {"method": "GET", "license": "DSGO.0001"}}
  }' | python3 -m json.tool
```

Als de matching policy een partial_context bevat, ziet het antwoord er zo uit:

```json
{
  "decision": true,
  "context": {
    "resource": {
      "type": "api",
      "id": "/products",
      "properties": {
        "service_provider": "EU.EORI.NL000000002",
        "identifiers": ["PRODUCT001"],
        "attributes": ["PRODUCT.WEIGHT", "PRODUCT.PRICE"]
      }
    }
  }
}
```

De PEP moet de response-data filteren: alleen product `PRODUCT001` retourneren, en daarvan alleen de velden `WEIGHT` en `PRICE`.

## Admin GUI

| Pagina | URL | Functie |
|--------|-----|---------|
| Policies | http://localhost:8080/admin/policies | CRUD voor autorisatieregels |
| Delegaties | http://localhost:8080/admin/delegations | CRUD voor delegatie-evidence |
| Importeren | http://localhost:8080/admin/policies/import | Bulk-import via CSV |
| Token Creator | http://localhost:8080/token/creator | Test-pagina voor token-generatie |
| API Docs | http://localhost:8080/api/docs | Swagger UI (Bearer token vereist) |

## Automatisch uitvoeren

```bash
# Via Docker (standaard poort 8080)
make demo

# Lokaal (poort 8000)
make demo BASE_URL=http://localhost:8000
```

Dit draait stap 1, 2 en 4 automatisch met gekleurde uitvoer in de terminal.
