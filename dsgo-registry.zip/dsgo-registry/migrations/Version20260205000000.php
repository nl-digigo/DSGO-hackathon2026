<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Create the authz_policy_rule table for Casbin policy storage.
 */
final class Version20260205000000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Create authz_policy_rule table for Casbin policy storage';
    }

    public function up(Schema $schema): void
    {
        $table = $schema->createTable('authz_policy_rule');
        
        $table->addColumn('id', 'integer', [
            'autoincrement' => true,
            'notnull' => true,
        ]);
        
        $table->addColumn('ptype', 'string', [
            'length' => 10,
            'notnull' => true,
            'default' => 'p',
        ]);
        
        $table->addColumn('v0', 'string', [
            'length' => 255,
            'notnull' => true,
        ]);
        
        $table->addColumn('v1', 'string', [
            'length' => 255,
            'notnull' => true,
        ]);
        
        $table->addColumn('v2', 'string', [
            'length' => 50,
            'notnull' => true,
        ]);
        
        $table->addColumn('v3', 'string', [
            'length' => 255,
            'notnull' => false,
        ]);
        
        $table->addColumn('v4', 'string', [
            'length' => 255,
            'notnull' => false,
        ]);
        
        $table->addColumn('v5', 'string', [
            'length' => 255,
            'notnull' => false,
        ]);
        
        $table->addColumn('created_at', 'datetime_immutable', [
            'notnull' => true,
        ]);
        
        $table->addColumn('updated_at', 'datetime_immutable', [
            'notnull' => true,
        ]);
        
        $table->setPrimaryKey(['id']);
        $table->addIndex(['ptype', 'v0', 'v1', 'v2'], 'idx_policy_lookup');
    }

    public function down(Schema $schema): void
    {
        $schema->dropTable('authz_policy_rule');
    }
}
