<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * AuthZen clean-room rebuild: add partial_context to policy rules, create delegation_evidence table.
 */
final class Version20260226000000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'AuthZen rebuild: add partial_context column and create delegation_evidence table';
    }

    public function up(Schema $schema): void
    {
        // Add partial_context only when missing (safe for already-initialized databases).
        if ($schema->hasTable('authz_policy_rule')) {
            $policyRule = $schema->getTable('authz_policy_rule');
            if (!$policyRule->hasColumn('partial_context')) {
                $this->addSql('ALTER TABLE authz_policy_rule ADD COLUMN partial_context JSON DEFAULT NULL');
            }
        }

        // Create delegation_evidence only when missing.
        if (!$schema->hasTable('delegation_evidence')) {
            $table = $schema->createTable('delegation_evidence');

            $table->addColumn('id', 'string', ['length' => 36, 'notnull' => true]);
            $table->addColumn('parent_id', 'string', ['length' => 36, 'notnull' => false]);
            $table->addColumn('issuer_type', 'string', ['length' => 50, 'notnull' => true]);
            $table->addColumn('issuer_id', 'string', ['length' => 255, 'notnull' => true]);
            $table->addColumn('subject_type', 'string', ['length' => 50, 'notnull' => true]);
            $table->addColumn('subject_id', 'string', ['length' => 255, 'notnull' => true]);
            $table->addColumn('resource_type', 'string', ['length' => 50, 'notnull' => true]);
            $table->addColumn('resource_id', 'string', ['length' => 255, 'notnull' => true]);
            $table->addColumn('resource_properties', 'json', ['notnull' => false]);
            $table->addColumn('action_name', 'string', ['length' => 50, 'notnull' => true]);
            $table->addColumn('action_properties', 'json', ['notnull' => false]);
            $table->addColumn('context_url', 'string', ['length' => 500, 'notnull' => false]);
            $table->addColumn('created_at', 'datetime_immutable', ['notnull' => true]);

            $table->setPrimaryKey(['id']);
            $table->addIndex(['issuer_id', 'subject_id'], 'idx_delegation_issuer_subject');
            $table->addIndex(['resource_id', 'action_name'], 'idx_delegation_resource_action');
            $table->addForeignKeyConstraint('delegation_evidence', ['parent_id'], ['id'], ['onDelete' => 'SET NULL'], 'fk_delegation_parent');
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable('delegation_evidence')) {
            $schema->dropTable('delegation_evidence');
        }

        if ($schema->hasTable('authz_policy_rule')) {
            $policyRule = $schema->getTable('authz_policy_rule');
            if ($policyRule->hasColumn('partial_context')) {
                $this->addSql('ALTER TABLE authz_policy_rule DROP COLUMN partial_context');
            }
        }
    }
}
