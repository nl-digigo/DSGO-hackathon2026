<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Seed demo data: policies and delegation evidence.
 *
 * Production-ready demo (iSHARE DID identifiers registered in Digigo):
 * - did:ishare:EU.NL.NTRNL-99999998 (test client) mag /products lezen bij did:ishare:EU.NL.NTRNL-99999999 (server)
 *
 * Test scenario (EU.EORI identifiers for functional tests):
 * - EU.EORI.NL000000001 (Bedrijf A) mag /products lezen bij EU.EORI.NL000000002 (Bedrijf B)
 * - EU.EORI.NL000000003 (Bedrijf C) mag /products lezen bij B via delegatie van A
 */
final class Version20260322000000 extends AbstractMigration
{
    public function getDescription(): string
    {
        return 'Seed demo policies and delegation evidence';
    }

    public function up(Schema $schema): void
    {
        $now = (new \DateTimeImmutable())->format('Y-m-d H:i:s');

        // Production demo: test client → server
        $this->seedPolicy('did:ishare:EU.NL.NTRNL-99999998', '/products', 'can_read', 'did:ishare:EU.NL.NTRNL-99999999', 'GET', 'DSGO.0001', $now);

        // Test scenario: Bedrijf A/B/C
        $this->seedPolicy('EU.EORI.NL000000001', '/products', 'can_read', 'EU.EORI.NL000000002', 'GET', 'DSGO.0001', $now);
        $this->seedPolicy('EU.EORI.NL000000003', '/products', 'can_read', 'EU.EORI.NL000000002', 'GET', 'DSGO.0008', $now);

        $deExists = $this->connection->fetchOne(
            "SELECT COUNT(*) FROM delegation_evidence WHERE issuer_id = 'EU.EORI.NL000000001' AND subject_id = 'EU.EORI.NL000000003' AND resource_id = '/products'"
        );
        if ((int) $deExists === 0) {
            $id = bin2hex(random_bytes(18));
            $this->addSql("INSERT INTO delegation_evidence (id, parent_id, issuer_type, issuer_id, subject_type, subject_id, resource_type, resource_id, resource_properties, action_name, action_properties, context_url, created_at) VALUES ('$id', NULL, 'service-consumer', 'EU.EORI.NL000000001', 'service-consumer', 'EU.EORI.NL000000003', 'api', '/products', '{\"service_provider\":\"EU.EORI.NL000000002\"}', 'can_access', '{\"method\":\"GET\",\"license\":\"DSGO.0008\"}', NULL, '$now')");
        }
    }

    public function down(Schema $schema): void
    {
        $this->addSql("DELETE FROM authz_policy_rule WHERE v0 = 'did:ishare:EU.NL.NTRNL-99999998' AND v1 = '/products' AND v2 = 'can_read'");
        $this->addSql("DELETE FROM authz_policy_rule WHERE v0 = 'EU.EORI.NL000000001' AND v1 = '/products' AND v2 = 'can_read'");
        $this->addSql("DELETE FROM authz_policy_rule WHERE v0 = 'EU.EORI.NL000000003' AND v1 = '/products' AND v2 = 'can_read'");
        $this->addSql("DELETE FROM delegation_evidence WHERE issuer_id = 'EU.EORI.NL000000001' AND subject_id = 'EU.EORI.NL000000003' AND resource_id = '/products'");
    }

    private function seedPolicy(string $v0, string $v1, string $v2, string $v3, string $v4, string $v5, string $now): void
    {
        $exists = $this->connection->fetchOne(
            "SELECT COUNT(*) FROM authz_policy_rule WHERE v0 = '$v0' AND v1 = '$v1' AND v2 = '$v2' AND v3 = '$v3'"
        );
        if ((int) $exists === 0) {
            $this->addSql("INSERT INTO authz_policy_rule (ptype, v0, v1, v2, v3, v4, v5, created_at, updated_at) VALUES ('p', '$v0', '$v1', '$v2', '$v3', '$v4', '$v5', '$now', '$now')");
        }
    }
}
