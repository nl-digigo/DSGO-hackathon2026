<?php

declare(strict_types=1);

namespace App\Tests\Functional\Admin;

use App\Entity\DelegationEvidence;
use App\Tests\Support\DatabaseTestTrait;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DelegationControllerTest extends WebTestCase
{
    use DatabaseTestTrait;

    private static function createDelegation(EntityManagerInterface $em): DelegationEvidence
    {
        $delegation = new DelegationEvidence();
        $delegation->setIssuerType('service-consumer');
        $delegation->setIssuerId('EU.EORI.NL000000001');
        $delegation->setSubjectType('service-consumer');
        $delegation->setSubjectId('EU.EORI.NL000000003');
        $delegation->setResourceType('api');
        $delegation->setResourceId('/products');
        $delegation->setActionName('can_read');
        $em->persist($delegation);
        $em->flush();

        return $delegation;
    }

    public function testIndexPageLoads(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        self::ensureSchema(static::getContainer()->get(EntityManagerInterface::class));

        $client->request('GET', '/admin/delegations');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h1', 'Delegation Evidence');
    }

    public function testIndexShowsDelegations(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createDelegation($em);

        $client->request('GET', '/admin/delegations');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('table', 'EU.EORI.NL000000001');
        $this->assertSelectorTextContains('table', 'EU.EORI.NL000000003');
    }

    public function testNewPageLoads(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        self::ensureSchema(static::getContainer()->get(EntityManagerInterface::class));

        $client->request('GET', '/admin/delegations/new');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h1', 'Nieuwe Delegation Evidence');
    }

    public function testDeleteDelegation(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        $delegation = self::createDelegation($em);
        $delegationId = $delegation->getId();

        $crawler = $client->request('GET', '/admin/delegations/' . $delegationId . '/edit');
        $this->assertResponseIsSuccessful();

        $token = $crawler->filter('form[action*="delete"] input[name="_token"]')->attr('value');

        $client->request('POST', '/admin/delegations/' . $delegationId . '/delete', [
            '_token' => $token,
        ]);

        $this->assertResponseRedirects('/admin/delegations');

        $em->clear();
        $this->assertNull($em->find(DelegationEvidence::class, $delegationId));
    }
}
