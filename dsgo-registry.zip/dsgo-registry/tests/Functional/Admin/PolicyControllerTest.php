<?php

declare(strict_types=1);

namespace App\Tests\Functional\Admin;

use App\Entity\PolicyRule;
use App\Tests\Support\DatabaseTestTrait;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class PolicyControllerTest extends WebTestCase
{
    use DatabaseTestTrait;

    private static function createPolicy(
        EntityManagerInterface $em,
        string $subject = 'EU.EORI.NL000000001',
        string $resource = '/products',
        string $action = 'can_read',
    ): PolicyRule {
        $policy = new PolicyRule();
        $policy->setV0($subject);
        $policy->setV1($resource);
        $policy->setV2($action);
        $em->persist($policy);
        $em->flush();

        return $policy;
    }

    public function testIndexPageLoads(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        self::ensureSchema(static::getContainer()->get(EntityManagerInterface::class));

        $client->request('GET', '/admin/policies');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h1', 'Policies');
    }

    public function testIndexShowsPolicies(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy($em);

        $client->request('GET', '/admin/policies');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('table', 'EU.EORI.NL000000001');
    }

    public function testDeletePolicy(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        $policy = self::createPolicy($em);
        $policyId = $policy->getId();

        $crawler = $client->request('GET', '/admin/policies/' . $policyId . '/edit');
        $deleteForm = $crawler->filter('form[action*="delete"]')->form();
        $client->submit($deleteForm);

        $this->assertResponseRedirects('/admin/policies');

        $em->clear();
        $this->assertNull($em->find(PolicyRule::class, $policyId));
    }

    public function testBySubjectPage(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy($em, 'EU.EORI.NL000000001', '/products', 'can_read');
        self::createPolicy($em, 'EU.EORI.NL000000002', '/orders', 'can_read');

        $client->request('GET', '/admin/policies/subject/' . urlencode('EU.EORI.NL000000001'));

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('table', '/products');
        $this->assertSelectorTextNotContains('table', '/orders');
    }
}
