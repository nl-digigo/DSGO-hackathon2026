<?php

declare(strict_types=1);

namespace App\Tests\Functional\Api;

use App\Entity\DelegationEvidence;
use App\Entity\PolicyRule;
use App\Tests\Support\DatabaseTestTrait;
use App\Tests\Support\JwtTestHelper;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

/**
 * End-to-end demo scenario: Bedrijf A/B/C.
 *
 * - EU.EORI.NL000000001 = Bedrijf A (juridisch datadienstgebruiker)
 * - EU.EORI.NL000000002 = Bedrijf B (datadienstaanbieder)
 * - EU.EORI.NL000000003 = Bedrijf C (gemachtigd datadienstgebruiker, acteert namens A)
 */
class DemoScenarioTest extends WebTestCase
{
    use DatabaseTestTrait;
    use JwtTestHelper;

    private static function setupScenario(EntityManagerInterface $em): void
    {
        self::ensureSchema($em);

        // Policy: A mag /products lezen bij B
        $p1 = new PolicyRule();
        $p1->setV0('EU.EORI.NL000000001');
        $p1->setV1('/products');
        $p1->setV2('can_read');
        $p1->setServiceProvider('EU.EORI.NL000000002');
        $p1->setMethod('GET');
        $p1->setLicense('DSGO.0001');
        $em->persist($p1);

        // Policy: C mag /products lezen bij B (via delegatie)
        $p2 = new PolicyRule();
        $p2->setV0('EU.EORI.NL000000003');
        $p2->setV1('/products');
        $p2->setV2('can_read');
        $p2->setServiceProvider('EU.EORI.NL000000002');
        $p2->setMethod('GET');
        $p2->setLicense('DSGO.0008');
        $em->persist($p2);

        // Delegation evidence: A delegeert aan C
        $de = new DelegationEvidence();
        $de->setIssuerType('service-consumer');
        $de->setIssuerId('EU.EORI.NL000000001');
        $de->setSubjectType('service-consumer');
        $de->setSubjectId('EU.EORI.NL000000003');
        $de->setResourceType('api');
        $de->setResourceId('/products');
        $de->setResourceProperties(['service_provider' => 'EU.EORI.NL000000002']);
        $de->setActionName('can_access');
        $de->setActionProperties(['method' => 'GET', 'license' => 'DSGO.0008']);
        $em->persist($de);

        $em->flush();
    }

    public function testBedrijfACanReadProducts(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::setupScenario($em);

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'EU.EORI.NL000000002']],
            'action' => ['name' => 'can_read', 'properties' => ['method' => 'GET', 'license' => 'DSGO.0001']],
        ]));

        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertTrue($data['decision']);
    }

    public function testBedrijfCCanReadViaDelegation(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::setupScenario($em);

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => [
                'type' => 'service-consumer',
                'id' => 'EU.EORI.NL000000003',
                'properties' => [
                    'delegation' => [
                        'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
                        'license' => 'DSGO.0008',
                        'url' => 'https://api.example.com/delegations/1',
                    ],
                ],
            ],
            'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'EU.EORI.NL000000002']],
            'action' => ['name' => 'can_read', 'properties' => ['method' => 'GET', 'license' => 'DSGO.0008']],
        ]));

        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertTrue($data['decision']);
    }

    public function testUnregisteredBedrijfIsRejectedByRegistry(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::setupScenario($em);

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL888888888'],
            'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'EU.EORI.NL000000002']],
            'action' => ['name' => 'can_read', 'properties' => ['method' => 'GET', 'license' => 'DSGO.0001']],
        ]));

        $this->assertResponseStatusCodeSame(403);
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertStringContainsString('not a registered participant', $data['detail']);
    }

    public function testRegisteredBedrijfWithoutPolicyIsDenied(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::setupScenario($em);

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL999999999'],
            'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'EU.EORI.NL000000002']],
            'action' => ['name' => 'can_read', 'properties' => ['method' => 'GET', 'license' => 'DSGO.0001']],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertFalse($data['decision']);
        $this->assertArrayHasKey('reason_admin', $data['context']);
    }

    public function testPrpLookupFindsDelegation(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::setupScenario($em);

        $client->request('POST', '/api/search', [], [], self::jsonAuthHeaders(), json_encode([
            'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000003'],
            'resource' => ['type' => 'api', 'id' => '/products'],
        ]));

        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertCount(1, $data['delegationEvidence']);
        $this->assertEquals('EU.EORI.NL000000001', $data['delegationEvidence'][0]['issuer']['id']);
        $this->assertEquals('EU.EORI.NL000000003', $data['delegationEvidence'][0]['subject']['id']);
    }
}
