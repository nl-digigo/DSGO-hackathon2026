<?php

declare(strict_types=1);

namespace App\Tests\Functional\Api;

use App\Controller\TokenController;
use App\Entity\PolicyRule;
use App\Tests\Support\DatabaseTestTrait;
use App\Util\JwtKeyPaths;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

/**
 * Full end-to-end flow: /token → access_token → /api/evaluation → decision.
 *
 * Uses the server's own key/cert (NTRNL-99999999) as client credentials,
 * which is registered in TestParticipantRegistry.
 */
class FullFlowTest extends WebTestCase
{
    use DatabaseTestTrait;

    private static function pemChainToX5cArray(string $pemChain): array
    {
        preg_match_all(
            '/-----BEGIN CERTIFICATE-----\s*(.+?)\s*-----END CERTIFICATE-----/s',
            $pemChain,
            $matches,
        );

        return array_map(
            fn(string $base64) => str_replace(["\r", "\n", " "], '', $base64),
            $matches[1],
        );
    }

    private static function buildClientAssertion(): string
    {
        $privateKey = InMemory::file(JwtKeyPaths::PRIVATE_KEY, '');
        $config = Configuration::forSymmetricSigner(new Sha256(), $privateKey);
        $x5c = self::pemChainToX5cArray(file_get_contents(JwtKeyPaths::CERT_CHAIN));

        $clientDid = 'did:ishare:EU.NL.NTRNL-99999999';
        $serverDid = TokenController::clientId;
        $now = new \DateTimeImmutable('now', new \DateTimeZone('europe/amsterdam'));

        return $config->builder()
            ->withHeader('x5c', $x5c)
            ->withHeader('typ', 'JWT')
            ->issuedBy($clientDid)
            ->relatedTo($clientDid)
            ->permittedFor($serverDid)
            ->identifiedBy(bin2hex(random_bytes(16)))
            ->issuedAt($now)
            ->canOnlyBeUsedAfter($now)
            ->expiresAt($now->modify('+30 seconds'))
            ->getToken($config->signer(), $config->signingKey())
            ->toString();
    }

    public function testFullTokenThenEvaluationFlow(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(\Doctrine\ORM\EntityManagerInterface::class);
        self::ensureSchema($em);

        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');
        $em->persist($policy);
        $em->flush();

        // Step 1: obtain access token via /token
        $assertion = self::buildClientAssertion();
        $client->request('POST', '/token', [
            'grant_type' => 'client_credentials',
            'client_assertion_type' => 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
            'client_assertion' => $assertion,
            'client_id' => 'did:ishare:EU.NL.NTRNL-99999999',
            'scope' => 'iSHARE',
        ]);

        $this->assertResponseIsSuccessful();
        $tokenData = json_decode($client->getResponse()->getContent(), true);
        $this->assertArrayHasKey('access_token', $tokenData);
        $this->assertSame('Bearer', $tokenData['token_type']);
        $this->assertSame(3600, $tokenData['expires_in']);
        $this->assertSame('iSHARE', $tokenData['scope']);

        $accessToken = $tokenData['access_token'];

        // Verify the access token is a valid, decodable JWT
        $config = Configuration::forSymmetricSigner(new Sha256(), InMemory::file(JwtKeyPaths::PRIVATE_KEY, ''));
        $parsedToken = $config->parser()->parse($accessToken);
        assert($parsedToken instanceof \Lcobucci\JWT\UnencryptedToken);
        $this->assertSame(TokenController::clientId, $parsedToken->claims()->get('iss'));
        $this->assertSame('did:ishare:EU.NL.NTRNL-99999999', $parsedToken->claims()->get('client_id'));
        $this->assertContains('iSHARE', $parsedToken->claims()->get('scope'));
        $this->assertTrue($parsedToken->claims()->get('exp') > new \DateTimeImmutable());

        // Step 2: call /api/evaluation with the access token
        $client->request('POST', '/api/evaluation', [], [], [
            'CONTENT_TYPE' => 'application/json',
            'HTTP_AUTHORIZATION' => 'Bearer ' . $accessToken,
        ], json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseIsSuccessful();
        $evalData = json_decode($client->getResponse()->getContent(), true);
        $this->assertTrue($evalData['decision']);
        $correlationId = $client->getResponse()->headers->get('X-Correlation-Id');
        $this->assertNotNull($correlationId);
        $this->assertNotEmpty($correlationId);
    }

    public function testFullTokenThenSearchFlow(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(\Doctrine\ORM\EntityManagerInterface::class);
        self::ensureSchema($em);

        $de = new \App\Entity\DelegationEvidence();
        $de->setIssuerType('service-consumer');
        $de->setIssuerId('EU.EORI.NL000000001');
        $de->setSubjectType('service-consumer');
        $de->setSubjectId('EU.EORI.NL000000003');
        $de->setResourceType('api');
        $de->setResourceId('/products');
        $de->setResourceProperties(['service_provider' => 'EU.EORI.NL000000002']);
        $de->setActionName('can_access');
        $de->setActionProperties(['method' => 'GET']);
        $em->persist($de);
        $em->flush();

        // Step 1: obtain access token
        $assertion = self::buildClientAssertion();
        $client->request('POST', '/token', [
            'grant_type' => 'client_credentials',
            'client_assertion_type' => 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
            'client_assertion' => $assertion,
            'client_id' => 'did:ishare:EU.NL.NTRNL-99999999',
            'scope' => 'iSHARE',
        ]);

        $this->assertResponseIsSuccessful();
        $accessToken = json_decode($client->getResponse()->getContent(), true)['access_token'];

        // Step 2: call /api/search with the access token
        $client->request('POST', '/api/search', [], [], [
            'CONTENT_TYPE' => 'application/json',
            'HTTP_AUTHORIZATION' => 'Bearer ' . $accessToken,
        ], json_encode([
            'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000003'],
            'resource' => ['type' => 'api', 'id' => '/products'],
        ]));

        $this->assertResponseIsSuccessful();
        $searchData = json_decode($client->getResponse()->getContent(), true);
        $this->assertCount(1, $searchData['delegationEvidence']);
        $this->assertEquals('EU.EORI.NL000000001', $searchData['delegationEvidence'][0]['issuer']['id']);
    }

    public function testTokenWithUnregisteredPartyIsRejected(): void
    {
        $client = static::createClient();

        $privateKey = InMemory::file(JwtKeyPaths::PRIVATE_KEY, '');
        $config = Configuration::forSymmetricSigner(new Sha256(), $privateKey);
        $x5c = self::pemChainToX5cArray(file_get_contents(JwtKeyPaths::CERT_CHAIN));
        $now = new \DateTimeImmutable('now', new \DateTimeZone('europe/amsterdam'));

        // Build assertion with valid signature but the cert's organizationIdentifier
        // (NTRNL-99999999) would pass. Instead we test that an invalid client_id
        // mismatch is caught: client_id says something different than iss/sub.
        $assertion = $config->builder()
            ->withHeader('x5c', $x5c)
            ->withHeader('typ', 'JWT')
            ->issuedBy('did:ishare:EU.NL.NTRNL-99999999')
            ->relatedTo('did:ishare:EU.NL.NTRNL-99999999')
            ->permittedFor(TokenController::clientId)
            ->identifiedBy(bin2hex(random_bytes(16)))
            ->issuedAt($now)
            ->canOnlyBeUsedAfter($now)
            ->expiresAt($now->modify('+30 seconds'))
            ->getToken($config->signer(), $config->signingKey())
            ->toString();

        $client->request('POST', '/token', [
            'grant_type' => 'client_credentials',
            'client_assertion' => $assertion,
            'client_id' => 'did:ishare:EU.NL.FAKE-00000000',
        ]);

        $this->assertResponseStatusCodeSame(401);
    }
}
