<?php

declare(strict_types=1);

namespace App\Tests\Functional\Api;

use App\Entity\DelegationEvidence;
use App\Tests\Support\DatabaseTestTrait;
use App\Tests\Support\JwtTestHelper;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class PolicySearchTest extends WebTestCase
{
    use DatabaseTestTrait;
    use JwtTestHelper;

    public function testSearchReturnsDelegationEvidence(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $evidence = new DelegationEvidence();
        $evidence->setIssuerType('service-consumer');
        $evidence->setIssuerId('EU.EORI.NL000000001');
        $evidence->setSubjectType('service-consumer');
        $evidence->setSubjectId('EU.EORI.NL000000003');
        $evidence->setResourceType('api');
        $evidence->setResourceId('/products');
        $evidence->setActionName('can_access');
        $evidence->setActionProperties(['method' => 'GET', 'license' => 'DSGO.0008']);
        $evidence->setResourceProperties(['service_provider' => 'EU.EORI.NL000000002']);
        $em->persist($evidence);
        $em->flush();

        $client->request('POST', '/api/search', [], [], self::jsonAuthHeaders(), json_encode([
            'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000003'],
            'resource' => ['type' => 'api', 'id' => '/products'],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertArrayHasKey('delegationEvidence', $data);
        $this->assertCount(1, $data['delegationEvidence']);
        $this->assertEquals('EU.EORI.NL000000001', $data['delegationEvidence'][0]['issuer']['id']);
    }

    public function testSearchReturnsEmptyWhenNoMatch(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('POST', '/api/search', [], [], self::jsonAuthHeaders(), json_encode([
            'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000003'],
            'resource' => ['type' => 'api', 'id' => '/nonexistent'],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertEmpty($data['delegationEvidence']);
    }

    public function testSearchValidationError(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('POST', '/api/search', [], [], self::jsonAuthHeaders(), json_encode([
            'issuer' => ['type' => 'service-consumer', 'id' => 'INVALID'],
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000003'],
            'resource' => ['type' => 'api', 'id' => '/products'],
        ]));

        $this->assertResponseStatusCodeSame(422);
    }
}
