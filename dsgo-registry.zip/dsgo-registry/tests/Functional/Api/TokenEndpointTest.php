<?php

declare(strict_types=1);

namespace App\Tests\Functional\Api;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class TokenEndpointTest extends WebTestCase
{
    public function testMissingGrantTypeReturns400(): void
    {
        $client = static::createClient();

        $client->request('POST', '/token', [
            'client_assertion' => 'some-assertion',
        ]);

        $this->assertResponseStatusCodeSame(400);
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('invalid_request', $data['error']);
    }

    public function testWrongGrantTypeReturns400(): void
    {
        $client = static::createClient();

        $client->request('POST', '/token', [
            'grant_type' => 'authorization_code',
            'client_assertion' => 'some-assertion',
        ]);

        $this->assertResponseStatusCodeSame(400);
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('invalid_request', $data['error']);
    }

    public function testMissingClientAssertionReturns400(): void
    {
        $client = static::createClient();

        $client->request('POST', '/token', [
            'grant_type' => 'client_credentials',
        ]);

        $this->assertResponseStatusCodeSame(400);
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('invalid_request', $data['error']);
    }

    public function testMalformedClientAssertionReturns401(): void
    {
        $client = static::createClient();

        $client->request('POST', '/token', [
            'grant_type' => 'client_credentials',
            'client_assertion' => 'not-a-valid-jwt',
        ]);

        $this->assertResponseStatusCodeSame(401);
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('invalid_client_assertion', $data['error']);
    }

    public function testAssertionWithoutX5cReturns401(): void
    {
        $client = static::createClient();

        $privateKey = \Lcobucci\JWT\Signer\Key\InMemory::file(\App\Util\JwtKeyPaths::PRIVATE_KEY, '');
        $config = \Lcobucci\JWT\Configuration::forSymmetricSigner(
            new \Lcobucci\JWT\Signer\Rsa\Sha256(),
            $privateKey,
        );
        $now = new \DateTimeImmutable('now', new \DateTimeZone('europe/amsterdam'));

        $assertion = $config->builder()
            ->issuedBy('did:ishare:EU.NL.NTRNL-12345678')
            ->permittedFor('did:ishare:EU.NL.NTRNL-99999999')
            ->relatedTo('did:ishare:EU.NL.NTRNL-12345678')
            ->issuedAt($now)
            ->canOnlyBeUsedAfter($now)
            ->expiresAt($now->modify('+30 seconds'))
            ->getToken($config->signer(), $config->signingKey())
            ->toString();

        $client->request('POST', '/token', [
            'grant_type' => 'client_credentials',
            'client_assertion' => $assertion,
        ]);

        $this->assertResponseStatusCodeSame(401);
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('missing_x5c', $data['error']);
    }

    public function testGetMethodNotAllowed(): void
    {
        $client = static::createClient();

        $client->request('GET', '/token');

        $this->assertResponseStatusCodeSame(405);
    }
}
