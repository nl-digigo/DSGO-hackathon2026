<?php

declare(strict_types=1);

namespace App\Tests\Functional\Api;

use App\Entity\PolicyRule;
use App\Tests\Support\DatabaseTestTrait;
use App\Tests\Support\JwtTestHelper;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class HealthAndStatusTest extends WebTestCase
{
    use DatabaseTestTrait;
    use JwtTestHelper;

    public function testHealthEndpoint(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('GET', '/api/health', [], [], self::authHeaders());

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('ok', $data['status']);
        $this->assertSame('dsgo-authz', $data['service']);
        $this->assertArrayHasKey('timestamp', $data);
    }

    public function testStatusEndpoint(): void
    {
        $client = static::createClient();
        $client->disableReboot();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');
        $em->persist($policy);
        $em->flush();

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $client->request('GET', '/api/status', [], [], self::authHeaders());

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('ok', $data['status']);
        $this->assertNotNull($data['policyLoadedAt']);
    }
}
