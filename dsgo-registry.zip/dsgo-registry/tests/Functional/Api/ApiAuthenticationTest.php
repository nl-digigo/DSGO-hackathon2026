<?php

declare(strict_types=1);

namespace App\Tests\Functional\Api;

use App\Tests\Support\DatabaseTestTrait;
use App\Tests\Support\JwtTestHelper;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ApiAuthenticationTest extends WebTestCase
{
    use DatabaseTestTrait;
    use JwtTestHelper;

    public function testProtectedApiReturns401WithoutToken(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('GET', '/api/status');

        $this->assertResponseStatusCodeSame(401);
    }

    public function testProtectedApiReturns401WithInvalidToken(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('GET', '/api/status', [], [], [
            'HTTP_AUTHORIZATION' => 'Bearer this-is-not-a-valid-jwt',
        ]);

        $this->assertResponseStatusCodeSame(401);
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('invalid_token', $data['error']);
    }

    public function testProtectedApiReturns401WithExpiredToken(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('GET', '/api/status', [], [], [
            'HTTP_AUTHORIZATION' => 'Bearer ' . self::createExpiredAccessToken(),
        ]);

        $this->assertResponseStatusCodeSame(401);
    }

    public function testProtectedApiReturns401WithWrongIssuer(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('GET', '/api/status', [], [], [
            'HTTP_AUTHORIZATION' => 'Bearer ' . self::createTokenWithWrongIssuer(),
        ]);

        $this->assertResponseStatusCodeSame(401);
    }

    public function testProtectedApiSucceedsWithValidToken(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('GET', '/api/status', [], [], self::authHeaders());

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('ok', $data['status']);
    }

    public function testHealthEndpointIsPublicWithoutToken(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('GET', '/api/health');

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertSame('ok', $data['status']);
    }

    public function testApiDocsIsPublicWithoutToken(): void
    {
        $client = static::createClient();

        $client->request('GET', '/api/docs');

        $this->assertResponseIsSuccessful();
    }

    public function testApiDocsAccessibleWithToken(): void
    {
        $client = static::createClient();

        $client->request('GET', '/api/docs', [], [], self::authHeaders());

        $this->assertResponseIsSuccessful();
    }

    public function testTokenEndpointAccessibleWithoutToken(): void
    {
        $client = static::createClient();

        $client->request('POST', '/token', [
            'grant_type' => 'client_credentials',
        ]);

        // 400 because client_assertion is missing, but NOT 401
        $this->assertResponseStatusCodeSame(400);
    }

    public function testTokenCreatorPageAccessibleWithoutToken(): void
    {
        $client = static::createClient();

        $client->request('GET', '/token/creator');

        $this->assertResponseIsSuccessful();
    }
}
