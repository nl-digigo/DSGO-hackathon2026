<?php

declare(strict_types=1);

namespace App\Tests\Functional\Api;

use App\Entity\PolicyRule;
use App\Tests\Support\DatabaseTestTrait;
use App\Tests\Support\JwtTestHelper;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class EvaluationTest extends WebTestCase
{
    use DatabaseTestTrait;
    use JwtTestHelper;

    private static function createPolicy(
        EntityManagerInterface $em,
        string $subject,
        string $resource,
        string $action,
        ?string $serviceProvider = null,
        ?string $method = null,
        ?string $license = null,
        ?array $partialContext = null,
    ): void {
        $policy = new PolicyRule();
        $policy->setV0($subject);
        $policy->setV1($resource);
        $policy->setV2($action);
        $policy->setV3($serviceProvider);
        $policy->setV4($method);
        $policy->setV5($license);
        $policy->setPartialContext($partialContext);
        $em->persist($policy);
        $em->flush();
    }

    public function testFullPermit(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy($em, 'EU.EORI.NL000000001', '/products', 'can_read');

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertTrue($data['decision']);
    }

    public function testDenyWithReasons(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertFalse($data['decision']);
        $this->assertArrayHasKey('context', $data);
        $this->assertArrayHasKey('reason_admin', $data['context']);
        $this->assertArrayHasKey('reason_user', $data['context']);
    }

    public function testPartialPermit(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy(
            $em,
            'EU.EORI.NL000000001',
            '/products',
            'can_read',
            partialContext: ['identifiers' => ['PRODUCT001'], 'attributes' => ['PRODUCT.WEIGHT']],
        );

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertTrue($data['decision']);
        $this->assertArrayHasKey('resource', $data['context']);
        $this->assertEquals(['PRODUCT001'], $data['context']['resource']['properties']['identifiers']);
    }

    public function testValidationError(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'INVALID-ID'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseStatusCodeSame(422);
    }

    public function testPropertyFiltering(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy(
            $em,
            'EU.EORI.NL000000001',
            '/products',
            'can_read',
            serviceProvider: 'EU.EORI.NL000000002',
            method: 'GET',
            license: 'DSGO.0001',
        );

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'EU.EORI.NL000000002']],
            'action' => ['name' => 'can_read', 'properties' => ['method' => 'GET', 'license' => 'DSGO.0001']],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertTrue($data['decision']);
    }

    public function testCorrelationIdIsReturnedInResponse(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy($em, 'EU.EORI.NL000000001', '/products', 'can_read');

        $client->request('POST', '/api/evaluation', [], [], array_merge(self::jsonAuthHeaders(), [
            'HTTP_X-Correlation-Id' => 'test-corr-123',
        ]), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseIsSuccessful();
        $this->assertSame('test-corr-123', $client->getResponse()->headers->get('X-Correlation-Id'));
    }

    public function testCorrelationIdIsGeneratedWhenMissing(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy($em, 'EU.EORI.NL000000001', '/products', 'can_read');

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseIsSuccessful();
        $correlationId = $client->getResponse()->headers->get('X-Correlation-Id');
        $this->assertNotNull($correlationId);
        $this->assertNotEmpty($correlationId);
    }

    public function testPropertyMismatchReturnsDeny(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);
        self::createPolicy(
            $em,
            'EU.EORI.NL000000001',
            '/products',
            'can_read',
            serviceProvider: 'EU.EORI.NL000000002',
        );

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'EU.EORI.NL000000099']],
            'action' => ['name' => 'can_read'],
        ]));

        $this->assertResponseIsSuccessful();
        $data = json_decode($client->getResponse()->getContent(), true);
        $this->assertFalse($data['decision']);
    }

    public function testInvalidActionReturnsValidationError(): void
    {
        $client = static::createClient();
        $em = static::getContainer()->get(EntityManagerInterface::class);
        self::ensureSchema($em);

        $client->request('POST', '/api/evaluation', [], [], self::jsonAuthHeaders(), json_encode([
            'subject' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
            'resource' => ['type' => 'api', 'id' => '/products'],
            'action' => ['name' => 'invalid_action'],
        ]));

        $this->assertResponseStatusCodeSame(422);
    }
}
