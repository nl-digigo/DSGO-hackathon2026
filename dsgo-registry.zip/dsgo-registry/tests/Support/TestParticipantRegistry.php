<?php

declare(strict_types=1);

namespace App\Tests\Support;

use App\Service\Registry\ParticipantRegistryInterface;

/**
 * Participant registry for functional tests.
 * Validates against a fixed set of known demo participants,
 * rejecting any unknown party — just like the real Digigo registry would.
 */
final class TestParticipantRegistry implements ParticipantRegistryInterface
{
    private const REGISTERED_PARTICIPANTS = [
        'EU.EORI.NL000000001',                // Bedrijf A
        'EU.EORI.NL000000002',                // Bedrijf B
        'EU.EORI.NL000000003',                // Bedrijf C
        'EU.EORI.NL000000004',                // Bedrijf D (delegatieketen)
        'EU.EORI.NL000000099',                // Test service provider
        'EU.EORI.NL999999999',                // Test bedrijf
        'NTRNL-99999999',                     // iSHARE test party (server, short)
        'NTRNL-99999998',                     // iSHARE test party (client, short)
        'did:ishare:EU.NL.NTRNL-99999999',   // iSHARE test party (server, DID)
        'did:ishare:EU.NL.NTRNL-99999998',   // iSHARE test party (client, DID)
    ];

    public function isValidParticipant(string $participantId): bool
    {
        return in_array($participantId, self::REGISTERED_PARTICIPANTS, true);
    }
}
