<?php

declare(strict_types=1);

namespace App\Tests\Support;

use App\Controller\TokenController;
use App\Util\JwtKeyPaths;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;

trait JwtTestHelper
{
    private static function jwtConfig(): Configuration
    {
        $privateKey = InMemory::file(JwtKeyPaths::PRIVATE_KEY, '');
        return Configuration::forSymmetricSigner(new Sha256(), $privateKey);
    }

    protected static function createValidAccessToken(string $clientId = 'test-client-id'): string
    {
        $config = self::jwtConfig();
        $now = new \DateTimeImmutable('now', new \DateTimeZone('europe/amsterdam'));

        return $config->builder()
            ->issuedBy(TokenController::clientId)
            ->permittedFor(TokenController::clientId)
            ->withClaim('client_id', $clientId)
            ->expiresAt($now->add(new \DateInterval('PT1H')))
            ->issuedAt($now)
            ->canOnlyBeUsedAfter($now)
            ->withClaim('scope', ['iSHARE'])
            ->getToken($config->signer(), $config->signingKey())
            ->toString();
    }

    protected static function createExpiredAccessToken(string $clientId = 'test-client-id'): string
    {
        $config = self::jwtConfig();
        $past = new \DateTimeImmutable('-2 hours', new \DateTimeZone('europe/amsterdam'));

        return $config->builder()
            ->issuedBy(TokenController::clientId)
            ->permittedFor(TokenController::clientId)
            ->withClaim('client_id', $clientId)
            ->expiresAt($past->add(new \DateInterval('PT1H')))
            ->issuedAt($past)
            ->canOnlyBeUsedAfter($past)
            ->withClaim('scope', ['iSHARE'])
            ->getToken($config->signer(), $config->signingKey())
            ->toString();
    }

    protected static function createTokenWithWrongIssuer(string $clientId = 'test-client-id'): string
    {
        $config = self::jwtConfig();
        $now = new \DateTimeImmutable('now', new \DateTimeZone('europe/amsterdam'));

        return $config->builder()
            ->issuedBy('wrong-issuer')
            ->permittedFor(TokenController::clientId)
            ->withClaim('client_id', $clientId)
            ->expiresAt($now->add(new \DateInterval('PT1H')))
            ->issuedAt($now)
            ->canOnlyBeUsedAfter($now)
            ->getToken($config->signer(), $config->signingKey())
            ->toString();
    }

    protected static function authHeaders(?string $token = null): array
    {
        $token = $token ?? static::createValidAccessToken();
        return ['HTTP_AUTHORIZATION' => 'Bearer ' . $token];
    }

    protected static function jsonAuthHeaders(?string $token = null): array
    {
        return array_merge(
            ['CONTENT_TYPE' => 'application/json'],
            static::authHeaders($token),
        );
    }
}
