<?php

declare(strict_types=1);

namespace App\Tests\Unit\Dto;

use App\Dto\Action;
use App\Dto\EvaluationRequest;
use App\Dto\Resource;
use App\Dto\Subject;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\Validation;

class EvaluationRequestTest extends TestCase
{
    private $validator;

    protected function setUp(): void
    {
        $this->validator = Validation::createValidatorBuilder()
            ->enableAttributeMapping()
            ->getValidator();
    }

    public function testValidRequest(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $violations = $this->validator->validate($request);
        $this->assertCount(0, $violations);
    }

    public function testNullSubjectIsInvalid(): void
    {
        $request = new EvaluationRequest(
            subject: null,
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $violations = $this->validator->validate($request);
        $this->assertGreaterThan(0, count($violations));
    }

    public function testFullRequestWithProperties(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(
                type: 'service-consumer',
                id: 'EU.EORI.NL000000001',
            ),
            resource: new Resource(
                type: 'api',
                id: '/products',
                properties: ['service_provider' => 'EU.EORI.NL000000002'],
            ),
            action: new Action(
                name: 'can_read',
                properties: ['method' => 'GET', 'license' => 'DSGO.0001'],
            ),
            context: ['time' => '2026-02-26T10:00:00+01:00'],
        );
        $violations = $this->validator->validate($request);
        $this->assertCount(0, $violations);
    }
}
