<?php

declare(strict_types=1);

namespace App\Tests\Unit\Dto;

use App\Dto\Resource;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\Validation;

class ResourceTest extends TestCase
{
    private $validator;

    protected function setUp(): void
    {
        $this->validator = Validation::createValidatorBuilder()
            ->enableAttributeMapping()
            ->getValidator();
    }

    public function testValidResource(): void
    {
        $resource = new Resource(type: 'api', id: '/products');
        $violations = $this->validator->validate($resource);
        $this->assertCount(0, $violations);
    }

    public function testBlankTypeIsInvalid(): void
    {
        $resource = new Resource(type: '', id: '/products');
        $violations = $this->validator->validate($resource);
        $this->assertGreaterThan(0, count($violations));
    }

    public function testBlankIdIsInvalid(): void
    {
        $resource = new Resource(type: 'api', id: '');
        $violations = $this->validator->validate($resource);
        $this->assertGreaterThan(0, count($violations));
    }

    public function testResourceWithProperties(): void
    {
        $resource = new Resource(
            type: 'api',
            id: '/products',
            properties: ['service_provider' => 'EU.EORI.NL000000002'],
        );
        $violations = $this->validator->validate($resource);
        $this->assertCount(0, $violations);
        $this->assertEquals('EU.EORI.NL000000002', $resource->properties['service_provider']);
    }

    public function testResourceWithNullProperties(): void
    {
        $resource = new Resource(type: 'api', id: '/products', properties: null);
        $violations = $this->validator->validate($resource);
        $this->assertCount(0, $violations);
        $this->assertNull($resource->properties);
    }
}
