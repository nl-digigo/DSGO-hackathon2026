<?php

declare(strict_types=1);

namespace App\Tests\Unit\Dto;

use App\Dto\Action;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\Validation;

class ActionTest extends TestCase
{
    private $validator;

    protected function setUp(): void
    {
        $this->validator = Validation::createValidatorBuilder()
            ->enableAttributeMapping()
            ->getValidator();
    }

    public function testValidActions(): void
    {
        foreach (Action::VALID_NAMES as $name) {
            $action = new Action(name: $name);
            $violations = $this->validator->validate($action);
            $this->assertCount(0, $violations, "Action '$name' should be valid");
        }
    }

    public function testInvalidAction(): void
    {
        $action = new Action(name: 'invalid_action');
        $violations = $this->validator->validate($action);
        $this->assertGreaterThan(0, count($violations));
    }

    public function testActionWithProperties(): void
    {
        $action = new Action(
            name: 'can_read',
            properties: ['method' => 'GET', 'license' => 'DSGO.0001'],
        );
        $violations = $this->validator->validate($action);
        $this->assertCount(0, $violations);
        $this->assertEquals('GET', $action->properties['method']);
        $this->assertEquals('DSGO.0001', $action->properties['license']);
    }
}
