<?php

declare(strict_types=1);

namespace App\Tests\Unit\Dto;

use App\Dto\Subject;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Validator\Validation;

class SubjectTest extends TestCase
{
    private $validator;

    protected function setUp(): void
    {
        $this->validator = Validation::createValidatorBuilder()
            ->enableAttributeMapping()
            ->getValidator();
    }

    public function testValidSubject(): void
    {
        $subject = new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001');
        $violations = $this->validator->validate($subject);
        $this->assertCount(0, $violations);
    }

    public function testInvalidEoriFormat(): void
    {
        $subject = new Subject(type: 'service-consumer', id: 'invalid-id');
        $violations = $this->validator->validate($subject);
        $this->assertGreaterThan(0, count($violations));
    }

    public function testBlankTypeIsInvalid(): void
    {
        $subject = new Subject(type: '', id: 'EU.EORI.NL000000001');
        $violations = $this->validator->validate($subject);
        $this->assertGreaterThan(0, count($violations));
    }

    public function testSubjectWithDelegationProperties(): void
    {
        $subject = new Subject(
            type: 'service-consumer',
            id: 'EU.EORI.NL000000003',
            properties: [
                'delegation' => [
                    'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
                    'license' => 'DSGO.0008',
                    'url' => 'https://api.example.com/delegations/1',
                ],
            ],
        );
        $violations = $this->validator->validate($subject);
        $this->assertCount(0, $violations);
        $this->assertArrayHasKey('delegation', $subject->properties);
    }
}
