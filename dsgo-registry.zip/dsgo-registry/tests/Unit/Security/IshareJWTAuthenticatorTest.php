<?php

declare(strict_types=1);

namespace App\Tests\Unit\Security;

use App\Security\IshareJWTAuthenticator;
use App\Tests\Support\JwtTestHelper;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Exception\AuthenticationException;

class IshareJWTAuthenticatorTest extends TestCase
{
    use JwtTestHelper;

    private IshareJWTAuthenticator $authenticator;

    protected function setUp(): void
    {
        $this->authenticator = new IshareJWTAuthenticator();
    }

    public function testSupportsApiRequestWithAuthorizationHeader(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('Authorization', 'Bearer some-token');

        $this->assertTrue($this->authenticator->supports($request));
    }

    public function testDoesNotSupportApiRequestWithoutAuthorizationHeader(): void
    {
        $request = Request::create('/api/evaluation', 'POST');

        $this->assertFalse($this->authenticator->supports($request));
    }

    public function testDoesNotSupportNonApiRequest(): void
    {
        $request = Request::create('/admin/policies', 'GET');
        $request->headers->set('Authorization', 'Bearer some-token');

        $this->assertFalse($this->authenticator->supports($request));
    }

    public function testDoesNotSupportTokenEndpoint(): void
    {
        $request = Request::create('/token', 'POST');
        $request->headers->set('Authorization', 'Bearer some-token');

        $this->assertFalse($this->authenticator->supports($request));
    }

    public function testAuthenticateWithValidToken(): void
    {
        $clientId = 'did:ishare:EU.NL.NTRNL-12345678';
        $jwt = self::createValidAccessToken($clientId);
        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('Authorization', 'Bearer ' . $jwt);

        $passport = $this->authenticator->authenticate($request);

        $this->assertSame($clientId, $passport->getUser()->getUserIdentifier());
        $this->assertContains('ROLE_CLIENT', $passport->getUser()->getRoles());
    }

    public function testAuthenticateThrowsOnMissingBearerPrefix(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('Authorization', 'Basic abc123');

        $this->expectException(AuthenticationException::class);
        $this->expectExceptionMessage('Missing bearer token');
        $this->authenticator->authenticate($request);
    }

    public function testAuthenticateThrowsOnExpiredToken(): void
    {
        $jwt = self::createExpiredAccessToken();
        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('Authorization', 'Bearer ' . $jwt);

        $this->expectException(AuthenticationException::class);
        $this->expectExceptionMessage('Token validation failed');
        $this->authenticator->authenticate($request);
    }

    public function testAuthenticateThrowsOnWrongIssuer(): void
    {
        $jwt = self::createTokenWithWrongIssuer();
        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('Authorization', 'Bearer ' . $jwt);

        $this->expectException(AuthenticationException::class);
        $this->expectExceptionMessage('Token validation failed');
        $this->authenticator->authenticate($request);
    }

    public function testAuthenticateThrowsOnMalformedToken(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('Authorization', 'Bearer not-a-valid-jwt');

        $this->expectException(AuthenticationException::class);
        $this->authenticator->authenticate($request);
    }

    public function testOnAuthenticationSuccessReturnsNull(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $token = $this->createMock(\Symfony\Component\Security\Core\Authentication\Token\TokenInterface::class);

        $result = $this->authenticator->onAuthenticationSuccess($request, $token, 'api');

        $this->assertNull($result);
    }

    public function testOnAuthenticationFailureReturns401Json(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $exception = new AuthenticationException('Test failure');

        $response = $this->authenticator->onAuthenticationFailure($request, $exception);

        $this->assertSame(401, $response->getStatusCode());
        $data = json_decode($response->getContent(), true);
        $this->assertSame('invalid_token', $data['error']);
        $this->assertSame('Test failure', $data['message']);
    }
}
