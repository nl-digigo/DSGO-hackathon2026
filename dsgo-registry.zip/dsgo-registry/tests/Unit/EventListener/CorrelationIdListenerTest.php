<?php

declare(strict_types=1);

namespace App\Tests\Unit\EventListener;

use App\EventListener\CorrelationIdListener;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\HttpKernel\KernelInterface;

class CorrelationIdListenerTest extends TestCase
{
    private CorrelationIdListener $listener;
    private KernelInterface $kernel;

    protected function setUp(): void
    {
        $this->listener = new CorrelationIdListener();
        $this->kernel = $this->createMock(KernelInterface::class);
    }

    public function testGeneratesCorrelationIdWhenMissing(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $event = new RequestEvent($this->kernel, $request, HttpKernelInterface::MAIN_REQUEST);

        $this->listener->onKernelRequest($event);

        $correlationId = $request->attributes->get('correlation_id');
        $this->assertNotNull($correlationId);
        $this->assertMatchesRegularExpression(
            '/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/',
            $correlationId,
        );
    }

    public function testPreservesExistingCorrelationId(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('X-Correlation-Id', 'my-custom-id');
        $event = new RequestEvent($this->kernel, $request, HttpKernelInterface::MAIN_REQUEST);

        $this->listener->onKernelRequest($event);

        $this->assertSame('my-custom-id', $request->attributes->get('correlation_id'));
    }

    public function testAddsCorrelationIdToResponse(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $request->attributes->set('correlation_id', 'test-id-123');
        $response = new Response();
        $event = new ResponseEvent($this->kernel, $request, HttpKernelInterface::MAIN_REQUEST, $response);

        $this->listener->onKernelResponse($event);

        $this->assertSame('test-id-123', $response->headers->get('X-Correlation-Id'));
    }

    public function testIgnoresSubRequests(): void
    {
        $request = Request::create('/api/evaluation', 'POST');
        $event = new RequestEvent($this->kernel, $request, HttpKernelInterface::SUB_REQUEST);

        $this->listener->onKernelRequest($event);

        $this->assertNull($request->attributes->get('correlation_id'));
    }
}
