<?php

declare(strict_types=1);

namespace App\Tests\Unit\Evidence;

use App\Dto\Action;
use App\Dto\EvaluationRequest;
use App\Dto\EvaluationResponse;
use App\Dto\Resource;
use App\Dto\Subject;
use App\Evidence\CanonicalDecisionPayload;
use PHPUnit\Framework\TestCase;

class CanonicalDecisionPayloadTest extends TestCase
{
    public function testFromPermitEvaluation(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $response = new EvaluationResponse(decision: true);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response, 'corr-123');

        $this->assertSame('corr-123', $payload->correlationId);
        $this->assertSame('EU.EORI.NL000000001', $payload->subjectId);
        $this->assertSame('/products', $payload->resourceId);
        $this->assertSame('can_read', $payload->actionName);
        $this->assertSame('permit', $payload->decision);
        $this->assertNull($payload->partialContext);
        $this->assertNull($payload->delegationIssuer);
    }

    public function testFromDenyEvaluation(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $response = new EvaluationResponse(decision: false, context: [
            'reason_admin' => ['en' => 'No matching policy found'],
        ]);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response);

        $this->assertSame('deny', $payload->decision);
        $this->assertSame('', $payload->correlationId);
    }

    public function testFromDelegationEvaluation(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(
                type: 'service-consumer',
                id: 'EU.EORI.NL000000003',
                properties: [
                    'delegation' => [
                        'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
                        'license' => 'DSGO.0008',
                    ],
                ],
            ),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $response = new EvaluationResponse(decision: true);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response);

        $this->assertSame('EU.EORI.NL000000001', $payload->delegationIssuer);
    }

    public function testFromPartialPermitEvaluation(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $response = new EvaluationResponse(decision: true, context: [
            'resource' => [
                'type' => 'api',
                'id' => '/products',
                'properties' => ['identifiers' => ['P001']],
            ],
        ]);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response);

        $this->assertSame('permit', $payload->decision);
        $this->assertEquals(['identifiers' => ['P001']], $payload->partialContext);
    }

    public function testCanonicalJsonIsConsistent(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $response = new EvaluationResponse(decision: true);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response, 'c-1');

        $json = $payload->toCanonicalJson();
        $decoded = json_decode($json, true);

        $this->assertSame('can_read', $decoded['action_name']);
        $this->assertSame('c-1', $decoded['correlation_id']);
        $this->assertSame('permit', $decoded['decision']);
        $this->assertArrayHasKey('timestamp', $decoded);
    }

    public function testHashIsDeterministic(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $response = new EvaluationResponse(decision: true);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response, 'c-1');

        $hash = $payload->getHash();

        $this->assertSame(64, strlen($hash));
        $this->assertSame($hash, $payload->getHash());
    }

    public function testToArrayContainsAllFields(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
        $response = new EvaluationResponse(decision: true);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response, 'c-1');
        $arr = $payload->toArray();

        $this->assertArrayHasKey('correlationId', $arr);
        $this->assertArrayHasKey('timestamp', $arr);
        $this->assertArrayHasKey('subjectId', $arr);
        $this->assertArrayHasKey('resourceId', $arr);
        $this->assertArrayHasKey('actionName', $arr);
        $this->assertArrayHasKey('decision', $arr);
        $this->assertArrayHasKey('partialContext', $arr);
        $this->assertArrayHasKey('delegationIssuer', $arr);
    }
}
