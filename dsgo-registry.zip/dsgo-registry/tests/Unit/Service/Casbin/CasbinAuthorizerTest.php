<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Casbin;

use App\Entity\PolicyRule;
use App\Repository\PolicyRuleRepository;
use App\Service\Casbin\CasbinAuthorizer;
use App\Service\Casbin\EnforcerFactory;
use Casbin\Enforcer;
use PHPUnit\Framework\TestCase;

class CasbinAuthorizerTest extends TestCase
{
    public function testIsPermittedReturnsTrue(): void
    {
        $enforcer = $this->createMock(Enforcer::class);
        $enforcer->method('enforce')
            ->with('EU.EORI.NL000000001', '/products', 'can_read')
            ->willReturn(true);

        $factory = $this->createMock(EnforcerFactory::class);
        $factory->method('getEnforcer')->willReturn($enforcer);

        $repo = $this->createMock(PolicyRuleRepository::class);

        $authorizer = new CasbinAuthorizer($factory, $repo);

        $this->assertTrue($authorizer->isPermitted('EU.EORI.NL000000001', '/products', 'can_read'));
    }

    public function testIsPermittedReturnsFalse(): void
    {
        $enforcer = $this->createMock(Enforcer::class);
        $enforcer->method('enforce')->willReturn(false);

        $factory = $this->createMock(EnforcerFactory::class);
        $factory->method('getEnforcer')->willReturn($enforcer);

        $repo = $this->createMock(PolicyRuleRepository::class);

        $authorizer = new CasbinAuthorizer($factory, $repo);

        $this->assertFalse($authorizer->isPermitted('EU.EORI.NL000000001', '/products', 'can_delete'));
    }

    public function testGetMatchingPoliciesReturnsEntities(): void
    {
        $enforcer = $this->createMock(Enforcer::class);
        $enforcer->method('enforce')->willReturn(true);

        $factory = $this->createMock(EnforcerFactory::class);
        $factory->method('getEnforcer')->willReturn($enforcer);

        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');

        $repo = $this->createMock(PolicyRuleRepository::class);
        $repo->method('findBySubjectAndAction')->willReturn([$policy]);

        $authorizer = new CasbinAuthorizer($factory, $repo);

        $result = $authorizer->getMatchingPolicies('EU.EORI.NL000000001', '/products', 'can_read');
        $this->assertCount(1, $result);
        $this->assertSame('EU.EORI.NL000000001', $result[0]->getSubject());
    }

    public function testGetMatchingPoliciesFiltersResourceByKeyMatch2(): void
    {
        $enforcer = $this->createMock(Enforcer::class);
        $enforcer->method('enforce')->willReturn(true);

        $factory = $this->createMock(EnforcerFactory::class);
        $factory->method('getEnforcer')->willReturn($enforcer);

        $matching = new PolicyRule();
        $matching->setV0('EU.EORI.NL000000001');
        $matching->setV1('/products');
        $matching->setV2('can_read');

        $nonMatching = new PolicyRule();
        $nonMatching->setV0('EU.EORI.NL000000001');
        $nonMatching->setV1('/orders');
        $nonMatching->setV2('can_read');

        $repo = $this->createMock(PolicyRuleRepository::class);
        $repo->method('findBySubjectAndAction')->willReturn([$matching, $nonMatching]);

        $authorizer = new CasbinAuthorizer($factory, $repo);

        $result = $authorizer->getMatchingPolicies('EU.EORI.NL000000001', '/products', 'can_read');
        $this->assertCount(1, $result);
        $this->assertSame('/products', $result[0]->getResource());
    }

    public function testGetMatchingPoliciesReturnsEmptyWhenDenied(): void
    {
        $enforcer = $this->createMock(Enforcer::class);
        $enforcer->method('enforce')->willReturn(false);

        $factory = $this->createMock(EnforcerFactory::class);
        $factory->method('getEnforcer')->willReturn($enforcer);

        $repo = $this->createMock(PolicyRuleRepository::class);

        $authorizer = new CasbinAuthorizer($factory, $repo);

        $result = $authorizer->getMatchingPolicies('EU.EORI.NL000000001', '/products', 'can_read');
        $this->assertEmpty($result);
    }
}
