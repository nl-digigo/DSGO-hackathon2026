<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service;

use App\Service\Registry\ParticipantRegistryService;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

class ParticipantRegistryServiceTest extends TestCase
{
    private function createService(array $responses): ParticipantRegistryService
    {
        $httpClient = new MockHttpClient($responses);
        return new ParticipantRegistryService($httpClient);
    }

    public function testValidateOrganisationReturnsTrueForActiveServiceConsumer(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        $partyResponse = new MockResponse(json_encode([
            'id' => 'did:ishare:EU.NL.NTRNL-99999998',
            'name' => 'Test Organization',
            'claims' => [
                [
                    'type' => 'dataspaceMembership',
                    'status' => 'Active',
                    'dataspaceId' => 'EU.DS.NL.DSGO',
                ],
                [
                    'type' => 'dataspaceRole',
                    'status' => 'Active',
                    'roleId' => 'ServiceConsumer',
                ],
            ],
        ]), ['http_code' => 200]);

        $service = $this->createService([$tokenResponse, $partyResponse]);
        $this->assertTrue($service->validateOrganisation('NTRNL-99999998'));
    }

    public function testValidateOrganisationReturnsFalseWhenPartyNotFound(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        $partyResponse = new MockResponse('', ['http_code' => 404]);

        $service = $this->createService([$tokenResponse, $partyResponse]);
        $this->assertFalse($service->validateOrganisation('NTRNL-00000000'));
    }

    public function testValidateOrganisationReturnsFalseWhenNoServiceConsumerRole(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        // Not a TEST_PARTY_IDS id: ServiceConsumer is mandatory alongside active membership.
        $partyResponse = new MockResponse(json_encode([
            'id' => 'did:ishare:EU.NL.NTRNL-17162509',
            'name' => 'Provider Only Org',
            'claims' => [
                [
                    'type' => 'dataspaceMembership',
                    'status' => 'Active',
                    'dataspaceId' => 'EU.DS.NL.DSGO',
                ],
                [
                    'type' => 'dataspaceRole',
                    'status' => 'Active',
                    'roleId' => 'ServiceProvider',
                ],
            ],
        ]), ['http_code' => 200]);

        $service = $this->createService([$tokenResponse, $partyResponse]);
        $this->assertFalse($service->validateOrganisation('NTRNL-17162509'));
    }

    public function testValidateOrganisationTestPartyAcceptsActiveMembershipWithoutServiceConsumerRole(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        $partyResponse = new MockResponse(json_encode([
            'id' => 'did:ishare:EU.NL.NTRNL-99999998',
            'name' => 'dsgotestclient',
            'claims' => [
                [
                    'type' => 'dataspaceMembership',
                    'status' => 'Active',
                    'dataspaceId' => 'EU.DS.NL.DSGO',
                ],
            ],
        ]), ['http_code' => 200]);

        $service = $this->createService([$tokenResponse, $partyResponse]);
        $this->assertTrue($service->validateOrganisation('NTRNL-99999998'));
    }

    public function testValidateOrganisationReturnsFalseWhenMembershipNotActive(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        $partyResponse = new MockResponse(json_encode([
            'id' => 'did:ishare:EU.NL.NTRNL-99999998',
            'name' => 'Revoked Org',
            'claims' => [
                [
                    'type' => 'dataspaceMembership',
                    'status' => 'Revoked',
                    'dataspaceId' => 'EU.DS.NL.DSGO',
                ],
                [
                    'type' => 'dataspaceRole',
                    'status' => 'Active',
                    'roleId' => 'ServiceConsumer',
                ],
            ],
        ]), ['http_code' => 200]);

        $service = $this->createService([$tokenResponse, $partyResponse]);
        $this->assertFalse($service->validateOrganisation('NTRNL-99999998'));
    }

    public function testValidateOrganisationReturnsFalseWhenNoClaims(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        $partyResponse = new MockResponse(json_encode([
            'id' => 'did:ishare:EU.NL.NTRNL-99999998',
            'name' => 'Empty Claims Org',
            'claims' => [],
        ]), ['http_code' => 200]);

        $service = $this->createService([$tokenResponse, $partyResponse]);
        $this->assertFalse($service->validateOrganisation('NTRNL-99999998'));
    }

    public function testValidateOrganisationThrowsOnDigigoAuthFailure(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'error' => 'invalid_request',
            'error_description' => 'Invalid client_id parameter value.',
        ]), ['http_code' => 400]);

        $service = $this->createService([$tokenResponse]);

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessageMatches('/Digigo auth failed/');
        $service->validateOrganisation('NTRNL-99999998');
    }

    public function testValidateOrganisationThrowsOnPartiesApiError(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        $partyResponse = new MockResponse('Internal Server Error', ['http_code' => 500]);

        $service = $this->createService([$tokenResponse, $partyResponse]);

        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessageMatches('/Digigo parties lookup failed/');
        $service->validateOrganisation('NTRNL-99999998');
    }

    public function testValidateOrganisationAcceptsDidFormat(): void
    {
        $tokenResponse = new MockResponse(json_encode([
            'access_token' => 'mock-digigo-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ]), ['http_code' => 200]);

        $partyResponse = new MockResponse(json_encode([
            'id' => 'did:ishare:EU.NL.NTRNL-99999998',
            'name' => 'Test Org',
            'claims' => [
                ['type' => 'dataspaceMembership', 'status' => 'Active', 'dataspaceId' => 'EU.DS.NL.DSGO'],
                ['type' => 'dataspaceRole', 'status' => 'Active', 'roleId' => 'ServiceConsumer'],
            ],
        ]), ['http_code' => 200]);

        $service = $this->createService([$tokenResponse, $partyResponse]);
        $this->assertTrue($service->validateOrganisation('did:ishare:EU.NL.NTRNL-99999998'));
    }
}
