<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Evaluation;

use App\Entity\PolicyRule;
use App\Service\Evaluation\PropertyMatcher;
use PHPUnit\Framework\TestCase;

class PropertyMatcherTest extends TestCase
{
    private PropertyMatcher $matcher;

    protected function setUp(): void
    {
        $this->matcher = new PropertyMatcher();
    }

    public function testMatchesWhenNoPropertiesOnPolicy(): void
    {
        $policy = new PolicyRule();
        $result = $this->matcher->match([$policy], []);
        $this->assertCount(1, $result['matched']);
        $this->assertNull($result['partialContext']);
    }

    public function testMatchesExactProperties(): void
    {
        $policy = new PolicyRule();
        $policy->setServiceProvider('EU.EORI.NL000000002');
        $policy->setMethod('GET');
        $policy->setLicense('DSGO.0001');

        $result = $this->matcher->match([$policy], [
            'service_provider' => 'EU.EORI.NL000000002',
            'method' => 'GET',
            'license' => 'DSGO.0001',
        ]);

        $this->assertCount(1, $result['matched']);
    }

    public function testWildcardMatches(): void
    {
        $policy = new PolicyRule();
        $policy->setServiceProvider('*');
        $policy->setMethod('*');
        $policy->setLicense('*');

        $result = $this->matcher->match([$policy], [
            'service_provider' => 'EU.EORI.NL000000002',
            'method' => 'POST',
            'license' => 'DSGO.9999',
        ]);

        $this->assertCount(1, $result['matched']);
    }

    public function testMismatchRejectsPolicy(): void
    {
        $policy = new PolicyRule();
        $policy->setServiceProvider('EU.EORI.NL000000002');
        $policy->setMethod('GET');
        $policy->setLicense('DSGO.0001');

        $result = $this->matcher->match([$policy], [
            'service_provider' => 'EU.EORI.NL000000002',
            'method' => 'POST',
            'license' => 'DSGO.0001',
        ]);

        $this->assertCount(0, $result['matched']);
    }

    public function testPartialContextIsReturned(): void
    {
        $policy = new PolicyRule();
        $policy->setPartialContext([
            'identifiers' => ['PRODUCT001'],
            'attributes' => ['PRODUCT.WEIGHT', 'PRODUCT.PRICE'],
        ]);

        $result = $this->matcher->match([$policy], []);

        $this->assertCount(1, $result['matched']);
        $this->assertEquals(['PRODUCT001'], $result['partialContext']['identifiers']);
        $this->assertEquals(['PRODUCT.WEIGHT', 'PRODUCT.PRICE'], $result['partialContext']['attributes']);
    }

    public function testMethodMatchIsCaseInsensitive(): void
    {
        $policy = new PolicyRule();
        $policy->setMethod('GET');

        $result = $this->matcher->match([$policy], ['method' => 'get']);
        $this->assertCount(1, $result['matched']);
    }

    public function testPartialContextMergesAcrossMultiplePolicies(): void
    {
        $policy1 = new PolicyRule();
        $policy1->setPartialContext([
            'identifiers' => ['P001'],
            'attributes' => ['WEIGHT'],
        ]);

        $policy2 = new PolicyRule();
        $policy2->setPartialContext([
            'identifiers' => ['P002'],
            'attributes' => ['PRICE'],
        ]);

        $result = $this->matcher->match([$policy1, $policy2], []);

        $this->assertCount(2, $result['matched']);
        $this->assertEquals(['P001', 'P002'], $result['partialContext']['identifiers']);
        $this->assertEquals(['WEIGHT', 'PRICE'], $result['partialContext']['attributes']);
    }

    public function testNullRequestPropertyMatchesAnyPolicyValue(): void
    {
        $policy = new PolicyRule();
        $policy->setServiceProvider('EU.EORI.NL000000002');
        $policy->setMethod('GET');

        $result = $this->matcher->match([$policy], []);
        $this->assertCount(1, $result['matched']);
    }

    public function testMultiplePoliciesOnlyMatchingOnesReturned(): void
    {
        $matching = new PolicyRule();
        $matching->setServiceProvider('EU.EORI.NL000000002');

        $nonMatching = new PolicyRule();
        $nonMatching->setServiceProvider('EU.EORI.NL000000099');

        $result = $this->matcher->match([$matching, $nonMatching], [
            'service_provider' => 'EU.EORI.NL000000002',
        ]);

        $this->assertCount(1, $result['matched']);
        $this->assertSame('EU.EORI.NL000000002', $result['matched'][0]->getServiceProvider());
    }
}
