<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Evaluation;

use App\Dto\Action;
use App\Dto\EvaluationRequest;
use App\Dto\Resource;
use App\Dto\Subject;
use App\Entity\PolicyRule;
use App\Service\Casbin\CasbinAuthorizer;
use App\Service\Delegation\DelegationService;
use App\Service\Evaluation\EvaluationService;
use App\Service\Evaluation\PropertyMatcher;
use App\Service\Evaluation\RequestMapper;
use App\Service\Evaluation\ResponseBuilder;
use PHPUnit\Framework\TestCase;

class EvaluationServiceTest extends TestCase
{
    private EvaluationService $service;
    private CasbinAuthorizer $authorizer;
    private DelegationService $delegationService;

    protected function setUp(): void
    {
        $this->authorizer = $this->createMock(CasbinAuthorizer::class);
        $this->delegationService = $this->createMock(DelegationService::class);

        $this->service = new EvaluationService(
            new RequestMapper(),
            $this->authorizer,
            new PropertyMatcher(),
            $this->delegationService,
            new ResponseBuilder(),
        );
    }

    public function testPermitWhenPolicyMatches(): void
    {
        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');

        $this->authorizer->method('getMatchingPolicies')->willReturn([$policy]);
        $this->delegationService->method('validateDelegation')->willReturn(null);

        $request = $this->createRequest();
        $response = $this->service->evaluate($request);

        $this->assertTrue($response->decision);
        $this->assertNull($response->context);
    }

    public function testDenyWhenNoPoliciesMatch(): void
    {
        $this->authorizer->method('getMatchingPolicies')->willReturn([]);
        $this->delegationService->method('validateDelegation')->willReturn(null);

        $response = $this->service->evaluate($this->createRequest());

        $this->assertFalse($response->decision);
        $this->assertArrayHasKey('reason_admin', $response->context);
    }

    public function testPartialPermitWhenPartialContextExists(): void
    {
        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');
        $policy->setPartialContext([
            'identifiers' => ['PRODUCT001'],
            'attributes' => ['PRODUCT.WEIGHT'],
        ]);

        $this->authorizer->method('getMatchingPolicies')->willReturn([$policy]);
        $this->delegationService->method('validateDelegation')->willReturn(null);

        $response = $this->service->evaluate($this->createRequest());

        $this->assertTrue($response->decision);
        $this->assertArrayHasKey('resource', $response->context);
    }

    public function testDenyWhenPropertyMismatch(): void
    {
        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');
        $policy->setServiceProvider('EU.EORI.NL000000099');

        $this->authorizer->method('getMatchingPolicies')->willReturn([$policy]);
        $this->delegationService->method('validateDelegation')->willReturn(null);

        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(
                type: 'api',
                id: '/products',
                properties: ['service_provider' => 'EU.EORI.NL000000002'],
            ),
            action: new Action(name: 'can_read'),
        );

        $response = $this->service->evaluate($request);

        $this->assertFalse($response->decision);
    }

    private function createRequest(): EvaluationRequest
    {
        return new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );
    }
}
