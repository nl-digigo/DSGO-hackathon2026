<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Evaluation;

use App\Dto\Action;
use App\Dto\EvaluationRequest;
use App\Dto\Resource;
use App\Dto\Subject;
use App\Service\Evaluation\ResponseBuilder;
use PHPUnit\Framework\TestCase;

class ResponseBuilderTest extends TestCase
{
    private ResponseBuilder $builder;

    protected function setUp(): void
    {
        $this->builder = new ResponseBuilder();
    }

    public function testPermitHasNoContext(): void
    {
        $response = $this->builder->permit();
        $this->assertTrue($response->decision);
        $this->assertNull($response->context);
    }

    public function testDenyHasReasons(): void
    {
        $response = $this->builder->deny();
        $this->assertFalse($response->decision);
        $this->assertArrayHasKey('reason_admin', $response->context);
        $this->assertArrayHasKey('reason_user', $response->context);
        $this->assertStringContainsString('No matching policy', $response->context['reason_admin']['en']);
    }

    public function testPartialPermitContainsResourceContext(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(
                type: 'api',
                id: '/products',
                properties: ['service_provider' => 'EU.EORI.NL000000002'],
            ),
            action: new Action(name: 'can_read'),
        );

        $partialContext = [
            'identifiers' => ['PRODUCT001'],
            'attributes' => ['PRODUCT.WEIGHT'],
        ];

        $response = $this->builder->partialPermit($request, $partialContext);

        $this->assertTrue($response->decision);
        $this->assertArrayHasKey('resource', $response->context);
        $this->assertEquals('api', $response->context['resource']['type']);
        $this->assertEquals('/products', $response->context['resource']['id']);
        $this->assertEquals(['PRODUCT001'], $response->context['resource']['properties']['identifiers']);
    }
}
