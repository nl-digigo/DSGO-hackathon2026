<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Evaluation;

use App\Dto\Action;
use App\Dto\EvaluationRequest;
use App\Dto\Resource;
use App\Dto\Subject;
use App\Service\Evaluation\RequestMapper;
use PHPUnit\Framework\TestCase;

class RequestMapperTest extends TestCase
{
    private RequestMapper $mapper;

    protected function setUp(): void
    {
        $this->mapper = new RequestMapper();
    }

    public function testMapsBasicFields(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(type: 'api', id: '/products'),
            action: new Action(name: 'can_read'),
        );

        $result = $this->mapper->map($request);

        $this->assertEquals('EU.EORI.NL000000001', $result['sub']);
        $this->assertEquals('/products', $result['obj']);
        $this->assertEquals('can_read', $result['act']);
        $this->assertEmpty($result['properties']);
    }

    public function testExtractsProperties(): void
    {
        $request = new EvaluationRequest(
            subject: new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001'),
            resource: new Resource(
                type: 'api',
                id: '/products',
                properties: ['service_provider' => 'EU.EORI.NL000000002'],
            ),
            action: new Action(
                name: 'can_read',
                properties: ['method' => 'GET', 'license' => 'DSGO.0001'],
            ),
        );

        $result = $this->mapper->map($request);

        $this->assertEquals('EU.EORI.NL000000002', $result['properties']['service_provider']);
        $this->assertEquals('GET', $result['properties']['method']);
        $this->assertEquals('DSGO.0001', $result['properties']['license']);
    }
}
