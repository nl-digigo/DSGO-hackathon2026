<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Identity;

use App\Service\Identity\ApiKeyValidator;
use PHPUnit\Framework\TestCase;

class ApiKeyValidatorTest extends TestCase
{
    public function testValidateWithValidKey(): void
    {
        $validator = new ApiKeyValidator('service-a:secret123,service-b:secret456');

        $result = $validator->validate('secret123');

        $this->assertSame('service-a', $result);
    }

    public function testValidateWithInvalidKey(): void
    {
        $validator = new ApiKeyValidator('service-a:secret123');

        $result = $validator->validate('wrong-key');

        $this->assertNull($result);
    }

    public function testValidateWithEmptyConfig(): void
    {
        $validator = new ApiKeyValidator('');

        $result = $validator->validate('any-key');

        $this->assertNull($result);
    }

    public function testIsEnabledWithKeys(): void
    {
        $validator = new ApiKeyValidator('service-a:secret123');

        $this->assertTrue($validator->isEnabled());
    }

    public function testIsEnabledWithoutKeys(): void
    {
        $validator = new ApiKeyValidator('');

        $this->assertFalse($validator->isEnabled());
    }

    public function testIsRequired(): void
    {
        $validator = new ApiKeyValidator('', true);

        $this->assertTrue($validator->isRequired());
    }

    public function testIsNotRequired(): void
    {
        $validator = new ApiKeyValidator('', false);

        $this->assertFalse($validator->isRequired());
    }

    public function testMultipleKeys(): void
    {
        $validator = new ApiKeyValidator('a:key1,b:key2,c:key3');

        $this->assertSame('a', $validator->validate('key1'));
        $this->assertSame('b', $validator->validate('key2'));
        $this->assertSame('c', $validator->validate('key3'));
    }

    public function testWhitespaceHandling(): void
    {
        $validator = new ApiKeyValidator(' service-a : secret123 , service-b : secret456 ');

        $this->assertSame('service-a', $validator->validate('secret123'));
        $this->assertSame('service-b', $validator->validate('secret456'));
    }

    public function testInvalidConfigFormat(): void
    {
        // Invalid format entries are ignored
        $validator = new ApiKeyValidator('invalid,also-invalid,service-a:valid');

        $this->assertSame('service-a', $validator->validate('valid'));
        $this->assertNull($validator->validate('invalid'));
    }
}
