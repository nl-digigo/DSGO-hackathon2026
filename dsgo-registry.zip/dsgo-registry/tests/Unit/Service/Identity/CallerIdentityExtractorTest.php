<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Identity;

use App\Service\Identity\ApiKeyValidator;
use App\Service\Identity\CallerIdentityExtractor;
use PHPUnit\Framework\TestCase;
use Symfony\Component\HttpFoundation\Request;

class CallerIdentityExtractorTest extends TestCase
{
    public function testExtractsFromApiKey(): void
    {
        $validator = new ApiKeyValidator('service-a:secret123');
        $extractor = new CallerIdentityExtractor($validator);

        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('X-API-Key', 'secret123');

        $identity = $extractor->extract($request);

        $this->assertSame('service-a', $identity->dataServiceId);
        $this->assertSame('api_key', $identity->source);
        $this->assertFalse($identity->isAnonymous());
    }

    public function testExtractsFromDataServiceIdHeader(): void
    {
        $validator = new ApiKeyValidator('');
        $extractor = new CallerIdentityExtractor($validator);

        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('X-Data-Service-Id', 'EU.EORI.NL000000001');

        $identity = $extractor->extract($request);

        $this->assertSame('EU.EORI.NL000000001', $identity->dataServiceId);
        $this->assertSame('header', $identity->source);
    }

    public function testExtractsFromMtlsCertificate(): void
    {
        $validator = new ApiKeyValidator('');
        $extractor = new CallerIdentityExtractor($validator);

        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('X-SSL-Client-DN', 'CN=data-service-a,O=Company A,C=NL');

        $identity = $extractor->extract($request);

        $this->assertSame('data-service-a', $identity->dataServiceId);
        $this->assertSame('mtls', $identity->source);
    }

    public function testReturnsAnonymousWhenNoIdentity(): void
    {
        $validator = new ApiKeyValidator('');
        $extractor = new CallerIdentityExtractor($validator);

        $request = Request::create('/api/evaluation', 'POST');

        $identity = $extractor->extract($request);

        $this->assertTrue($identity->isAnonymous());
        $this->assertSame('anonymous', $identity->dataServiceId);
        $this->assertSame('none', $identity->source);
    }

    public function testApiKeyTakesPrecedenceOverHeader(): void
    {
        $validator = new ApiKeyValidator('service-a:secret123');
        $extractor = new CallerIdentityExtractor($validator);

        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('X-API-Key', 'secret123');
        $request->headers->set('X-Data-Service-Id', 'other-service');

        $identity = $extractor->extract($request);

        $this->assertSame('service-a', $identity->dataServiceId);
        $this->assertSame('api_key', $identity->source);
    }

    public function testInvalidApiKeyFallsBackToHeader(): void
    {
        $validator = new ApiKeyValidator('service-a:secret123');
        $extractor = new CallerIdentityExtractor($validator);

        $request = Request::create('/api/evaluation', 'POST');
        $request->headers->set('X-API-Key', 'wrong-key');
        $request->headers->set('X-Data-Service-Id', 'fallback-service');

        $identity = $extractor->extract($request);

        $this->assertSame('fallback-service', $identity->dataServiceId);
        $this->assertSame('header', $identity->source);
    }
}
