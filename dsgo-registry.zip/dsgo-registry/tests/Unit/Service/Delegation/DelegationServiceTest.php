<?php

declare(strict_types=1);

namespace App\Tests\Unit\Service\Delegation;

use App\Dto\Subject;
use App\Repository\DelegationEvidenceRepository;
use App\Service\Delegation\DelegationService;
use App\Service\Registry\ParticipantRegistryInterface;
use Doctrine\ORM\EntityManagerInterface;
use PHPUnit\Framework\TestCase;

class DelegationServiceTest extends TestCase
{
    private DelegationService $service;
    private ParticipantRegistryInterface $registry;
    private DelegationEvidenceRepository $repository;

    protected function setUp(): void
    {
        $this->repository = $this->createMock(DelegationEvidenceRepository::class);
        $this->registry = $this->createMock(ParticipantRegistryInterface::class);
        $em = $this->createMock(EntityManagerInterface::class);

        $this->service = new DelegationService($this->repository, $this->registry, $em);
    }

    public function testNoDelegationReturnsNull(): void
    {
        $subject = new Subject(type: 'service-consumer', id: 'EU.EORI.NL000000001');
        $result = $this->service->validateDelegation($subject);
        $this->assertNull($result);
    }

    public function testValidDelegationReturnsIssuerId(): void
    {
        $this->registry->method('isValidParticipant')->willReturn(true);

        $subject = new Subject(
            type: 'service-consumer',
            id: 'EU.EORI.NL000000003',
            properties: [
                'delegation' => [
                    'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
                    'license' => 'DSGO.0008',
                ],
            ],
        );

        $result = $this->service->validateDelegation($subject);
        $this->assertEquals('EU.EORI.NL000000001', $result);
    }

    public function testInvalidIssuerThrowsException(): void
    {
        $this->registry->method('isValidParticipant')->willReturn(false);

        $subject = new Subject(
            type: 'service-consumer',
            id: 'EU.EORI.NL000000003',
            properties: [
                'delegation' => [
                    'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.INVALID001'],
                    'license' => 'DSGO.0008',
                ],
            ],
        );

        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('not a valid participant');
        $this->service->validateDelegation($subject);
    }

    public function testSubjectWithoutPropertiesReturnsNull(): void
    {
        $subject = new Subject(
            type: 'service-consumer',
            id: 'EU.EORI.NL000000001',
            properties: null,
        );

        $this->assertNull($this->service->validateDelegation($subject));
    }

    public function testSubjectWithEmptyDelegationReturnsNull(): void
    {
        $subject = new Subject(
            type: 'service-consumer',
            id: 'EU.EORI.NL000000001',
            properties: ['other_key' => 'value'],
        );

        $this->assertNull($this->service->validateDelegation($subject));
    }

    public function testNestedDelegationValidatesChain(): void
    {
        $this->registry->method('isValidParticipant')->willReturn(true);

        $subject = new Subject(
            type: 'service-consumer',
            id: 'EU.EORI.NL000000004',
            properties: [
                'delegation' => [
                    'issuer' => [
                        'type' => 'service-consumer',
                        'id' => 'EU.EORI.NL000000003',
                        'properties' => [
                            'delegation' => [
                                'issuer' => ['type' => 'service-consumer', 'id' => 'EU.EORI.NL000000001'],
                                'license' => 'DSGO.0001',
                            ],
                        ],
                    ],
                    'license' => 'DSGO.0008',
                ],
            ],
        );

        $result = $this->service->validateDelegation($subject);
        $this->assertSame('EU.EORI.NL000000001', $result);
    }
}
