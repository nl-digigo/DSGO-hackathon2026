<?php

declare(strict_types=1);

namespace App\Tests\Unit\Entity;

use App\Entity\PolicyRule;
use PHPUnit\Framework\TestCase;

class PolicyRuleTest extends TestCase
{
    public function testCreateNewPolicyRule(): void
    {
        $policy = new PolicyRule();

        $this->assertSame('p', $policy->getPtype());
        $this->assertSame('', $policy->getV0());
        $this->assertSame('', $policy->getV1());
        $this->assertSame('', $policy->getV2());
        $this->assertNull($policy->getId());
        $this->assertNull($policy->getPartialContext());
    }

    public function testSettersAndGetters(): void
    {
        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');

        $this->assertSame('EU.EORI.NL000000001', $policy->getV0());
        $this->assertSame('/products', $policy->getV1());
        $this->assertSame('can_read', $policy->getV2());
    }

    public function testAuthZenAliases(): void
    {
        $policy = new PolicyRule();
        $policy->setSubject('EU.EORI.NL000000001');
        $policy->setResource('/products');
        $policy->setAction('can_read');
        $policy->setServiceProvider('EU.EORI.NL000000002');
        $policy->setMethod('GET');
        $policy->setLicense('DSGO.0001');

        $this->assertSame('EU.EORI.NL000000001', $policy->getSubject());
        $this->assertSame('/products', $policy->getResource());
        $this->assertSame('can_read', $policy->getAction());
        $this->assertSame('EU.EORI.NL000000002', $policy->getServiceProvider());
        $this->assertSame('GET', $policy->getMethod());
        $this->assertSame('DSGO.0001', $policy->getLicense());

        $this->assertSame('EU.EORI.NL000000001', $policy->getV0());
        $this->assertSame('/products', $policy->getV1());
        $this->assertSame('can_read', $policy->getV2());
        $this->assertSame('EU.EORI.NL000000002', $policy->getV3());
        $this->assertSame('GET', $policy->getV4());
        $this->assertSame('DSGO.0001', $policy->getV5());
    }

    public function testPartialContext(): void
    {
        $policy = new PolicyRule();
        $ctx = ['identifiers' => ['PRODUCT001'], 'attributes' => ['PRODUCT.WEIGHT']];
        $policy->setPartialContext($ctx);

        $this->assertEquals($ctx, $policy->getPartialContext());
    }

    public function testToRuleArray(): void
    {
        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');

        $this->assertSame(['EU.EORI.NL000000001', '/products', 'can_read'], $policy->toRuleArray());
    }

    public function testToRuleArrayWithOptionalFields(): void
    {
        $policy = new PolicyRule();
        $policy->setV0('EU.EORI.NL000000001');
        $policy->setV1('/products');
        $policy->setV2('can_read');
        $policy->setV3('EU.EORI.NL000000002');
        $policy->setV4('GET');

        $this->assertSame([
            'EU.EORI.NL000000001', '/products', 'can_read', 'EU.EORI.NL000000002', 'GET',
        ], $policy->toRuleArray());
    }

    public function testFromRuleArray(): void
    {
        $policy = PolicyRule::fromRuleArray('p', [
            'EU.EORI.NL000000001', '/products', 'can_read',
            'EU.EORI.NL000000002', 'GET', 'DSGO.0001',
        ]);

        $this->assertSame('EU.EORI.NL000000001', $policy->getSubject());
        $this->assertSame('EU.EORI.NL000000002', $policy->getServiceProvider());
        $this->assertSame('DSGO.0001', $policy->getLicense());
    }

    public function testTimestampsAreSet(): void
    {
        $policy = new PolicyRule();
        $this->assertInstanceOf(\DateTimeImmutable::class, $policy->getCreatedAt());
        $this->assertInstanceOf(\DateTimeImmutable::class, $policy->getUpdatedAt());
    }

    public function testUpdatedAtChangesOnModification(): void
    {
        $policy = new PolicyRule();
        $originalUpdatedAt = $policy->getUpdatedAt();
        usleep(1000);
        $policy->setV0('EU.EORI.NL000000002');
        $this->assertGreaterThan($originalUpdatedAt, $policy->getUpdatedAt());
    }

    public function testFluentInterface(): void
    {
        $policy = new PolicyRule();
        $result = $policy->setV0('EU.EORI.NL000000001')->setV1('/products')->setV2('can_read');
        $this->assertSame($policy, $result);
    }
}
