<?php

declare(strict_types=1);

namespace App\Tests\Unit\Entity;

use App\Entity\TokenCreator;
use PHPUnit\Framework\TestCase;

class TokenCreatorTest extends TestCase
{
    public function testGettersAndSetters(): void
    {
        $tc = new TokenCreator();

        $this->assertSame('did:ishare:EU.NL.NTRNL-99999998', $tc->getClientId());
        $this->assertSame('urn:ietf:params:oauth:client-assertion-type:jwt-bearer', $tc->getClientAssertionType());
        $this->assertSame('iSHARE', $tc->getScope());
        $this->assertSame('client_credentials', $tc->getGrantType());
        $this->assertSame('did:ishare:EU.NL.NTRNL-99999999', $tc->getAudience());
        $this->assertNull($tc->getTokenUrl());
        $this->assertNull($tc->getDataUrl());
        $this->assertStringContainsString('BEGIN PRIVATE KEY', $tc->getPrivateKey());
        $this->assertStringContainsString('MIIG', $tc->getPublicKey());

        $result = $tc->setClientId('client-123');
        $this->assertSame($tc, $result);
        $this->assertSame('client-123', $tc->getClientId());

        $tc->setClientAssertionType('urn:ietf:params:oauth:client-assertion-type:jwt-bearer');
        $this->assertSame('urn:ietf:params:oauth:client-assertion-type:jwt-bearer', $tc->getClientAssertionType());

        $tc->setScope('iSHARE');
        $this->assertSame('iSHARE', $tc->getScope());

        $tc->setGrantType('client_credentials');
        $this->assertSame('client_credentials', $tc->getGrantType());

        $tc->setAudience('did:ishare:EU.NL.NTRNL-99999999');
        $this->assertSame('did:ishare:EU.NL.NTRNL-99999999', $tc->getAudience());

        $tc->setTokenUrl('https://example.com/token');
        $this->assertSame('https://example.com/token', $tc->getTokenUrl());

        $tc->setDataUrl('https://example.com/api/data');
        $this->assertSame('https://example.com/api/data', $tc->getDataUrl());

        $tc->setPrivateKey('-----BEGIN PRIVATE KEY-----...');
        $this->assertSame('-----BEGIN PRIVATE KEY-----...', $tc->getPrivateKey());

        $tc->setPublicKey('MIIGUDCCBDig...');
        $this->assertSame('MIIGUDCCBDig...', $tc->getPublicKey());
    }

    public function testFluentInterface(): void
    {
        $tc = (new TokenCreator())
            ->setClientId('id')
            ->setScope('scope')
            ->setGrantType('grant')
            ->setAudience('aud')
            ->setTokenUrl('url')
            ->setDataUrl('data')
            ->setPrivateKey('key')
            ->setPublicKey('pub')
            ->setClientAssertionType('type');

        $this->assertSame('id', $tc->getClientId());
        $this->assertSame('scope', $tc->getScope());
        $this->assertSame('grant', $tc->getGrantType());
        $this->assertSame('aud', $tc->getAudience());
        $this->assertSame('url', $tc->getTokenUrl());
        $this->assertSame('data', $tc->getDataUrl());
        $this->assertSame('key', $tc->getPrivateKey());
        $this->assertSame('pub', $tc->getPublicKey());
        $this->assertSame('type', $tc->getClientAssertionType());
    }
}
