<?php

declare(strict_types=1);

namespace App\EventListener;

use Ramsey\Uuid\Uuid;
use Symfony\Component\EventDispatcher\Attribute\AsEventListener;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Event listener that manages correlation IDs for request tracing.
 * 
 * - On request: Extracts or generates a correlation ID
 * - On response: Adds the correlation ID to response headers
 */
#[AsEventListener(event: KernelEvents::REQUEST, priority: 255)]
#[AsEventListener(event: KernelEvents::RESPONSE, priority: -255)]
final class CorrelationIdListener
{
    public const HEADER_NAME = 'X-Correlation-Id';
    public const ATTRIBUTE_NAME = 'correlation_id';

    public function onKernelRequest(RequestEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        $request = $event->getRequest();
        
        // Use existing correlation ID from header, or generate a new one
        $correlationId = $request->headers->get(self::HEADER_NAME);
        
        if ($correlationId === null || $correlationId === '') {
            $correlationId = Uuid::uuid4()->toString();
        }
        
        // Store in request attributes for use throughout the request lifecycle
        $request->attributes->set(self::ATTRIBUTE_NAME, $correlationId);
    }

    public function onKernelResponse(ResponseEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        $correlationId = $event->getRequest()->attributes->get(self::ATTRIBUTE_NAME);
        
        if ($correlationId !== null) {
            $event->getResponse()->headers->set(self::HEADER_NAME, $correlationId);
        }
    }
}
