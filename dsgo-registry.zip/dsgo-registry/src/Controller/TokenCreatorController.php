<?php

namespace App\Controller;

use App\Entity\TokenCreator;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Contracts\HttpClient\HttpClientInterface;

final class TokenCreatorController extends AbstractController
{
    public function __construct(
        protected HttpClientInterface $client,
        private readonly HttpKernelInterface $httpKernel,
    ) {}

    #[Route('/token/creator', name: 'app_token_creator')]
    public function index(Request $request): Response
    {
        $tokenCreator = new TokenCreator();

        $internalBase = 'http://127.0.0.1:' . ($request->server->get('SERVER_PORT') ?: '8000');
        $tokenCreator->setTokenUrl($internalBase . '/token');
        $tokenCreator->setDataUrl($internalBase . '/api/health');

        $form = $this->createFormBuilder($tokenCreator)
            ->add('clientId', TextType::class)
            ->add('clientAssertionType', TextType::class)
            ->add('scope', TextType::class)
            ->add('grantType', TextType::class)
            ->add('audience', TextType::class)
            ->add('tokenUrl', TextType::class)
            ->add('dataUrl', TextType::class)
            ->add('privateKey', TextareaType::class)
            ->add('publicKey', TextareaType::class)
            ->add('save', SubmitType::class, [ 'label' => 'Generate token', 'attr' => ['class' => 'btn btn-primary']])
            ->setAction($this->generateUrl('app_token_creator'))
            ->setMethod('POST')
            ->getForm();

        $response = '';
        $token = '';
        $evaluationResult = '';
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            /** @var TokenCreator $data */
            $data = $form->getData();
            $certChain = explode(',', $data->getPublicKey());
            $clientId = $data->getClientId();

            $privateKey = InMemory::plainText($data->getPrivateKey(), '');

            $config = Configuration::forAsymmetricSigner(new Sha256(), $privateKey, $privateKey);
            $now = new \DateTimeImmutable(date('Y-m-d H:i:s'));

            $assertion = $config->builder()
                ->issuedBy($clientId)
                ->permittedFor($data->getAudience())
                ->relatedTo($clientId)
                ->issuedAt($now)
                ->canOnlyBeUsedAfter($now)
                ->expiresAt($now->modify('+30 seconds'))
                ->identifiedBy(bin2hex(random_bytes(16)))
                ->withHeader('typ', 'JWT')
                ->withHeader('x5c', $certChain)
                ->getToken($config->signer(), $config->signingKey())
                ->toString();

            $tokenRequestBody = [
                'grant_type' => $data->getGrantType(),
                'scope' => $data->getScope(),
                'client_assertion_type' => $data->getClientAssertionType(),
                'client_assertion' => $assertion,
                'client_id' => $data->getClientId(),
            ];

            // Step 1: obtain access token
            if ($this->isLocalCall($data->getTokenUrl(), $request)) {
                $token = $this->requestLocalJson($request, 'POST', $data->getTokenUrl(), $tokenRequestBody);
            } else {
                $dataResult = $this->client->request('POST', $data->getTokenUrl(), ['body' => $tokenRequestBody]);
                $token = $dataResult->toArray(false);
            }

            if (isset($token['access_token'])) {
                $authHeaders = [
                    'Authorization' => 'Bearer ' . $token['access_token'],
                    'Content-Type' => 'application/json',
                ];

                // Step 2: call data endpoint (health, evaluation, or custom)
                if ($this->isLocalCall($data->getDataUrl(), $request)) {
                    $response = $this->requestLocalJson($request, 'GET', $data->getDataUrl(), [], $authHeaders);
                } else {
                    $dataResultContent = $this->client->request('GET', $data->getDataUrl(), ['headers' => $authHeaders]);
                    $response = $dataResultContent->toArray(false);
                }

                // Step 3: demo Casbin evaluation — test client leest /products bij server
                $evaluationBody = [
                    'subject' => ['type' => 'service-consumer', 'id' => 'did:ishare:EU.NL.NTRNL-99999998'],
                    'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'did:ishare:EU.NL.NTRNL-99999999']],
                    'action' => ['name' => 'can_read', 'properties' => ['method' => 'GET', 'license' => 'DSGO.0001']],
                ];

                $evalUrl = $internalBase . '/api/evaluation';
                if ($this->isLocalCall($evalUrl, $request)) {
                    $evaluationResult = $this->requestLocalJson($request, 'POST', $evalUrl, $evaluationBody, $authHeaders);
                } else {
                    $evalResponse = $this->client->request('POST', $evalUrl, [
                        'headers' => $authHeaders,
                        'json' => $evaluationBody,
                    ]);
                    $evaluationResult = $evalResponse->toArray(false);
                }
            }
        }

        return $this->render('token_creator/index.html.twig', [
            'controller_name' => 'TokenCreatorController',
            'form' => $form,
            'token' => $token,
            'response' => $response,
            'evaluationResult' => $evaluationResult,
            'evaluationRequest' => [
                'subject' => ['type' => 'service-consumer', 'id' => 'did:ishare:EU.NL.NTRNL-99999998'],
                'resource' => ['type' => 'api', 'id' => '/products', 'properties' => ['service_provider' => 'did:ishare:EU.NL.NTRNL-99999999']],
                'action' => ['name' => 'can_read', 'properties' => ['method' => 'GET', 'license' => 'DSGO.0001']],
            ],
        ]);
    }

    private function isLocalCall(string $url, Request $request): bool
    {
        $host = parse_url($url, \PHP_URL_HOST);
        if (!in_array($host, ['127.0.0.1', 'localhost'], true)) {
            return false;
        }

        $path = (string) (parse_url($url, \PHP_URL_PATH) ?: '');
        if (!str_starts_with($path, '/token') && !str_starts_with($path, '/api/')) {
            return false;
        }

        $port = parse_url($url, \PHP_URL_PORT);
        $currentPort = (int) ($request->server->get('SERVER_PORT') ?: 8000);

        if ($port === null || (int) $port === $currentPort) {
            return true;
        }

        return ($currentPort === 8000 && (int) $port === 8080)
            || ($currentPort === 8080 && (int) $port === 8000);
    }

    private function requestLocalJson(
        Request $parentRequest,
        string $method,
        string $url,
        array $body = [],
        array $headers = [],
    ): array {
        $path = (string) (parse_url($url, \PHP_URL_PATH) ?: '/');
        $query = parse_url($url, \PHP_URL_QUERY);
        if (is_string($query) && $query !== '') {
            $path .= '?' . $query;
        }

        $isJson = isset($headers['Content-Type']) && str_contains($headers['Content-Type'], 'application/json');
        $isGet = strtoupper($method) === 'GET';

        $subRequest = Request::create(
            $path,
            strtoupper($method),
            ($isGet || $isJson) ? [] : $body,
            [],
            [],
            [],
            $isJson && !$isGet ? json_encode($body) : null,
        );

        foreach ($headers as $name => $value) {
            $subRequest->headers->set($name, $value);
        }

        $subRequest->server->set('HTTP_HOST', (string) $parentRequest->getHost());
        $subRequest->server->set('SERVER_PORT', (string) $parentRequest->getPort());

        $subResponse = $this->httpKernel->handle($subRequest, HttpKernelInterface::SUB_REQUEST);
        $content = $subResponse->getContent();
        if ($content === false || $content === '') {
            return [];
        }

        $decoded = json_decode($content, true);

        return is_array($decoded) ? $decoded : ['raw' => $content];
    }
}
