<?php

declare(strict_types=1);

namespace App\Controller\Admin;

use App\Entity\PolicyRule;
use App\Form\PolicyRuleType;
use App\Repository\PolicyRuleRepository;
use App\Service\Casbin\EnforcerFactory;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/admin/policies')]
final class PolicyController extends AbstractController
{
    public function __construct(
        private readonly PolicyRuleRepository $repository,
        private readonly EntityManagerInterface $entityManager,
        private readonly EnforcerFactory $enforcerFactory,
        private readonly ValidatorInterface $validator,
    ) {
    }

    #[Route('', name: 'admin_policy_index', methods: ['GET'])]
    public function index(): Response
    {
        $policies = $this->repository->findAll();
        $subjects = $this->repository->getUniqueSubjects();

        return $this->render('admin/policy/index.html.twig', [
            'policies' => $policies,
            'subjects' => $subjects,
            'policyCount' => count($policies),
        ]);
    }

    #[Route('/new', name: 'admin_policy_new', methods: ['GET', 'POST'])]
    public function new(Request $request): Response
    {
        $policy = new PolicyRule();
        $form = $this->createForm(PolicyRuleType::class, $policy);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->persist($policy);
            $this->entityManager->flush();
            $this->enforcerFactory->forceRefresh();

            $this->addFlash('success', 'Policy succesvol toegevoegd.');

            return $this->redirectToRoute('admin_policy_index');
        }

        return $this->render('admin/policy/new.html.twig', [
            'form' => $form,
        ]);
    }

    #[Route('/{id}/edit', name: 'admin_policy_edit', methods: ['GET', 'POST'])]
    public function edit(PolicyRule $policy, Request $request): Response
    {
        $form = $this->createForm(PolicyRuleType::class, $policy);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->flush();
            $this->enforcerFactory->forceRefresh();

            $this->addFlash('success', 'Policy succesvol bijgewerkt.');

            return $this->redirectToRoute('admin_policy_index');
        }

        return $this->render('admin/policy/edit.html.twig', [
            'form' => $form,
            'policy' => $policy,
        ]);
    }

    #[Route('/{id}/delete', name: 'admin_policy_delete', methods: ['POST'])]
    public function delete(PolicyRule $policy, Request $request): Response
    {
        $token = $request->request->get('_token');
        if ($this->isCsrfTokenValid('delete-policy-' . $policy->getId(), $token)) {
            $this->entityManager->remove($policy);
            $this->entityManager->flush();
            $this->enforcerFactory->forceRefresh();

            $this->addFlash('success', 'Policy succesvol verwijderd.');
        } else {
            $this->addFlash('error', 'Ongeldige CSRF token.');
        }

        return $this->redirectToRoute('admin_policy_index');
    }

    #[Route('/subject/{subject}', name: 'admin_policy_by_subject', methods: ['GET'])]
    public function bySubject(string $subject): Response
    {
        $subject = urldecode($subject);
        $policies = $this->repository->findBySubject($subject);

        return $this->render('admin/policy/by_subject.html.twig', [
            'policies' => $policies,
            'subject' => $subject,
        ]);
    }

    #[Route('/import', name: 'admin_policy_import', methods: ['GET', 'POST'])]
    public function import(Request $request): Response
    {
        if ($request->isMethod('POST')) {
            $token = $request->request->get('_token');
            if (!$this->isCsrfTokenValid('import-policy', $token)) {
                $this->addFlash('error', 'Ongeldige CSRF token.');
                return $this->redirectToRoute('admin_policy_import');
            }

            $csvText = trim((string) $request->request->get('csv_text', ''));
            if ($csvText === '') {
                $this->addFlash('error', 'Geen CSV-invoer opgegeven.');
                return $this->redirectToRoute('admin_policy_import');
            }

            $replace = (bool) $request->request->get('replace', false);
            $policies = $this->parseCsvText($csvText);
            $errors = [];
            $valid = [];

            foreach ($policies as $lineNumber => $row) {
                $policy = new PolicyRule();
                $policy->setV0($row['subject']);
                $policy->setV1($row['resource']);
                $policy->setV2($row['action']);
                $policy->setV3($row['service_provider'] ?? null);
                $policy->setV4($row['method'] ?? null);
                $policy->setV5($row['license'] ?? null);
                $violations = $this->validator->validate($policy);
                if (count($violations) > 0) {
                    $errors[] = $lineNumber + 1;
                } else {
                    $valid[] = $policy;
                }
            }

            if (count($errors) > 0) {
                $this->addFlash('error', sprintf(
                    'Ongeldige regels op regel(s): %s. Geen wijzigingen toegepast.',
                    implode(', ', $errors)
                ));
                return $this->redirectToRoute('admin_policy_import');
            }

            if ($replace) {
                $this->repository->clearAll();
            }
            foreach ($valid as $policy) {
                $this->entityManager->persist($policy);
            }
            $this->entityManager->flush();
            $this->enforcerFactory->forceRefresh();

            $this->addFlash('success', sprintf('%d policy(ies) geimporteerd.', count($valid)));
            return $this->redirectToRoute('admin_policy_index');
        }

        return $this->render('admin/policy/import.html.twig');
    }

    /**
     * @return array<int, array<string, ?string>>
     */
    private function parseCsvText(string $csvText): array
    {
        $policies = [];
        $lines = preg_split('/\R/', $csvText) ?: [];
        $lineNumber = 0;

        foreach ($lines as $line) {
            $lineNumber++;
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $row = str_getcsv($line);

            if ($lineNumber === 1 && in_array(strtolower(trim($row[0] ?? '')), ['subject', 'p'], true)) {
                continue;
            }

            $offset = 0;
            if (count($row) >= 4 && trim($row[0]) === 'p') {
                $offset = 1;
            }

            if (count($row) >= $offset + 3) {
                $policies[] = [
                    'subject' => trim($row[$offset]),
                    'resource' => trim($row[$offset + 1]),
                    'action' => trim($row[$offset + 2]),
                    'service_provider' => isset($row[$offset + 3]) && trim($row[$offset + 3]) !== '' ? trim($row[$offset + 3]) : null,
                    'method' => isset($row[$offset + 4]) && trim($row[$offset + 4]) !== '' ? trim($row[$offset + 4]) : null,
                    'license' => isset($row[$offset + 5]) && trim($row[$offset + 5]) !== '' ? trim($row[$offset + 5]) : null,
                ];
            }
        }

        return $policies;
    }
}
