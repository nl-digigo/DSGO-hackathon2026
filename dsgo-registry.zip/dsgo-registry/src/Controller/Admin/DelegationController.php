<?php

declare(strict_types=1);

namespace App\Controller\Admin;

use App\Entity\DelegationEvidence;
use App\Form\DelegationEvidenceType;
use App\Repository\DelegationEvidenceRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

#[Route('/admin/delegations')]
final class DelegationController extends AbstractController
{
    public function __construct(
        private readonly DelegationEvidenceRepository $repository,
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    #[Route('', name: 'admin_delegation_index', methods: ['GET'])]
    public function index(): Response
    {
        $delegations = $this->repository->findBy([], ['createdAt' => 'DESC']);

        return $this->render('admin/delegation/index.html.twig', [
            'delegations' => $delegations,
        ]);
    }

    #[Route('/new', name: 'admin_delegation_new', methods: ['GET', 'POST'])]
    public function new(Request $request): Response
    {
        $delegation = new DelegationEvidence();
        $form = $this->createForm(DelegationEvidenceType::class, $delegation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->persist($delegation);
            $this->entityManager->flush();

            $this->addFlash('success', 'Delegation evidence succesvol toegevoegd.');

            return $this->redirectToRoute('admin_delegation_index');
        }

        return $this->render('admin/delegation/new.html.twig', [
            'form' => $form,
        ]);
    }

    #[Route('/{id}/edit', name: 'admin_delegation_edit', methods: ['GET', 'POST'])]
    public function edit(DelegationEvidence $delegation, Request $request): Response
    {
        $form = $this->createForm(DelegationEvidenceType::class, $delegation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->flush();

            $this->addFlash('success', 'Delegation evidence succesvol bijgewerkt.');

            return $this->redirectToRoute('admin_delegation_index');
        }

        return $this->render('admin/delegation/edit.html.twig', [
            'form' => $form,
            'delegation' => $delegation,
        ]);
    }

    #[Route('/{id}/delete', name: 'admin_delegation_delete', methods: ['POST'])]
    public function delete(DelegationEvidence $delegation, Request $request): Response
    {
        $token = $request->request->get('_token');
        if ($this->isCsrfTokenValid('delete-delegation-' . $delegation->getId(), $token)) {
            $this->entityManager->remove($delegation);
            $this->entityManager->flush();
            $this->addFlash('success', 'Delegation evidence succesvol verwijderd.');
        } else {
            $this->addFlash('error', 'Ongeldige CSRF token.');
        }

        return $this->redirectToRoute('admin_delegation_index');
    }
}
