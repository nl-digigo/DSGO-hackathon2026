<?php
namespace App\Controller;

use App\Service\Registry\ParticipantRegistryInterface;
use App\Util\JwtKeyPaths;
use Lcobucci\Clock\SystemClock;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Lcobucci\JWT\UnencryptedToken;
use Lcobucci\JWT\Validation\Constraint\IssuedBy;
use Lcobucci\JWT\Validation\Constraint\SignedWith;
use Lcobucci\JWT\Validation\Constraint\StrictValidAt;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Attribute\AsController;
use Symfony\Component\Routing\Attribute\Route;

#[AsController]
final class TokenController
{
    public const clientId = 'did:ishare:EU.NL.NTRNL-99999999';

    public function __construct(
        private readonly ParticipantRegistryInterface $participantRegistry,
    ) {}

    #[Route('/token', name: 'ishare_token', methods: ['POST'])]
    public function __invoke(Request $request): JsonResponse
    {
        $grantType = $request->request->get('grant_type');
        $clientAssertion = $request->request->get('client_assertion');
        $requestClientId = $request->request->get('client_id');

        if ($grantType !== 'client_credentials' || !$clientAssertion) {
            return new JsonResponse(['error' => 'invalid_request'], 400);
        }

        try {
            $privateKey = InMemory::file(JwtKeyPaths::PRIVATE_KEY, '');
            $config = Configuration::forSymmetricSigner(new Sha256(), $privateKey);
            $token = $config->parser()->parse($clientAssertion);
            assert($token instanceof UnencryptedToken);

            if (! $x5c = $token->headers()->get('x5c')) {
                return new JsonResponse(['error' => 'missing_x5c'], 401);
            }

            $iss = $token->claims()->get('iss');
            $sub = $token->claims()->get('sub');

            if ($requestClientId && $requestClientId !== $iss) {
                throw new \RuntimeException(sprintf(
                    'client_id "%s" does not match JWT iss "%s".',
                    $requestClientId,
                    $iss,
                ));
            }
            if ($requestClientId && $requestClientId !== $sub) {
                throw new \RuntimeException(sprintf(
                    'client_id "%s" does not match JWT sub "%s".',
                    $requestClientId,
                    $sub,
                ));
            }

            $publicKeyPem = $this->extractPublicKeyFromX5c($x5c);
            $constraints = [
                new SignedWith(new Sha256(), InMemory::plainText($publicKeyPem)),
                new StrictValidAt(new SystemClock(new \DateTimeZone('europe/amsterdam'))),
                new IssuedBy($sub),
            ];

            $validator = $config->validator();
            $validator->assert($token, ...$constraints);
            $certData = openssl_x509_parse($this->x5cToPem($x5c));
            $certSubject = (is_array($certData) && isset($certData['subject']) && is_array($certData['subject']))
                ? $certData['subject']
                : [];
            $organizationId = $this->validateTokenClaims($token, $certSubject);

            if (!$this->participantRegistry->isValidParticipant($organizationId)) {
                return new JsonResponse(['error' => 'invalid client'], 401);
            }

            $now = new \DateTimeImmutable('now', new \DateTimeZone('europe/amsterdam'));
            $jwt = $config->builder()
                ->issuedBy(self::clientId)
                ->permittedFor(self::clientId)
                ->withClaim('client_id', $token->claims()->get('sub'))
                ->expiresAt($now->add(new \DateInterval('PT1H')))
                ->issuedAt($now)
                ->canOnlyBeUsedAfter($now)
                ->withClaim('scope', ['iSHARE'])
                ->getToken($config->signer(), $config->signingKey())
                ->toString();

            return new JsonResponse([
                'access_token' => $jwt,
                'token_type' => 'Bearer',
                'expires_in' => 3600,
                'scope' => 'iSHARE',
            ]);

        } catch (\Throwable $e) {
            if (str_contains($e->getMessage(), 'Digigo auth failed for client_id')) {
                return new JsonResponse([
                    'error' => 'participant_registry_auth_failed',
                    'details' => $e->getMessage(),
                ], 401);
            }

            return new JsonResponse(['error' => 'invalid_client_assertion', 'details' => $e->getMessage()], 401);
        }
    }

    private function x5cToPem(array $x5c): string
    {
        return implode("\n", array_map(
            fn(string $cert) => "-----BEGIN CERTIFICATE-----\n" . chunk_split($cert, 64, "\n") . "-----END CERTIFICATE-----",
            $x5c,
        ));
    }

    private function extractPublicKeyFromX5c(array $x5c): string
    {
        $leafCertPem = $this->x5cToPem($x5c);
        $pubRes = openssl_pkey_get_public($leafCertPem);

        if (!$pubRes) {
            throw new \RuntimeException('Invalid leaf certificate.');
        }

        $pubDetails = openssl_pkey_get_details($pubRes);
        if (!isset($pubDetails['key'])) {
            throw new \RuntimeException('No public key found in certificate.');
        }

        return $pubDetails['key'];
    }

    private function validateTokenClaims(UnencryptedToken $token, array $certSubject): string
    {
        $iss = $token->claims()->get('iss');
        $sub = $token->claims()->get('sub');
        $aud = $token->claims()->get('aud');

        if (!$iss || !$sub || !$aud) {
            throw new \RuntimeException('Missing required claims.');
        }

        $organizationId = $this->extractOrganizationIdentifier($certSubject);
        if ($organizationId === '') {
            throw new \RuntimeException('Invalid certificate: missing organizationIdentifier in x5c subject.');
        }

        if (!str_contains($sub, $organizationId)) {
            throw new \RuntimeException(sprintf(
                'Invalid certificate: token sub "%s" does not match certificate organizationIdentifier "%s".',
                $sub,
                $organizationId
            ));
        }

        return $organizationId;
    }

    private function extractOrganizationIdentifier(array $certSubject): string
    {
        $candidateKeys = [
            'organizationIdentifier',
            'OID.2.5.4.97',
            '2.5.4.97',
            'serialNumber',
            'a',
        ];

        foreach ($candidateKeys as $key) {
            if (!isset($certSubject[$key]) || !is_scalar($certSubject[$key])) {
                continue;
            }

            $value = trim((string) $certSubject[$key]);
            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }
}
