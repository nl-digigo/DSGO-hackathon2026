<?php

declare(strict_types=1);

namespace App\Util;

/**
 * Centralises the file paths for the server's JWT signing key and certificate chain,
 * preventing magic strings from being scattered across controllers, authenticators and services.
 */
final class JwtKeyPaths
{
    public const PRIVATE_KEY = __DIR__ . '/../../config/jwt/private.key';
    public const CERT_CHAIN = __DIR__ . '/../../config/jwt/cert13909d26d707be2016b4f47f2aee636904848361-chain.pem';
}
