<?php

declare(strict_types=1);

namespace App\OpenApi;

use ApiPlatform\OpenApi\Factory\OpenApiFactoryInterface;
use ApiPlatform\OpenApi\Model;
use ApiPlatform\OpenApi\OpenApi;
use Symfony\Component\DependencyInjection\Attribute\AsDecorator;

#[AsDecorator('api_platform.openapi.factory')]
final class OpenApiFactory implements OpenApiFactoryInterface
{
    public function __construct(
        private readonly OpenApiFactoryInterface $decorated,
    ) {}

    public function __invoke(array $context = []): OpenApi
    {
        $openApi = $this->decorated->__invoke($context);

        $openApi = $this->addSecurityScheme($openApi);
        $openApi = $this->addTokenEndpoint($openApi);
        $openApi = $this->replaceTagDescriptions($openApi);

        return $openApi;
    }

    private function addSecurityScheme(OpenApi $openApi): OpenApi
    {
        $securitySchemes = $openApi->getComponents()->getSecuritySchemes() ?? new \ArrayObject();
        $securitySchemes['Bearer'] = new \ArrayObject([
            'type' => 'http',
            'scheme' => 'bearer',
            'bearerFormat' => 'JWT',
            'description' => 'Obtain a token via POST /token using an iSHARE client_assertion JWT.',
        ]);

        return $openApi->withComponents(
            $openApi->getComponents()->withSecuritySchemes($securitySchemes)
        );
    }

    private function addTokenEndpoint(OpenApi $openApi): OpenApi
    {
        $tokenPath = new Model\PathItem(
            post: new Model\Operation(
                operationId: 'token_post',
                tags: ['Authentication'],
                responses: [
                    '200' => [
                        'description' => 'Access token issued',
                        'content' => [
                            'application/json' => [
                                'schema' => [
                                    'type' => 'object',
                                    'properties' => [
                                        'access_token' => ['type' => 'string', 'description' => 'JWT access token'],
                                        'token_type' => ['type' => 'string', 'example' => 'Bearer'],
                                        'expires_in' => ['type' => 'integer', 'example' => 3600],
                                        'scope' => ['type' => 'string', 'example' => 'iSHARE'],
                                    ],
                                ],
                            ],
                        ],
                    ],
                    '400' => ['description' => 'Invalid request (missing grant_type or client_assertion)'],
                    '401' => ['description' => 'Invalid client assertion, certificate, or unregistered participant'],
                ],
                summary: 'Obtain an access token (OAuth2 Client Credentials)',
                description: <<<'DESC'
                    Issues a JWT access token using the OAuth2 client_credentials grant with iSHARE JWT client assertion (RFC 7523).

                    The client must provide:
                    - `grant_type`: must be `client_credentials`
                    - `client_assertion_type`: `urn:ietf:params:oauth:client-assertion-type:jwt-bearer`
                    - `client_assertion`: a signed JWT with x5c header containing the client certificate chain
                    - `client_id`: the iSHARE party identifier (e.g. `did:ishare:EU.NL.NTRNL-99999998`)
                    - `scope`: `iSHARE`

                    The server validates the JWT signature against the x5c certificate, verifies the organization identifier matches the token claims, and checks the Digigo participant registry.
                    DESC,
                security: [],
                requestBody: new Model\RequestBody(
                    description: 'OAuth2 Client Credentials token request',
                    content: new \ArrayObject([
                        'application/x-www-form-urlencoded' => [
                            'schema' => [
                                'type' => 'object',
                                'required' => ['grant_type', 'client_assertion_type', 'client_assertion', 'client_id', 'scope'],
                                'properties' => [
                                    'grant_type' => [
                                        'type' => 'string',
                                        'enum' => ['client_credentials'],
                                        'description' => 'Must be client_credentials',
                                    ],
                                    'client_assertion_type' => [
                                        'type' => 'string',
                                        'enum' => ['urn:ietf:params:oauth:client-assertion-type:jwt-bearer'],
                                        'description' => 'JWT bearer assertion type',
                                    ],
                                    'client_assertion' => [
                                        'type' => 'string',
                                        'description' => 'Signed JWT with x5c certificate chain in header',
                                    ],
                                    'client_id' => [
                                        'type' => 'string',
                                        'description' => 'iSHARE party identifier (e.g. did:ishare:EU.NL.NTRNL-99999998)',
                                    ],
                                    'scope' => [
                                        'type' => 'string',
                                        'enum' => ['iSHARE'],
                                        'description' => 'Must be iSHARE',
                                    ],
                                ],
                            ],
                        ],
                    ]),
                    required: true,
                ),
            ),
        );

        $openApi->getPaths()->addPath('/token', $tokenPath);

        return $openApi;
    }

    private function replaceTagDescriptions(OpenApi $openApi): OpenApi
    {
        $tagDescriptions = [
            'Authentication' => 'OAuth2 token endpoint for obtaining access tokens via iSHARE client assertions.',
            'Evaluation' => 'AuthZen Policy Decision Point (PDP) — evaluate whether a subject may perform an action on a resource.',
            'PolicySearch' => 'Policy Retrieval Point (PRP) — search for delegation evidence matching a given issuer, subject, and resource.',
            'HealthStatus' => 'Service health check (public, no authentication required).',
            'PolicyStatus' => 'Casbin policy engine status (requires authentication).',
        ];

        $tags = [];
        foreach ($tagDescriptions as $name => $description) {
            $tags[] = ['name' => $name, 'description' => $description];
        }

        return $openApi->withTags($tags);
    }
}
