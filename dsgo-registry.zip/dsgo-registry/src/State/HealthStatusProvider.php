<?php

declare(strict_types=1);

namespace App\State;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;
use App\ApiResource\HealthStatus;

final class HealthStatusProvider implements ProviderInterface
{
    public function provide(Operation $operation, array $uriVariables = [], array $context = []): HealthStatus
    {
        return new HealthStatus(
            status: 'ok',
            service: 'dsgo-authz',
            timestamp: (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
        );
    }
}
