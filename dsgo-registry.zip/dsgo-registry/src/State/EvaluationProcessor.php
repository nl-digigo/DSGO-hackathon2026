<?php

declare(strict_types=1);

namespace App\State;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;
use App\Dto\EvaluationRequest;
use App\Dto\EvaluationResponse;
use App\Service\Evaluation\EvaluationService;
use App\Service\Identity\ApiKeyValidator;
use App\Service\Identity\CallerIdentityExtractor;
use App\Service\Logging\DecisionLogger;
use App\Service\Registry\ParticipantRegistryInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;
use Symfony\Component\Validator\Validator\ValidatorInterface;

final class EvaluationProcessor implements ProcessorInterface
{
    public function __construct(
        private readonly EvaluationService $evaluationService,
        private readonly ValidatorInterface $validator,
        private readonly CallerIdentityExtractor $callerIdentityExtractor,
        private readonly ApiKeyValidator $apiKeyValidator,
        private readonly ParticipantRegistryInterface $participantRegistry,
        private readonly DecisionLogger $decisionLogger,
        private readonly RequestStack $requestStack,
    ) {
    }

    /**
     * @param EvaluationRequest $data
     */
    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = []): EvaluationResponse
    {
        $httpRequest = $this->requestStack->getCurrentRequest();

        // 1. Extract caller identity
        $callerIdentity = $httpRequest !== null
            ? $this->callerIdentityExtractor->extract($httpRequest)
            : null;

        // 2. API key validation
        if ($this->apiKeyValidator->isRequired() && ($callerIdentity === null || $callerIdentity->isAnonymous())) {
            throw new UnauthorizedHttpException('Bearer', 'API key is required');
        }

        // 3. Validate request
        $violations = $this->validator->validate($data);
        if (count($violations) > 0) {
            $messages = [];
            foreach ($violations as $violation) {
                $messages[] = $violation->getPropertyPath() . ': ' . $violation->getMessage();
            }
            throw new UnprocessableEntityHttpException(implode('; ', $messages));
        }

        // 4. Validate subject as participant
        if (!$this->participantRegistry->isValidParticipant($data->subject->id)) {
            throw new AccessDeniedHttpException(
                sprintf('Subject "%s" is not a registered participant', $data->subject->id)
            );
        }

        // 5. Evaluate
        try {
            $response = $this->evaluationService->evaluate($data);
        } catch (\InvalidArgumentException $e) {
            throw new UnprocessableEntityHttpException($e->getMessage(), $e);
        }

        // 6. Log decision
        $correlationId = $httpRequest?->attributes->get('correlation_id')
            ?? $httpRequest?->headers->get('X-Correlation-Id');
        $this->decisionLogger->log($data, $response, $callerIdentity, $correlationId);

        return $response;
    }
}
