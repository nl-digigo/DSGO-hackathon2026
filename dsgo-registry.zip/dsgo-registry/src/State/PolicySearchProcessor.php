<?php

declare(strict_types=1);

namespace App\State;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;
use App\Dto\SearchRequest;
use App\Dto\SearchResponse;
use App\Service\Delegation\DelegationService;
use App\Service\Identity\ApiKeyValidator;
use App\Service\Identity\CallerIdentityExtractor;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;
use Symfony\Component\Validator\Validator\ValidatorInterface;

final class PolicySearchProcessor implements ProcessorInterface
{
    public function __construct(
        private readonly DelegationService $delegationService,
        private readonly ValidatorInterface $validator,
        private readonly CallerIdentityExtractor $callerIdentityExtractor,
        private readonly ApiKeyValidator $apiKeyValidator,
        private readonly RequestStack $requestStack,
    ) {
    }

    /**
     * @param SearchRequest $data
     */
    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = []): SearchResponse
    {
        $httpRequest = $this->requestStack->getCurrentRequest();

        // 1. Extract caller identity
        $callerIdentity = $httpRequest !== null
            ? $this->callerIdentityExtractor->extract($httpRequest)
            : null;

        // 2. API key validation
        if ($this->apiKeyValidator->isRequired() && ($callerIdentity === null || $callerIdentity->isAnonymous())) {
            throw new UnauthorizedHttpException('Bearer', 'API key is required');
        }

        // 3. Validate request
        $violations = $this->validator->validate($data);
        if (count($violations) > 0) {
            $messages = [];
            foreach ($violations as $violation) {
                $messages[] = $violation->getPropertyPath() . ': ' . $violation->getMessage();
            }
            throw new UnprocessableEntityHttpException(implode('; ', $messages));
        }

        // 4. Search delegation evidence (PRP)
        $evidence = $this->delegationService->searchDelegations($data);

        $evidenceArray = array_map(
            fn ($e) => $e->toAuthZenFormat(),
            $evidence,
        );

        return new SearchResponse(delegationEvidence: $evidenceArray);
    }
}
