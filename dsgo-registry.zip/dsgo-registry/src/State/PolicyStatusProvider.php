<?php

declare(strict_types=1);

namespace App\State;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;
use App\ApiResource\PolicyStatus;
use App\Service\Casbin\CasbinAuthorizer;

final class PolicyStatusProvider implements ProviderInterface
{
    public function __construct(
        private readonly CasbinAuthorizer $authorizer,
    ) {
    }

    public function provide(Operation $operation, array $uriVariables = [], array $context = []): PolicyStatus
    {
        $policyLoadedAt = $this->authorizer->getPolicyLoadedAt();

        return new PolicyStatus(
            status: 'ok',
            policyLoadedAt: $policyLoadedAt?->format(\DateTimeInterface::ATOM),
        );
    }
}
