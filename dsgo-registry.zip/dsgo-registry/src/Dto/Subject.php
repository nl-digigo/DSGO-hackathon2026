<?php

declare(strict_types=1);

namespace App\Dto;

use Symfony\Component\Validator\Constraints as Assert;

final class Subject
{
    public function __construct(
        #[Assert\NotBlank]
        public readonly string $type = '',

        #[Assert\NotBlank]
        #[Assert\Regex(
            pattern: '/^(EU\.EORI\..+|did:ishare:.+)$/',
            message: 'Subject ID must be a valid EORI (e.g., EU.EORI.NL000000001) or iSHARE DID (e.g., did:ishare:EU.NL.NTRNL-99999998)'
        )]
        public readonly string $id = '',

        public readonly ?array $properties = null,
    ) {
    }
}
