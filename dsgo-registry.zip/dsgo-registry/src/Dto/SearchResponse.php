<?php

declare(strict_types=1);

namespace App\Dto;

final class SearchResponse
{
    /**
     * @param array<array<string, mixed>> $delegationEvidence
     */
    public function __construct(
        public readonly array $delegationEvidence = [],
    ) {
    }
}
