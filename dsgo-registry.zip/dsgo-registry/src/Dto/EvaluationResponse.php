<?php

declare(strict_types=1);

namespace App\Dto;

final class EvaluationResponse
{
    public function __construct(
        public readonly bool $decision,
        public readonly ?array $context = null,
    ) {
    }
}
