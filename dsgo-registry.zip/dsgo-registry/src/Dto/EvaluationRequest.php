<?php

declare(strict_types=1);

namespace App\Dto;

use Symfony\Component\Validator\Constraints as Assert;

final class EvaluationRequest
{
    public function __construct(
        #[Assert\NotNull]
        #[Assert\Valid]
        public readonly ?Subject $subject = null,

        #[Assert\NotNull]
        #[Assert\Valid]
        public readonly ?Resource $resource = null,

        #[Assert\NotNull]
        #[Assert\Valid]
        public readonly ?Action $action = null,

        public readonly ?array $context = null,
    ) {
    }
}
