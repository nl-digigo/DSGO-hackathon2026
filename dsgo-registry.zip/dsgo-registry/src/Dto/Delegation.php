<?php

declare(strict_types=1);

namespace App\Dto;

use Symfony\Component\Validator\Constraints as Assert;

/**
 * Minimal delegation model: identifies who delegated (issuer), under which license,
 * and optionally a URL for retrieving additional evidence.
 *
 * Supports nesting via issuer.properties.delegation (max depth 5).
 */
final class Delegation
{
    public function __construct(
        #[Assert\NotNull]
        #[Assert\Valid]
        public readonly ?Subject $issuer = null,

        #[Assert\NotBlank]
        public readonly string $license = '',

        public readonly ?string $url = null,
    ) {
    }
}
