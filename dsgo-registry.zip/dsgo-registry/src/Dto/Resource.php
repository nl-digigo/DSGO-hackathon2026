<?php

declare(strict_types=1);

namespace App\Dto;

use Symfony\Component\Validator\Constraints as Assert;

final class Resource
{
    public function __construct(
        #[Assert\NotBlank]
        public readonly string $type = '',

        #[Assert\NotBlank]
        public readonly string $id = '',

        public readonly ?array $properties = null,
    ) {
    }
}
