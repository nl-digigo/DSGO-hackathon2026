<?php

declare(strict_types=1);

namespace App\Dto;

use Symfony\Component\Validator\Constraints as Assert;

final class Action
{
    public const VALID_NAMES = ['can_access', 'can_create', 'can_read', 'can_update', 'can_delete'];

    public function __construct(
        #[Assert\NotBlank]
        #[Assert\Choice(
            choices: self::VALID_NAMES,
            message: 'Action must be one of: can_access, can_create, can_read, can_update, can_delete'
        )]
        public readonly string $name = '',

        public readonly ?array $properties = null,
    ) {
    }
}
