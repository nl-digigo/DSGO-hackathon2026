<?php

declare(strict_types=1);

namespace App\Dto;

use Symfony\Component\Validator\Constraints as Assert;

/**
 * Policy Retrieval Point request: find delegation evidence
 * for a given issuer -> subject -> resource combination.
 */
final class SearchRequest
{
    public function __construct(
        #[Assert\NotNull]
        #[Assert\Valid]
        public readonly ?Subject $issuer = null,

        #[Assert\NotNull]
        #[Assert\Valid]
        public readonly ?Subject $subject = null,

        #[Assert\NotNull]
        #[Assert\Valid]
        public readonly ?Resource $resource = null,
    ) {
    }
}
