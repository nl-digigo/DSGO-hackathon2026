<?php

declare(strict_types=1);

namespace App\Repository;

use App\Entity\PolicyRule;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<PolicyRule>
 */
class PolicyRuleRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, PolicyRule::class);
    }

    /**
     * Find policies matching subject and action. Resource matching is done in PHP
     * via CasbinAuthorizer to stay consistent with Casbin's keyMatch2 pattern logic.
     *
     * @return PolicyRule[]
     */
    public function findBySubjectAndAction(string $subject, string $action): array
    {
        return $this->createQueryBuilder('p')
            ->andWhere('p.ptype = :ptype')
            ->andWhere('p.v0 = :subject')
            ->andWhere('p.v2 = :action')
            ->setParameter('ptype', 'p')
            ->setParameter('subject', $subject)
            ->setParameter('action', $action)
            ->getQuery()
            ->getResult();
    }

    /**
     * Find policies for a specific subject
     * 
     * @return PolicyRule[]
     */
    public function findBySubject(string $subject): array
    {
        return $this->createQueryBuilder('p')
            ->andWhere('p.ptype = :ptype')
            ->andWhere('p.v0 = :subject')
            ->setParameter('ptype', 'p')
            ->setParameter('subject', $subject)
            ->orderBy('p.v1', 'ASC')
            ->getQuery()
            ->getResult();
    }

    /**
     * Delete a policy by its components
     */
    public function deletePolicy(string $ptype, string $v0, string $v1, string $v2): int
    {
        return $this->createQueryBuilder('p')
            ->delete()
            ->andWhere('p.ptype = :ptype')
            ->andWhere('p.v0 = :v0')
            ->andWhere('p.v1 = :v1')
            ->andWhere('p.v2 = :v2')
            ->setParameter('ptype', $ptype)
            ->setParameter('v0', $v0)
            ->setParameter('v1', $v1)
            ->setParameter('v2', $v2)
            ->getQuery()
            ->execute();
    }

    /**
     * Get unique subjects
     * 
     * @return string[]
     */
    public function getUniqueSubjects(): array
    {
        $result = $this->createQueryBuilder('p')
            ->select('DISTINCT p.v0')
            ->andWhere('p.ptype = :ptype')
            ->setParameter('ptype', 'p')
            ->orderBy('p.v0', 'ASC')
            ->getQuery()
            ->getSingleColumnResult();

        return $result;
    }

    /**
     * Clear all policies
     */
    public function clearAll(): int
    {
        return $this->createQueryBuilder('p')
            ->delete()
            ->getQuery()
            ->execute();
    }

}
