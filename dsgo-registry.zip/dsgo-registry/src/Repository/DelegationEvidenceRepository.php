<?php

declare(strict_types=1);

namespace App\Repository;

use App\Entity\DelegationEvidence;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<DelegationEvidence>
 */
class DelegationEvidenceRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, DelegationEvidence::class);
    }

    /**
     * Find delegation evidence by issuer, subject, and resource.
     *
     * @return DelegationEvidence[]
     */
    public function findByIssuerSubjectResource(
        string $issuerId,
        string $subjectId,
        string $resourceId,
    ): array {
        return $this->createQueryBuilder('d')
            ->andWhere('d.issuerId = :issuerId')
            ->andWhere('d.subjectId = :subjectId')
            ->andWhere('d.resourceId = :resourceId')
            ->setParameter('issuerId', $issuerId)
            ->setParameter('subjectId', $subjectId)
            ->setParameter('resourceId', $resourceId)
            ->orderBy('d.createdAt', 'DESC')
            ->getQuery()
            ->getResult();
    }

    /**
     * Check if a matching delegation evidence record already exists.
     */
    public function exists(
        string $issuerId,
        string $subjectId,
        string $resourceId,
        string $actionName,
    ): bool {
        $count = $this->createQueryBuilder('d')
            ->select('COUNT(d.id)')
            ->andWhere('d.issuerId = :issuerId')
            ->andWhere('d.subjectId = :subjectId')
            ->andWhere('d.resourceId = :resourceId')
            ->andWhere('d.actionName = :actionName')
            ->setParameter('issuerId', $issuerId)
            ->setParameter('subjectId', $subjectId)
            ->setParameter('resourceId', $resourceId)
            ->setParameter('actionName', $actionName)
            ->getQuery()
            ->getSingleScalarResult();

        return $count > 0;
    }

}
