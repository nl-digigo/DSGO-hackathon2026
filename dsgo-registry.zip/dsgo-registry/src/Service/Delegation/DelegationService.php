<?php

declare(strict_types=1);

namespace App\Service\Delegation;

use App\Dto\Delegation;
use App\Dto\SearchRequest;
use App\Dto\Subject;
use App\Entity\DelegationEvidence;
use App\Repository\DelegationEvidenceRepository;
use App\Service\Registry\ParticipantRegistryInterface;
use Doctrine\ORM\EntityManagerInterface;

class DelegationService
{
    private const MAX_NESTING_DEPTH = 5;

    public function __construct(
        private readonly DelegationEvidenceRepository $repository,
        private readonly ParticipantRegistryInterface $participantRegistry,
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    /**
     * Validate the delegation chain on a subject. Returns the resolved issuer
     * EORI (the original delegator at the root of the chain) or null if no delegation.
     *
     * @throws \InvalidArgumentException on validation failure
     */
    public function validateDelegation(Subject $subject): ?string
    {
        $delegation = $this->extractDelegation($subject);
        if ($delegation === null) {
            return null;
        }

        return $this->validateChain($delegation, 1);
    }

    /**
     * Automatically store delegation evidence from an evaluation request's subject,
     * if delegation info is present and not already stored.
     */
    public function storeFromSubject(Subject $subject, string $resourceId, string $actionName): void
    {
        $delegation = $this->extractDelegation($subject);
        if ($delegation === null) {
            return;
        }

        $alreadyExists = $this->repository->exists(
            $delegation->issuer->id,
            $subject->id,
            $resourceId,
            $actionName,
        );

        if ($alreadyExists) {
            return;
        }

        $evidence = new DelegationEvidence();
        $evidence->setIssuerType($delegation->issuer->type);
        $evidence->setIssuerId($delegation->issuer->id);
        $evidence->setSubjectType($subject->type);
        $evidence->setSubjectId($subject->id);
        $evidence->setResourceType('api');
        $evidence->setResourceId($resourceId);
        $evidence->setActionName($actionName);
        if ($delegation->url !== null) {
            $evidence->setContextUrl($delegation->url);
        }
        $evidence->setActionProperties(['license' => $delegation->license]);

        $this->entityManager->persist($evidence);
        $this->entityManager->flush();
    }

    /**
     * PRP lookup: find delegation evidence matching issuer + subject + resource.
     *
     * @return DelegationEvidence[]
     */
    public function searchDelegations(SearchRequest $request): array
    {
        return $this->repository->findByIssuerSubjectResource(
            $request->issuer->id,
            $request->subject->id,
            $request->resource->id,
        );
    }

    private function extractDelegation(Subject $subject): ?Delegation
    {
        if ($subject->properties === null || !isset($subject->properties['delegation'])) {
            return null;
        }

        $data = $subject->properties['delegation'];

        $issuer = new Subject(
            type: $data['issuer']['type'] ?? '',
            id: $data['issuer']['id'] ?? '',
            properties: $data['issuer']['properties'] ?? null,
        );

        return new Delegation(
            issuer: $issuer,
            license: $data['license'] ?? '',
            url: $data['url'] ?? null,
        );
    }

    private function validateChain(Delegation $delegation, int $depth): string
    {
        if ($depth > self::MAX_NESTING_DEPTH) {
            throw new \InvalidArgumentException(
                sprintf('Delegation chain exceeds maximum nesting depth of %d', self::MAX_NESTING_DEPTH)
            );
        }

        if (!$this->participantRegistry->isValidParticipant($delegation->issuer->id)) {
            throw new \InvalidArgumentException(
                sprintf('Delegation issuer "%s" is not a valid participant', $delegation->issuer->id)
            );
        }

        $nestedDelegation = $this->extractDelegation($delegation->issuer);
        if ($nestedDelegation !== null) {
            return $this->validateChain($nestedDelegation, $depth + 1);
        }

        return $delegation->issuer->id;
    }
}
