<?php

declare(strict_types=1);

namespace App\Service\Casbin;

use App\Entity\PolicyRule;
use App\Repository\PolicyRuleRepository;
use Casbin\Util\BuiltinOperations;

/**
 * Authorization service using Casbin for basic sub/obj/act enforcement
 * and direct DB queries for property-level matching.
 */
class CasbinAuthorizer
{
    public function __construct(
        private readonly EnforcerFactory $enforcerFactory,
        private readonly PolicyRuleRepository $policyRuleRepository,
    ) {
    }

    /**
     * Check if the subject is permitted to perform the action on the resource
     * at the Casbin (sub/obj/act) level.
     */
    public function isPermitted(string $subject, string $object, string $action): bool
    {
        $enforcer = $this->enforcerFactory->getEnforcer();

        return $enforcer->enforce($subject, $object, $action);
    }

    /**
     * Get all PolicyRule entities that match the sub/obj/act triple.
     * Uses Casbin for the initial check, then queries DB by subject+action
     * and filters by resource using the same keyMatch2 logic as model.conf.
     *
     * @return PolicyRule[]
     */
    public function getMatchingPolicies(string $subject, string $object, string $action): array
    {
        if (!$this->isPermitted($subject, $object, $action)) {
            return [];
        }

        $candidates = $this->policyRuleRepository->findBySubjectAndAction($subject, $action);

        return array_values(array_filter(
            $candidates,
            fn (PolicyRule $p) => BuiltinOperations::keyMatch2($object, $p->getV1()),
        ));
    }

    public function getPolicyLoadedAt(): ?\DateTimeImmutable
    {
        return $this->enforcerFactory->getLoadedAt();
    }

}
