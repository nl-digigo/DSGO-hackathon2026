<?php

declare(strict_types=1);

namespace App\Service\Casbin;

use App\Entity\PolicyRule;
use App\Repository\PolicyRuleRepository;
use Casbin\Model\Model;
use Casbin\Persist\Adapter;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Doctrine adapter for Casbin policy storage.
 * 
 * Implements the Casbin Adapter interface to load/save policies from the database.
 */
final class DoctrinePolicyAdapter implements Adapter
{
    public function __construct(
        private readonly PolicyRuleRepository $repository,
        private readonly EntityManagerInterface $entityManager,
    ) {
    }

    /**
     * Load all policy rules from the database into the model.
     */
    public function loadPolicy(Model $model): void
    {
        $policies = $this->repository->findAll();

        foreach ($policies as $policy) {
            $this->loadPolicyLine($policy, $model);
        }
    }

    /**
     * Save all policy rules from the model to the database.
     * This performs a full sync (clears existing and inserts new).
     */
    public function savePolicy(Model $model): void
    {
        // Clear existing policies
        $this->repository->clearAll();

        // Save 'p' policies
        if (isset($model['p'])) {
            foreach ($model['p'] as $ptype => $ast) {
                foreach ($ast->policy as $rule) {
                    $this->savePolicyLine($ptype, $rule);
                }
            }
        }

        // Save 'g' grouping policies (role mappings)
        if (isset($model['g'])) {
            foreach ($model['g'] as $ptype => $ast) {
                foreach ($ast->policy as $rule) {
                    $this->savePolicyLine($ptype, $rule);
                }
            }
        }

        $this->entityManager->flush();
    }

    /**
     * Add a policy rule to the database.
     * 
     * @param string $sec The section ('p' or 'g')
     * @param string $ptype The policy type
     * @param array<string> $rule The policy rule
     */
    public function addPolicy(string $sec, string $ptype, array $rule): void
    {
        $this->savePolicyLine($ptype, $rule);
        $this->entityManager->flush();
    }

    /**
     * Remove a policy rule from the database.
     * 
     * @param string $sec The section ('p' or 'g')
     * @param string $ptype The policy type
     * @param array<string> $rule The policy rule
     */
    public function removePolicy(string $sec, string $ptype, array $rule): void
    {
        $this->repository->deletePolicy(
            $ptype,
            $rule[0] ?? '',
            $rule[1] ?? '',
            $rule[2] ?? ''
        );
    }

    /**
     * Remove filtered policy rules from the database.
     * 
     * @param string $sec The section ('p' or 'g')
     * @param string $ptype The policy type
     * @param int $fieldIndex The field index to start filtering from
     * @param string ...$fieldValues The field values to filter by
     */
    public function removeFilteredPolicy(string $sec, string $ptype, int $fieldIndex, string ...$fieldValues): void
    {
        $qb = $this->entityManager->createQueryBuilder()
            ->delete(PolicyRule::class, 'p')
            ->andWhere('p.ptype = :ptype')
            ->setParameter('ptype', $ptype);

        $fields = ['v0', 'v1', 'v2', 'v3', 'v4', 'v5'];
        
        foreach ($fieldValues as $i => $value) {
            if ($value !== '') {
                $field = $fields[$fieldIndex + $i] ?? null;
                if ($field !== null) {
                    $qb->andWhere("p.{$field} = :field{$i}")
                        ->setParameter("field{$i}", $value);
                }
            }
        }

        $qb->getQuery()->execute();
    }

    /**
     * Load a single policy line into the model.
     */
    private function loadPolicyLine(PolicyRule $policy, Model $model): void
    {
        $ptype = $policy->getPtype();
        // Only load the first 3 fields (sub, obj, act) into Casbin.
        // Extended fields (v3-v5) are handled by PropertyMatcher outside Casbin.
        $rule = [$policy->getV0(), $policy->getV1(), $policy->getV2()];

        $sec = str_starts_with($ptype, 'g') ? 'g' : 'p';

        $model->addPolicy($sec, $ptype, $rule);
    }

    /**
     * Save a single policy rule to the database.
     * 
     * @param string $ptype The policy type
     * @param array<string> $rule The policy rule
     */
    private function savePolicyLine(string $ptype, array $rule): void
    {
        $policy = PolicyRule::fromRuleArray($ptype, $rule);
        $this->entityManager->persist($policy);
    }
}
