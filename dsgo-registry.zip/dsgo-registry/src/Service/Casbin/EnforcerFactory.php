<?php

declare(strict_types=1);

namespace App\Service\Casbin;

use Casbin\Enforcer;

/**
 * Factory for creating and managing the Casbin Enforcer instance.
 * 
 * Provides a singleton enforcer with TTL-based automatic refresh.
 */
class EnforcerFactory
{
    private ?Enforcer $enforcer = null;
    private ?\DateTimeImmutable $loadedAt = null;

    public function __construct(
        private readonly DoctrinePolicyAdapter $adapter,
        private readonly string $modelPath,
        private readonly int $refreshTtlSeconds = 60,
    ) {
    }

    /**
     * Get the Casbin Enforcer instance.
     * 
     * Creates a new instance or refreshes the existing one if TTL has expired.
     */
    public function getEnforcer(): Enforcer
    {
        if ($this->shouldRefresh()) {
            $this->refresh();
        }

        return $this->enforcer;
    }

    /**
     * Force a refresh of the enforcer, reloading policies from the database.
     */
    public function forceRefresh(): void
    {
        $this->enforcer = null;
        $this->loadedAt = null;
    }

    /**
     * Get the timestamp when policies were last loaded.
     */
    public function getLoadedAt(): ?\DateTimeImmutable
    {
        return $this->loadedAt;
    }

    /**
     * Check if the enforcer needs to be refreshed.
     */
    private function shouldRefresh(): bool
    {
        if ($this->enforcer === null) {
            return true;
        }

        if ($this->loadedAt === null) {
            return true;
        }

        $expiresAt = $this->loadedAt->modify("+{$this->refreshTtlSeconds} seconds");
        
        return new \DateTimeImmutable() > $expiresAt;
    }

    /**
     * Refresh the enforcer by creating a new instance and loading policies.
     */
    private function refresh(): void
    {
        $this->enforcer = new Enforcer($this->modelPath, $this->adapter);
        $this->loadedAt = new \DateTimeImmutable();
    }
}
