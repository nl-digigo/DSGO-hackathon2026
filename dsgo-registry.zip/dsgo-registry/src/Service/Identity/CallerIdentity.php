<?php

declare(strict_types=1);

namespace App\Service\Identity;

/**
 * Value object representing the identity of an API caller (data service provider).
 */
final readonly class CallerIdentity
{
    public function __construct(
        /**
         * The unique identifier of the data service provider making the API call.
         */
        public string $dataServiceId,
        
        /**
         * The source of the identity (how it was determined).
         * Possible values: "api_key", "header", "mtls"
         */
        public string $source,
        
        /**
         * Optional raw value from which the identity was extracted.
         */
        public ?string $rawValue = null,
    ) {
    }

    /**
     * Create an anonymous/unknown caller identity.
     */
    public static function anonymous(): self
    {
        return new self(
            dataServiceId: 'anonymous',
            source: 'none',
        );
    }

    /**
     * Check if this is an anonymous caller.
     */
    public function isAnonymous(): bool
    {
        return $this->dataServiceId === 'anonymous';
    }
}
