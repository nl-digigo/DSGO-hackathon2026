<?php

declare(strict_types=1);

namespace App\Service\Identity;

use Symfony\Component\HttpFoundation\Request;

/**
 * Extracts caller identity from incoming HTTP requests.
 * 
 * Supports multiple extraction methods:
 * - API key header
 * - Custom identity header
 * - mTLS client certificate (via proxy headers)
 */
final class CallerIdentityExtractor
{
    private const HEADER_API_KEY = 'X-API-Key';
    private const HEADER_DATA_SERVICE_ID = 'X-Data-Service-Id';
    private const HEADER_SSL_CLIENT_DN = 'X-SSL-Client-DN';

    public function __construct(
        private readonly ApiKeyValidator $apiKeyValidator,
    ) {
    }

    /**
     * Extract caller identity from the request.
     * 
     * Tries multiple extraction methods in order:
     * 1. API key
     * 2. Data service ID header
     * 3. mTLS client certificate DN
     * 
     * Returns anonymous identity if none found.
     */
    public function extract(Request $request): CallerIdentity
    {
        // Try API key first
        $apiKey = $request->headers->get(self::HEADER_API_KEY);
        if ($apiKey !== null) {
            $dataServiceId = $this->apiKeyValidator->validate($apiKey);
            if ($dataServiceId !== null) {
                return new CallerIdentity(
                    dataServiceId: $dataServiceId,
                    source: 'api_key',
                    rawValue: $apiKey,
                );
            }
        }

        // Try data service ID header
        $dataServiceId = $request->headers->get(self::HEADER_DATA_SERVICE_ID);
        if ($dataServiceId !== null && $dataServiceId !== '') {
            return new CallerIdentity(
                dataServiceId: $dataServiceId,
                source: 'header',
                rawValue: $dataServiceId,
            );
        }

        // Try mTLS client certificate DN
        $clientDn = $request->headers->get(self::HEADER_SSL_CLIENT_DN);
        if ($clientDn !== null && $clientDn !== '') {
            $dataServiceId = $this->extractFromDn($clientDn);
            if ($dataServiceId !== null) {
                return new CallerIdentity(
                    dataServiceId: $dataServiceId,
                    source: 'mtls',
                    rawValue: $clientDn,
                );
            }
        }

        // No identity found - return anonymous
        return CallerIdentity::anonymous();
    }

    /**
     * Extract data service ID from a certificate DN (Distinguished Name).
     * 
     * Looks for CN (Common Name) or O (Organization) fields.
     * Example DN: "CN=data-service-a,O=Company A,C=NL"
     */
    private function extractFromDn(string $dn): ?string
    {
        // Try to extract CN (Common Name)
        if (preg_match('/CN=([^,]+)/', $dn, $matches)) {
            return trim($matches[1]);
        }

        // Fall back to O (Organization)
        if (preg_match('/O=([^,]+)/', $dn, $matches)) {
            return trim($matches[1]);
        }

        return null;
    }
}
