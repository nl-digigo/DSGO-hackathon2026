<?php

declare(strict_types=1);

namespace App\Service\Identity;

/**
 * Validates API keys for caller authentication.
 * 
 * For PoC: Uses a simple configuration-based approach.
 * In production: Could use database storage, caching, etc.
 */
class ApiKeyValidator
{
    /**
     * Map of API key -> data service ID.
     * 
     * @var array<string, string>
     */
    private array $validKeys = [];

    /**
     * @param string|null $apiKeysConfig Comma-separated list of "id:key" pairs
     *                                   Example: "service-a:secret123,service-b:secret456"
     */
    public function __construct(
        ?string $apiKeysConfig = '',
        private readonly bool $requireApiKey = false,
    ) {
        $this->parseConfig($apiKeysConfig ?? '');
    }

    /**
     * Validate an API key and return the associated data service ID.
     * 
     * @return string|null The data service ID if valid, null otherwise
     */
    public function validate(string $apiKey): ?string
    {
        return $this->validKeys[$apiKey] ?? null;
    }

    /**
     * Check if API key validation is required.
     */
    public function isRequired(): bool
    {
        return $this->requireApiKey;
    }

    /**
     * Check if API key authentication is enabled (has any configured keys).
     */
    public function isEnabled(): bool
    {
        return !empty($this->validKeys);
    }

    /**
     * Parse the API keys configuration string.
     * 
     * Format: "id1:key1,id2:key2,..."
     */
    private function parseConfig(string $config): void
    {
        if (empty($config)) {
            return;
        }

        $pairs = explode(',', $config);
        foreach ($pairs as $pair) {
            $parts = explode(':', trim($pair), 2);
            if (count($parts) === 2) {
                $dataServiceId = trim($parts[0]);
                $apiKey = trim($parts[1]);
                if ($dataServiceId !== '' && $apiKey !== '') {
                    $this->validKeys[$apiKey] = $dataServiceId;
                }
            }
        }
    }
}
