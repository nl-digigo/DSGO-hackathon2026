<?php

declare(strict_types=1);

namespace App\Service\Logging;

use App\Dto\EvaluationRequest;
use App\Dto\EvaluationResponse;
use App\Evidence\CanonicalDecisionPayload;
use App\Evidence\EvidenceRecorderInterface;
use App\Service\Identity\CallerIdentity;
use Psr\Log\LoggerInterface;

final class DecisionLogger
{
    public function __construct(
        private readonly LoggerInterface $logger,
        private readonly EvidenceRecorderInterface $evidenceRecorder,
    ) {
    }

    public function log(
        EvaluationRequest $request,
        EvaluationResponse $response,
        ?CallerIdentity $callerIdentity = null,
        ?string $correlationId = null,
    ): void {
        $context = [
            'correlation_id' => $correlationId,
            'subject_type' => $request->subject->type,
            'subject_id' => $request->subject->id,
            'resource_type' => $request->resource->type,
            'resource_id' => $request->resource->id,
            'action' => $request->action->name,
            'decision' => $response->decision ? 'permit' : 'deny',
        ];

        if ($request->resource->properties !== null) {
            $context['service_provider'] = $request->resource->properties['service_provider'] ?? null;
        }

        if ($request->action->properties !== null) {
            $context['method'] = $request->action->properties['method'] ?? null;
            $context['license'] = $request->action->properties['license'] ?? null;
        }

        if ($request->subject->properties !== null && isset($request->subject->properties['delegation'])) {
            $context['delegation_issuer'] = $request->subject->properties['delegation']['issuer']['id'] ?? null;
        }

        if ($callerIdentity !== null) {
            $context['caller_data_service_id'] = $callerIdentity->dataServiceId;
            $context['caller_source'] = $callerIdentity->source;
        }

        $this->logger->info('Authorization decision', $context);

        $payload = CanonicalDecisionPayload::fromEvaluation($request, $response, $correlationId);
        $this->evidenceRecorder->record($payload);
    }
}
