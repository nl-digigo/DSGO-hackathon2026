<?php

declare(strict_types=1);

namespace App\Service\Evaluation;

use App\Dto\EvaluationRequest;

/**
 * Maps an AuthZen EvaluationRequest to Casbin enforcement arguments
 * and extracts extended properties for PropertyMatcher.
 */
final class RequestMapper
{
    /**
     * @return array{sub: string, obj: string, act: string, properties: array<string, mixed>}
     */
    public function map(EvaluationRequest $request): array
    {
        $properties = [];

        if ($request->resource->properties !== null) {
            if (isset($request->resource->properties['service_provider'])) {
                $properties['service_provider'] = $request->resource->properties['service_provider'];
            }
        }

        if ($request->action->properties !== null) {
            if (isset($request->action->properties['method'])) {
                $properties['method'] = $request->action->properties['method'];
            }
            if (isset($request->action->properties['license'])) {
                $properties['license'] = $request->action->properties['license'];
            }
        }

        return [
            'sub' => $request->subject->id,
            'obj' => $request->resource->id,
            'act' => $request->action->name,
            'properties' => $properties,
        ];
    }
}
