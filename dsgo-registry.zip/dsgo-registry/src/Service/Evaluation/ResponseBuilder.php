<?php

declare(strict_types=1);

namespace App\Service\Evaluation;

use App\Dto\EvaluationRequest;
use App\Dto\EvaluationResponse;

/**
 * Builds EvaluationResponse objects with the appropriate context
 * for deny reasons and partial authorization.
 */
final class ResponseBuilder
{
    public function permit(): EvaluationResponse
    {
        return new EvaluationResponse(decision: true);
    }

    public function partialPermit(EvaluationRequest $request, array $partialContext): EvaluationResponse
    {
        $resourceContext = [
            'type' => $request->resource->type,
            'id' => $request->resource->id,
            'properties' => array_merge(
                $request->resource->properties ?? [],
                $partialContext,
            ),
        ];

        return new EvaluationResponse(
            decision: true,
            context: ['resource' => $resourceContext],
        );
    }

    public function deny(): EvaluationResponse
    {
        $context = [
            'reason_admin' => [
                'en' => 'No matching policy found',
            ],
            'reason_user' => [
                'en' => 'Insufficient privileges. Contact your administrator.',
            ],
        ];

        return new EvaluationResponse(decision: false, context: $context);
    }
}
