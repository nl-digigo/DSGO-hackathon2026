<?php

declare(strict_types=1);

namespace App\Service\Evaluation;

use App\Entity\PolicyRule;

/**
 * Evaluates AuthZen properties (service_provider, method, license) against
 * PolicyRule v3-v5 fields. Builds partial authorization context when applicable.
 */
final class PropertyMatcher
{
    /**
     * Filter matching policies by their extended property fields (v3-v5).
     *
     * @param PolicyRule[] $policies  Casbin-matched policies (sub/obj/act already match)
     * @param array<string, mixed> $properties  Extracted request properties
     * @return array{matched: PolicyRule[], partialContext: ?array}
     */
    public function match(array $policies, array $properties): array
    {
        $matched = [];
        $partialContext = null;

        foreach ($policies as $policy) {
            if (!$this->matchesProperties($policy, $properties)) {
                continue;
            }

            $matched[] = $policy;

            if ($policy->getPartialContext() !== null) {
                $partialContext = $this->mergePartialContext($partialContext, $policy->getPartialContext());
            }
        }

        return [
            'matched' => $matched,
            'partialContext' => $partialContext,
        ];
    }

    private function matchesProperties(PolicyRule $policy, array $properties): bool
    {
        if (!$this->fieldMatches($policy->getServiceProvider(), $properties['service_provider'] ?? null)) {
            return false;
        }

        if (!$this->fieldMatches($policy->getMethod(), $properties['method'] ?? null)) {
            return false;
        }

        if (!$this->fieldMatches($policy->getLicense(), $properties['license'] ?? null)) {
            return false;
        }

        return true;
    }

    /**
     * A policy field matches if:
     * - the policy field is null (no constraint)
     * - the policy field is '*' (wildcard)
     * - the policy field equals the request value (case-insensitive for methods)
     * - the request value is null (property not provided, matches any policy field)
     */
    private function fieldMatches(?string $policyValue, mixed $requestValue): bool
    {
        if ($policyValue === null || $policyValue === '*') {
            return true;
        }

        if ($requestValue === null) {
            return true;
        }

        return strtoupper((string) $policyValue) === strtoupper((string) $requestValue);
    }

    private function mergePartialContext(?array $existing, array $new): array
    {
        if ($existing === null) {
            return $new;
        }

        $merged = $existing;

        if (isset($new['identifiers'])) {
            $merged['identifiers'] = array_values(array_unique(
                array_merge($merged['identifiers'] ?? [], $new['identifiers'])
            ));
        }

        if (isset($new['attributes'])) {
            $merged['attributes'] = array_values(array_unique(
                array_merge($merged['attributes'] ?? [], $new['attributes'])
            ));
        }

        return $merged;
    }
}
