<?php

declare(strict_types=1);

namespace App\Service\Evaluation;

use App\Dto\EvaluationRequest;
use App\Dto\EvaluationResponse;
use App\Service\Casbin\CasbinAuthorizer;
use App\Service\Delegation\DelegationService;

/**
 * Central facade for authorization evaluation.
 * Orchestrates request mapping, Casbin enforcement, property matching,
 * delegation validation, and response building.
 */
final class EvaluationService
{
    public function __construct(
        private readonly RequestMapper $requestMapper,
        private readonly CasbinAuthorizer $casbinAuthorizer,
        private readonly PropertyMatcher $propertyMatcher,
        private readonly DelegationService $delegationService,
        private readonly ResponseBuilder $responseBuilder,
    ) {
    }

    public function evaluate(EvaluationRequest $request): EvaluationResponse
    {
        // 1. Map AuthZen request to Casbin args + extracted properties
        $mapped = $this->requestMapper->map($request);

        // 2. Validate delegation chain if present
        $this->delegationService->validateDelegation($request->subject);

        // 3. Get policies matching at Casbin level (sub/obj/act)
        $policies = $this->casbinAuthorizer->getMatchingPolicies(
            $mapped['sub'],
            $mapped['obj'],
            $mapped['act'],
        );

        if (empty($policies)) {
            return $this->responseBuilder->deny();
        }

        // 4. Match extended properties (service_provider, method, license) against v3-v5
        $result = $this->propertyMatcher->match($policies, $mapped['properties']);

        if (empty($result['matched'])) {
            return $this->responseBuilder->deny();
        }

        // 5. Auto-store delegation evidence if present
        $this->delegationService->storeFromSubject(
            $request->subject,
            $request->resource->id,
            $request->action->name,
        );

        // 6. Build response: partial permit or full permit
        if ($result['partialContext'] !== null) {
            return $this->responseBuilder->partialPermit($request, $result['partialContext']);
        }

        return $this->responseBuilder->permit();
    }
}
