<?php

declare(strict_types=1);

namespace App\Service\Registry;

/**
 * No-op participant registry that accepts all participants.
 * 
 * Used for PoC when no external registry is configured.
 */
final class NullParticipantRegistry implements ParticipantRegistryInterface
{
    public function isValidParticipant(string $participantId): bool
    {
        // Accept all participants in PoC mode
        return true;
    }
}
