<?php

declare(strict_types=1);

namespace App\Service\Registry;

/**
 * Interface for validating participants against an external registry.
 */
interface ParticipantRegistryInterface
{
    /**
     * Check if a participant ID is valid/registered.
     * 
     * @param string $participantId The participant ID to validate (e.g., "EU.EORI.NL000000001")
     * @return bool True if valid, false otherwise
     */
    public function isValidParticipant(string $participantId): bool;
}
