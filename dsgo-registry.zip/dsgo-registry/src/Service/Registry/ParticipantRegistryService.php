<?php

declare(strict_types=1);

namespace App\Service\Registry;

use App\Controller\TokenController;
use App\Util\JwtKeyPaths;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * Validates participants against the Digigo DSGO Participant Registry.
 *
 * Authenticates with Digigo via JWT client assertion, then checks the
 * /parties endpoint for active dataspace membership and ServiceConsumer role.
 */
readonly class ParticipantRegistryService implements ParticipantRegistryInterface
{
    private const DIGIGO_BASE = 'https://api.acceptance.digigo.nu';
    private const DIGIGO_AUDIENCE = 'did:ishare:EU.NL.NTRNL-63202158';

    /**
     * Test party IDs in Digigo acceptance without a ServiceConsumer role claim yet.
     * For these IDs only: still require an active dataspaceMembership claim; the
     * ServiceConsumer role requirement is waived so local/token-creator flows work.
     * Remove this list once Digigo assigns ServiceConsumer to these parties.
     */
    private const TEST_PARTY_IDS = [
        'NTRNL-99999998',
        'NTRNL-99999999',
    ];

    public function __construct(
        private HttpClientInterface $httpClient
    ) {
    }

    public function isValidParticipant(string $participantId): bool
    {
        return $this->validateOrganisation($participantId);
    }

    /**
     * Validates that the given participant is an active DSGO member, and has the
     * ServiceConsumer role unless they are listed in TEST_PARTY_IDS.
     *
     * Uses the Digigo Participant Registry API v1:
     *   GET /api/v1/parties/{partyId}?format=json
     */
    public function validateOrganisation(string $participantId): bool
    {
        $token = $this->authenticate();

        $partyDid = $this->toDidFormat($participantId);
        $url = self::DIGIGO_BASE . '/api/v1/parties/' . urlencode($partyDid) . '?' . http_build_query([
            'format' => 'json',
        ]);

        $response = $this->httpClient->request('GET', $url, [
            'headers' => ['Authorization' => 'Bearer ' . $token],
        ]);

        $statusCode = $response->getStatusCode();

        if ($statusCode === 404) {
            return false;
        }

        if ($statusCode >= 400) {
            throw new \RuntimeException(sprintf(
                'Digigo parties lookup failed for "%s": HTTP %d',
                $partyDid,
                $statusCode,
            ));
        }

        $party = $response->toArray(false);

        if (!isset($party['claims']) || !is_array($party['claims'])) {
            return false;
        }

        $hasActiveMembership = false;
        $hasServiceConsumerRole = false;

        foreach ($party['claims'] as $claim) {
            $status = $claim['status'] ?? '';
            $type = $claim['type'] ?? '';

            if ($type === 'dataspaceMembership' && $status === 'Active') {
                $hasActiveMembership = true;
            }

            if ($type === 'dataspaceRole' && $status === 'Active' && ($claim['roleId'] ?? '') === 'ServiceConsumer') {
                $hasServiceConsumerRole = true;
            }
        }

        // Always require active dataspace membership (including for TEST_PARTY_IDS).
        if (!$hasActiveMembership) {
            return false;
        }

        if ($hasServiceConsumerRole) {
            return true;
        }

        // TEST_PARTY_IDS: membership already verified above; waive ServiceConsumer only.
        foreach (self::TEST_PARTY_IDS as $testId) {
            if (str_contains($partyDid, $testId)) {
                return true;
            }
        }

        return false;
    }

    private function toDidFormat(string $identifier): string
    {
        if (str_starts_with($identifier, 'did:ishare:')) {
            return $identifier;
        }
        if (str_starts_with($identifier, 'EU.NL.')) {
            return 'did:ishare:' . $identifier;
        }
        return 'did:ishare:EU.NL.' . $identifier;
    }

    private function authenticate(): string
    {
        $clientId = TokenController::clientId;

        $assertion = $this->createJwt();
        $postFields = [
            'grant_type' => 'client_credentials',
            'client_assertion_type' => 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
            'client_assertion' => $assertion,
            'scope' => 'iSHARE',
            'client_id' => $clientId,
        ];

        $response = $this->httpClient->request('POST', self::DIGIGO_BASE . '/connect/token', [
            'body' => $postFields,
        ]);
        $statusCode = $response->getStatusCode();
        $data = $response->toArray(false);

        if ($statusCode >= 400 || !isset($data['access_token'])) {
            $details = is_array($data)
                ? ($data['error_description'] ?? $data['error'] ?? json_encode($data))
                : $response->getContent(false);

            throw new \RuntimeException(
                sprintf('Digigo auth failed for client_id "%s": %s', $clientId, (string) $details)
            );
        }

        return (string) $data['access_token'];
    }

    private function createJwt(): string
    {
        $clientId = TokenController::clientId;

        $privateKey = InMemory::file(JwtKeyPaths::PRIVATE_KEY, '');
        $certChain = $this->pemChainToX5cArray(file_get_contents(JwtKeyPaths::CERT_CHAIN));

        $config = Configuration::forAsymmetricSigner(new Sha256(), $privateKey, $privateKey);
        $now = new \DateTimeImmutable(date('Y-m-d H:i:s'));

        return $config->builder()
            ->issuedBy($clientId)
            ->permittedFor(self::DIGIGO_AUDIENCE)
            ->relatedTo($clientId)
            ->issuedAt($now)
            ->canOnlyBeUsedAfter($now)
            ->expiresAt($now->modify('+30 seconds'))
            ->identifiedBy(bin2hex(random_bytes(16)))
            ->withHeader('typ', 'JWT')
            ->withHeader('x5c', $certChain)
            ->getToken($config->signer(), $config->signingKey())
            ->toString();
    }

    private function pemChainToX5cArray(string $pemChain): array
    {
        $certs = [];
        preg_match_all('/-----BEGIN CERTIFICATE-----(.*?)-----END CERTIFICATE-----/s', $pemChain, $matches);
        if (!empty($matches[1])) {
            foreach ($matches[1] as $certPem) {
                $der = base64_decode(trim($certPem));
                $certs[] = base64_encode($der);
            }
        }
        return $certs;
    }
}
