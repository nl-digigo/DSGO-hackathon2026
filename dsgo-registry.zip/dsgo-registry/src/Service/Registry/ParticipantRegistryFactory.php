<?php

declare(strict_types=1);

namespace App\Service\Registry;

/**
 * Returns the appropriate ParticipantRegistry implementation based on
 * PARTICIPANT_REGISTRY_ENABLED: the real Digigo service when enabled,
 * or a pass-through NullParticipantRegistry when disabled.
 */
final class ParticipantRegistryFactory
{
    public function __construct(
        private readonly bool $enabled,
        private readonly ParticipantRegistryService $registryService,
        private readonly NullParticipantRegistry $nullRegistry,
    ) {
    }

    public function create(): ParticipantRegistryInterface
    {
        return $this->enabled ? $this->registryService : $this->nullRegistry;
    }
}
