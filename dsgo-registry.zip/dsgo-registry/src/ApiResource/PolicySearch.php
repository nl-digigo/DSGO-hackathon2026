<?php

declare(strict_types=1);

namespace App\ApiResource;

use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Post;
use App\Dto\SearchRequest;
use App\Dto\SearchResponse;
use App\State\PolicySearchProcessor;

#[ApiResource(
    operations: [
        new Post(
            uriTemplate: '/search',
            inputFormats: ['json' => ['application/json'], 'jsonld' => ['application/ld+json']],
            outputFormats: ['json' => ['application/json']],
            input: SearchRequest::class,
            output: SearchResponse::class,
            processor: PolicySearchProcessor::class,
            openapi: new \ApiPlatform\OpenApi\Model\Operation(
                summary: 'Search for delegation evidence (Policy Retrieval Point)',
                description: 'Retrieves delegation evidence records matching the given issuer, subject, and resource combination. Functions as a Policy Retrieval Point (PRP) per AuthZen.',
                security: [['Bearer' => []]],
            ),
        ),
    ],
    paginationEnabled: false,
)]
final class PolicySearch
{
}
