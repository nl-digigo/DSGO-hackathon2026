<?php

declare(strict_types=1);

namespace App\ApiResource;

use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Get;
use App\State\HealthStatusProvider;

#[ApiResource(
    operations: [
        new Get(
            uriTemplate: '/health',
            outputFormats: ['json' => ['application/json']],
            provider: HealthStatusProvider::class,
            openapi: new \ApiPlatform\OpenApi\Model\Operation(
                summary: 'Health check endpoint.',
                description: 'Returns the service health status. Publicly accessible without authentication.',
                security: [],
            ),
        ),
    ],
    paginationEnabled: false,
)]
final readonly class HealthStatus
{
    public function __construct(
        public string $status,
        public string $service,
        public string $timestamp,
    ) {
    }
}
