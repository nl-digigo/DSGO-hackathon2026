<?php

declare(strict_types=1);

namespace App\ApiResource;

use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Post;
use App\Dto\EvaluationRequest;
use App\Dto\EvaluationResponse;
use App\State\EvaluationProcessor;

#[ApiResource(
    operations: [
        new Post(
            uriTemplate: '/evaluation',
            inputFormats: ['json' => ['application/json'], 'jsonld' => ['application/ld+json']],
            outputFormats: ['json' => ['application/json']],
            input: EvaluationRequest::class,
            output: EvaluationResponse::class,
            processor: EvaluationProcessor::class,
            openapi: new \ApiPlatform\OpenApi\Model\Operation(
                summary: 'Evaluate an authorization request (AuthZen)',
                description: 'Evaluates whether the subject is permitted to perform the action on the resource. Returns a decision (true/false) with optional context for partial authorization or deny reasons.',
                security: [['Bearer' => []]],
            ),
        ),
    ],
    paginationEnabled: false,
)]
final class Evaluation
{
}
