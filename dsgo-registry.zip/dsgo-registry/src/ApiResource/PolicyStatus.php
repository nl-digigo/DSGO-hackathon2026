<?php

declare(strict_types=1);

namespace App\ApiResource;

use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Get;
use App\State\PolicyStatusProvider;

#[ApiResource(
    operations: [
        new Get(
            uriTemplate: '/status',
            outputFormats: ['json' => ['application/json']],
            provider: PolicyStatusProvider::class,
            openapi: new \ApiPlatform\OpenApi\Model\Operation(
                summary: 'Retrieves the policy engine status.',
                description: 'Returns the current status of the Casbin policy engine, including when policies were last loaded.',
                security: [['Bearer' => []]],
            ),
        ),
    ],
    paginationEnabled: false,
)]
final readonly class PolicyStatus
{
    public function __construct(
        public string $status,
        public ?string $policyLoadedAt,
    ) {
    }
}
