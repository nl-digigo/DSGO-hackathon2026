<?php

namespace App\Security;

use App\Controller\TokenController;
use App\Util\JwtKeyPaths;
use Lcobucci\Clock\SystemClock;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Lcobucci\JWT\Validation\Constraint\IssuedBy;
use Lcobucci\JWT\Validation\Constraint\SignedWith;
use Lcobucci\JWT\Validation\Constraint\StrictValidAt;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Http\Authenticator\AbstractAuthenticator;
use Symfony\Component\Security\Core\User\InMemoryUser;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\UserBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Passport;
use Symfony\Component\Security\Http\Authenticator\Passport\SelfValidatingPassport;

final class IshareJWTAuthenticator extends AbstractAuthenticator
{
    public function supports(Request $request): ?bool
    {
        return str_starts_with($request->getPathInfo(), '/api')
            && $request->headers->has('Authorization');
    }

    public function authenticate(Request $request): Passport
    {
        $authHeader = $request->headers->get('Authorization');
        if (! preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
            throw new AuthenticationException('Missing bearer token');
        }

        try {
            $token = $matches[1];
            $privateKey = InMemory::file(JwtKeyPaths::PRIVATE_KEY, '');
            $publicKey = InMemory::file(JwtKeyPaths::CERT_CHAIN, '');
            $config = Configuration::forAsymmetricSigner(new Sha256(), $privateKey, $publicKey );
            $token = $config->parser()->parse($token);

            // Constraints:
            $constraints = [
                new SignedWith($config->signer(), $config->verificationKey()),
                new StrictValidAt(new SystemClock(new \DateTimeZone('europe/amsterdam'))), // checks exp/nbf/iat
                new IssuedBy(TokenController::clientId),     // optional
            ];

            $validator = $config->validator();
            $validator->assert($token, ...$constraints); // token is now authenticated and validated

            $token = $matches[1];
            $parts = explode('.', $token);
            $payload = json_decode(base64_decode($parts[1]), true);
            $clientId = $payload['client_id'];

            return new SelfValidatingPassport(
                new UserBadge($clientId, fn() => new InMemoryUser($clientId, '', ['ROLE_CLIENT']))
            );
        } catch (AuthenticationException $e) {
            throw $e;
        } catch (\Throwable $e) {
            throw new AuthenticationException('Token validation failed');
        }
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, string $firewallName): ?JsonResponse
    {
        return null; // allow request
    }

    public function onAuthenticationFailure(Request $request, AuthenticationException $exception): ?JsonResponse
    {
        return new JsonResponse(['error' => 'invalid_token', 'message' => $exception->getMessage()], 401);
    }
}
