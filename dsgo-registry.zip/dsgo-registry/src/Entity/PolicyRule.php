<?php

declare(strict_types=1);

namespace App\Entity;

use App\Repository\PolicyRuleRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Entity(repositoryClass: PolicyRuleRepository::class)]
#[ORM\Table(name: 'authz_policy_rule')]
#[ORM\Index(columns: ['ptype', 'v0', 'v1', 'v2'], name: 'idx_policy_lookup')]
class PolicyRule
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 10)]
    private string $ptype = 'p';

    /** Subject (EORI identifier) */
    #[ORM\Column(length: 255)]
    #[Assert\NotBlank(message: 'Subject is required')]
    #[Assert\Regex(
        pattern: '/^EU\.EORI\..+$/',
        message: 'Subject must be a valid EORI (e.g., EU.EORI.NL000000001)'
    )]
    private string $v0 = '';

    /** Resource path */
    #[ORM\Column(length: 255)]
    #[Assert\NotBlank(message: 'Resource is required')]
    private string $v1 = '';

    /** Action name */
    #[ORM\Column(length: 50)]
    #[Assert\NotBlank(message: 'Action is required')]
    #[Assert\Choice(
        choices: ['can_access', 'can_create', 'can_read', 'can_update', 'can_delete'],
        message: 'Action must be one of: can_access, can_create, can_read, can_update, can_delete'
    )]
    private string $v2 = '';

    /** Service provider EORI (resource.properties.service_provider) */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $v3 = null;

    /** HTTP method (action.properties.method) */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $v4 = null;

    /** License code (action.properties.license) */
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $v5 = null;

    /** Partial authorization context (identifiers/attributes restrictions) */
    #[ORM\Column(type: 'json', nullable: true)]
    private ?array $partialContext = null;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    #[ORM\Column]
    private \DateTimeImmutable $updatedAt;

    public function __construct()
    {
        $this->createdAt = new \DateTimeImmutable();
        $this->updatedAt = new \DateTimeImmutable();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPtype(): string
    {
        return $this->ptype;
    }

    public function setPtype(string $ptype): static
    {
        $this->ptype = $ptype;
        return $this;
    }

    // --- Casbin raw field accessors (v0–v5) ---

    public function getV0(): string
    {
        return $this->v0;
    }

    public function setV0(string $v0): static
    {
        $this->v0 = $v0;
        $this->updatedAt = new \DateTimeImmutable();
        return $this;
    }

    public function getV1(): string
    {
        return $this->v1;
    }

    public function setV1(string $v1): static
    {
        $this->v1 = $v1;
        $this->updatedAt = new \DateTimeImmutable();
        return $this;
    }

    public function getV2(): string
    {
        return $this->v2;
    }

    public function setV2(string $v2): static
    {
        $this->v2 = $v2;
        $this->updatedAt = new \DateTimeImmutable();
        return $this;
    }

    public function getV3(): ?string
    {
        return $this->v3;
    }

    public function setV3(?string $v3): static
    {
        $this->v3 = $v3;
        return $this;
    }

    public function getV4(): ?string
    {
        return $this->v4;
    }

    public function setV4(?string $v4): static
    {
        $this->v4 = $v4;
        return $this;
    }

    public function getV5(): ?string
    {
        return $this->v5;
    }

    public function setV5(?string $v5): static
    {
        $this->v5 = $v5;
        return $this;
    }

    // --- AuthZen semantic aliases ---

    public function getSubject(): string
    {
        return $this->v0;
    }

    public function setSubject(string $subject): static
    {
        return $this->setV0($subject);
    }

    public function getResource(): string
    {
        return $this->v1;
    }

    public function setResource(string $resource): static
    {
        return $this->setV1($resource);
    }

    public function getAction(): string
    {
        return $this->v2;
    }

    public function setAction(string $action): static
    {
        return $this->setV2($action);
    }

    public function getServiceProvider(): ?string
    {
        return $this->v3;
    }

    public function setServiceProvider(?string $serviceProvider): static
    {
        $this->v3 = $serviceProvider;
        return $this;
    }

    public function getMethod(): ?string
    {
        return $this->v4;
    }

    public function setMethod(?string $method): static
    {
        $this->v4 = $method;
        return $this;
    }

    public function getLicense(): ?string
    {
        return $this->v5;
    }

    public function setLicense(?string $license): static
    {
        $this->v5 = $license;
        return $this;
    }

    public function getPartialContext(): ?array
    {
        return $this->partialContext;
    }

    public function setPartialContext(?array $partialContext): static
    {
        $this->partialContext = $partialContext;
        return $this;
    }

    // --- Timestamps ---

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): \DateTimeImmutable
    {
        return $this->updatedAt;
    }

    // --- Casbin interop ---

    /**
     * @return array<string>
     */
    public function toRuleArray(): array
    {
        $rule = [$this->v0, $this->v1, $this->v2];

        if ($this->v3 !== null) {
            $rule[] = $this->v3;
        }
        if ($this->v4 !== null) {
            $rule[] = $this->v4;
        }
        if ($this->v5 !== null) {
            $rule[] = $this->v5;
        }

        return $rule;
    }

    /**
     * @param array<string> $rule
     */
    public static function fromRuleArray(string $ptype, array $rule): static
    {
        $policy = new static();
        $policy->ptype = $ptype;
        $policy->v0 = $rule[0] ?? '';
        $policy->v1 = $rule[1] ?? '';
        $policy->v2 = $rule[2] ?? '';
        $policy->v3 = $rule[3] ?? null;
        $policy->v4 = $rule[4] ?? null;
        $policy->v5 = $rule[5] ?? null;

        return $policy;
    }
}
