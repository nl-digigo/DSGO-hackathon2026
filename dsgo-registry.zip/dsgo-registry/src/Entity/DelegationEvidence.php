<?php

declare(strict_types=1);

namespace App\Entity;

use App\Repository\DelegationEvidenceRepository;
use Doctrine\ORM\Mapping as ORM;
use Ramsey\Uuid\Uuid;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Entity(repositoryClass: DelegationEvidenceRepository::class)]
#[ORM\Table(name: 'delegation_evidence')]
#[ORM\Index(columns: ['issuer_id', 'subject_id'], name: 'idx_delegation_issuer_subject')]
#[ORM\Index(columns: ['resource_id', 'action_name'], name: 'idx_delegation_resource_action')]
class DelegationEvidence
{
    #[ORM\Id]
    #[ORM\Column(type: 'string', length: 36)]
    private string $id;

    #[ORM\ManyToOne(targetEntity: self::class)]
    #[ORM\JoinColumn(name: 'parent_id', referencedColumnName: 'id', nullable: true, onDelete: 'SET NULL')]
    private ?self $parent = null;

    #[ORM\Column(length: 50)]
    #[Assert\NotBlank]
    private string $issuerType = '';

    #[ORM\Column(length: 255)]
    #[Assert\NotBlank]
    #[Assert\Regex(pattern: '/^EU\.EORI\..+$/', message: 'Must be a valid EORI')]
    private string $issuerId = '';

    #[ORM\Column(length: 50)]
    #[Assert\NotBlank]
    private string $subjectType = '';

    #[ORM\Column(length: 255)]
    #[Assert\NotBlank]
    #[Assert\Regex(pattern: '/^EU\.EORI\..+$/', message: 'Must be a valid EORI')]
    private string $subjectId = '';

    #[ORM\Column(length: 50)]
    #[Assert\NotBlank]
    private string $resourceType = '';

    #[ORM\Column(length: 255)]
    #[Assert\NotBlank]
    private string $resourceId = '';

    #[ORM\Column(type: 'json', nullable: true)]
    private ?array $resourceProperties = null;

    #[ORM\Column(length: 50)]
    #[Assert\NotBlank]
    private string $actionName = '';

    #[ORM\Column(type: 'json', nullable: true)]
    private ?array $actionProperties = null;

    #[ORM\Column(length: 500, nullable: true)]
    private ?string $contextUrl = null;

    #[ORM\Column]
    private \DateTimeImmutable $createdAt;

    public function __construct()
    {
        $this->id = Uuid::uuid4()->toString();
        $this->createdAt = new \DateTimeImmutable();
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getParent(): ?self
    {
        return $this->parent;
    }

    public function setParent(?self $parent): static
    {
        $this->parent = $parent;
        return $this;
    }

    public function getIssuerType(): string
    {
        return $this->issuerType;
    }

    public function setIssuerType(string $issuerType): static
    {
        $this->issuerType = $issuerType;
        return $this;
    }

    public function getIssuerId(): string
    {
        return $this->issuerId;
    }

    public function setIssuerId(string $issuerId): static
    {
        $this->issuerId = $issuerId;
        return $this;
    }

    public function getSubjectType(): string
    {
        return $this->subjectType;
    }

    public function setSubjectType(string $subjectType): static
    {
        $this->subjectType = $subjectType;
        return $this;
    }

    public function getSubjectId(): string
    {
        return $this->subjectId;
    }

    public function setSubjectId(string $subjectId): static
    {
        $this->subjectId = $subjectId;
        return $this;
    }

    public function getResourceType(): string
    {
        return $this->resourceType;
    }

    public function setResourceType(string $resourceType): static
    {
        $this->resourceType = $resourceType;
        return $this;
    }

    public function getResourceId(): string
    {
        return $this->resourceId;
    }

    public function setResourceId(string $resourceId): static
    {
        $this->resourceId = $resourceId;
        return $this;
    }

    public function getResourceProperties(): ?array
    {
        return $this->resourceProperties;
    }

    public function setResourceProperties(?array $resourceProperties): static
    {
        $this->resourceProperties = $resourceProperties;
        return $this;
    }

    public function getActionName(): string
    {
        return $this->actionName;
    }

    public function setActionName(string $actionName): static
    {
        $this->actionName = $actionName;
        return $this;
    }

    public function getActionProperties(): ?array
    {
        return $this->actionProperties;
    }

    public function setActionProperties(?array $actionProperties): static
    {
        $this->actionProperties = $actionProperties;
        return $this;
    }

    public function getContextUrl(): ?string
    {
        return $this->contextUrl;
    }

    public function setContextUrl(?string $contextUrl): static
    {
        $this->contextUrl = $contextUrl;
        return $this;
    }

    public function getCreatedAt(): \DateTimeImmutable
    {
        return $this->createdAt;
    }

    /**
     * Convert to the AuthZen delegation_evidence response format.
     *
     * @return array<string, mixed>
     */
    public function toAuthZenFormat(): array
    {
        $evidence = [
            'issuer' => [
                'type' => $this->issuerType,
                'id' => $this->issuerId,
            ],
            'subject' => [
                'type' => $this->subjectType,
                'id' => $this->subjectId,
            ],
            'resource' => [
                'type' => $this->resourceType,
                'id' => $this->resourceId,
            ],
            'action' => [
                'name' => $this->actionName,
            ],
        ];

        if ($this->resourceProperties !== null) {
            $evidence['resource']['properties'] = $this->resourceProperties;
        }

        if ($this->actionProperties !== null) {
            $evidence['action']['properties'] = $this->actionProperties;
        }

        if ($this->contextUrl !== null) {
            $evidence['context'] = ['url' => $this->contextUrl];
        }

        return $evidence;
    }
}
