<?php

declare(strict_types=1);

namespace App\Evidence;

use App\Dto\EvaluationRequest;
use App\Dto\EvaluationResponse;

/**
 * Canonical representation of an authorization decision for non-repudiation.
 * This payload can be hashed/signed for evidence purposes.
 */
final readonly class CanonicalDecisionPayload
{
    public function __construct(
        public string $correlationId,
        public string $timestamp,
        public string $subjectId,
        public string $resourceId,
        public string $actionName,
        public string $decision,
        public ?array $partialContext,
        public ?string $delegationIssuer,
    ) {
    }

    public static function fromEvaluation(
        EvaluationRequest $request,
        EvaluationResponse $response,
        ?string $correlationId = null,
    ): self {
        $delegationIssuer = null;
        if ($request->subject->properties !== null && isset($request->subject->properties['delegation'])) {
            $delegationIssuer = $request->subject->properties['delegation']['issuer']['id'] ?? null;
        }

        $partialContext = null;
        if ($response->decision && $response->context !== null && isset($response->context['resource'])) {
            $partialContext = $response->context['resource']['properties'] ?? null;
        }

        return new self(
            correlationId: $correlationId ?? '',
            timestamp: (new \DateTimeImmutable())->format(\DateTimeInterface::ATOM),
            subjectId: $request->subject->id,
            resourceId: $request->resource->id,
            actionName: $request->action->name,
            decision: $response->decision ? 'permit' : 'deny',
            partialContext: $partialContext,
            delegationIssuer: $delegationIssuer,
        );
    }

    public function toCanonicalJson(): string
    {
        return json_encode([
            'action_name' => $this->actionName,
            'correlation_id' => $this->correlationId,
            'decision' => $this->decision,
            'delegation_issuer' => $this->delegationIssuer,
            'partial_context' => $this->partialContext,
            'resource_id' => $this->resourceId,
            'subject_id' => $this->subjectId,
            'timestamp' => $this->timestamp,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    public function getHash(): string
    {
        return hash('sha256', $this->toCanonicalJson());
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'correlationId' => $this->correlationId,
            'timestamp' => $this->timestamp,
            'subjectId' => $this->subjectId,
            'resourceId' => $this->resourceId,
            'actionName' => $this->actionName,
            'decision' => $this->decision,
            'partialContext' => $this->partialContext,
            'delegationIssuer' => $this->delegationIssuer,
        ];
    }
}
