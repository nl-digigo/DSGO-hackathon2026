<?php

declare(strict_types=1);

namespace App\Evidence;

/**
 * Interface for recording authorization decision evidence.
 * 
 * Implementations can store evidence for non-repudiation purposes,
 * such as hashing, signing, and storing in append-only storage.
 */
interface EvidenceRecorderInterface
{
    /**
     * Record an authorization decision as evidence.
     */
    public function record(CanonicalDecisionPayload $payload): void;
}
