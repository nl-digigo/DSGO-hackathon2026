<?php

declare(strict_types=1);

namespace App\Evidence;

/**
 * No-op implementation of EvidenceRecorderInterface.
 * 
 * Used for PoC - does not actually record any evidence.
 * In production, replace with an implementation that:
 * - Hashes the canonical payload (SHA-256)
 * - Signs the hash (RSA/ECDSA)
 * - Stores in append-only storage (WORM)
 */
final class NullEvidenceRecorder implements EvidenceRecorderInterface
{
    public function record(CanonicalDecisionPayload $payload): void
    {
        // Intentionally empty - no-op for PoC
        // Future implementation could:
        // - $payload->toCanonicalJson()
        // - $payload->getHash()
        // - Sign and store
    }
}
