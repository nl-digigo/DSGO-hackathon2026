<?php

declare(strict_types=1);

namespace App\Form;

use App\Entity\DelegationEvidence;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class DelegationEvidenceType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('issuerType', TextType::class, [
                'label' => 'Issuer Type',
                'attr' => ['placeholder' => 'service-consumer', 'class' => 'form-input'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('issuerId', TextType::class, [
                'label' => 'Issuer EORI',
                'attr' => ['placeholder' => 'EU.EORI.NL000000001', 'class' => 'form-input'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('subjectType', TextType::class, [
                'label' => 'Subject Type',
                'attr' => ['placeholder' => 'service-consumer', 'class' => 'form-input'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('subjectId', TextType::class, [
                'label' => 'Subject EORI',
                'attr' => ['placeholder' => 'EU.EORI.NL000000003', 'class' => 'form-input'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('resourceType', TextType::class, [
                'label' => 'Resource Type',
                'attr' => ['placeholder' => 'api', 'class' => 'form-input'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('resourceId', TextType::class, [
                'label' => 'Resource ID',
                'attr' => ['placeholder' => '/products', 'class' => 'form-input'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('actionName', ChoiceType::class, [
                'label' => 'Action',
                'choices' => [
                    'can_access' => 'can_access',
                    'can_create' => 'can_create',
                    'can_read' => 'can_read',
                    'can_update' => 'can_update',
                    'can_delete' => 'can_delete',
                ],
                'attr' => ['class' => 'form-select'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('contextUrl', TextType::class, [
                'label' => 'Evidence URL',
                'required' => false,
                'attr' => ['placeholder' => 'https://api.example.com/delegations/{id}', 'class' => 'form-input'],
                'row_attr' => ['class' => 'form-row'],
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => DelegationEvidence::class,
        ]);
    }
}
