<?php

declare(strict_types=1);

namespace App\Form;

use App\Entity\PolicyRule;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PolicyRuleType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('v0', TextType::class, [
                'label' => 'Subject (EORI)',
                'help' => 'EORI identifier, bijv: EU.EORI.NL000000001',
                'attr' => [
                    'placeholder' => 'EU.EORI.NL000000001',
                    'class' => 'form-input',
                ],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('v1', TextType::class, [
                'label' => 'Resource',
                'help' => 'API endpoint pad, bijv: /products of /products/* (wildcard)',
                'attr' => [
                    'placeholder' => '/products',
                    'class' => 'form-input',
                ],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('v2', ChoiceType::class, [
                'label' => 'Action',
                'help' => 'AuthZen actie',
                'choices' => [
                    'can_access - Algemene toegang' => 'can_access',
                    'can_create - Aanmaken' => 'can_create',
                    'can_read - Lezen' => 'can_read',
                    'can_update - Bijwerken' => 'can_update',
                    'can_delete - Verwijderen' => 'can_delete',
                ],
                'attr' => ['class' => 'form-select'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('v3', TextType::class, [
                'label' => 'Service Provider (EORI)',
                'required' => false,
                'help' => 'EORI van de datadienstaanbieder, bijv: EU.EORI.NL000000002. * = wildcard.',
                'attr' => [
                    'placeholder' => 'EU.EORI.NL000000002',
                    'class' => 'form-input',
                ],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('v4', ChoiceType::class, [
                'label' => 'HTTP Method',
                'required' => false,
                'help' => 'REST methode. Leeg = alle methodes.',
                'choices' => [
                    '(alle)' => null,
                    'GET' => 'GET',
                    'POST' => 'POST',
                    'PUT' => 'PUT',
                    'PATCH' => 'PATCH',
                    'DELETE' => 'DELETE',
                    '* (wildcard)' => '*',
                ],
                'attr' => ['class' => 'form-select'],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('v5', TextType::class, [
                'label' => 'License',
                'required' => false,
                'help' => 'Licentiecode, bijv: DSGO.0001. * = wildcard.',
                'attr' => [
                    'placeholder' => 'DSGO.0001',
                    'class' => 'form-input',
                ],
                'row_attr' => ['class' => 'form-row'],
            ])
            ->add('partialContext', TextareaType::class, [
                'label' => 'Partial Authorization (JSON)',
                'required' => false,
                'help' => 'JSON met identifiers/attributes restricties, bijv: {"identifiers": ["PRODUCT001"], "attributes": ["PRODUCT.WEIGHT"]}',
                'attr' => [
                    'placeholder' => '{"identifiers": [], "attributes": []}',
                    'class' => 'form-input font-mono text-sm',
                    'rows' => 3,
                ],
                'row_attr' => ['class' => 'form-row'],
                'getter' => function (PolicyRule $policy): ?string {
                    $ctx = $policy->getPartialContext();
                    return $ctx !== null ? json_encode($ctx, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) : null;
                },
                'setter' => function (PolicyRule &$policy, ?string $value): void {
                    if ($value === null || trim($value) === '') {
                        $policy->setPartialContext(null);
                        return;
                    }
                    $decoded = json_decode($value, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $policy->setPartialContext($decoded);
                    }
                },
            ]);

        $builder->addEventListener(FormEvents::POST_SUBMIT, function (FormEvent $event): void {
            $form = $event->getForm();
            $jsonField = $form->get('partialContext');
            $value = $jsonField->getData();
            if ($value !== null && trim($value) !== '') {
                json_decode($value, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $jsonField->addError(new FormError('Ongeldige JSON: ' . json_last_error_msg()));
                }
            }
        });
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => PolicyRule::class,
        ]);
    }
}
