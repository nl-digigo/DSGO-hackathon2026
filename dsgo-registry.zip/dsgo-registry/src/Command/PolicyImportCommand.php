<?php

declare(strict_types=1);

namespace App\Command;

use App\Entity\PolicyRule;
use App\Service\Casbin\EnforcerFactory;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'dsgo:policy:import',
    description: 'Import policies from a CSV or JSON file',
)]
class PolicyImportCommand extends Command
{
    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly EnforcerFactory $enforcerFactory,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('file', InputArgument::REQUIRED, 'Path to the CSV or JSON file')
            ->addOption('format', 'f', InputOption::VALUE_REQUIRED, 'File format (csv or json)', 'csv')
            ->addOption('clear', null, InputOption::VALUE_NONE, 'Clear existing policies before import')
            ->addOption('dry-run', null, InputOption::VALUE_NONE, 'Show what would be imported without making changes');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        $file = $input->getArgument('file');
        $format = $input->getOption('format');
        $clear = $input->getOption('clear');
        $dryRun = $input->getOption('dry-run');

        if (!file_exists($file)) {
            $io->error(sprintf('File not found: %s', $file));
            return Command::FAILURE;
        }

        $io->title('DSGO Policy Import');

        try {
            $policies = match ($format) {
                'csv' => $this->readCsv($file),
                'json' => $this->readJson($file),
                default => throw new \InvalidArgumentException("Unknown format: $format"),
            };
        } catch (\Exception $e) {
            $io->error(sprintf('Failed to read file: %s', $e->getMessage()));
            return Command::FAILURE;
        }

        if (empty($policies)) {
            $io->warning('No policies found in file');
            return Command::SUCCESS;
        }

        $io->text(sprintf('Found %d policies', count($policies)));
        $io->table(
            ['Subject', 'Resource', 'Action', 'Service Provider', 'Method', 'License'],
            array_map(fn ($p) => [
                $p['subject'], $p['resource'], $p['action'],
                $p['service_provider'] ?? '-', $p['method'] ?? '-', $p['license'] ?? '-',
            ], $policies)
        );

        if ($dryRun) {
            $io->note('Dry run - no changes made');
            return Command::SUCCESS;
        }

        if ($clear) {
            $deleted = $this->entityManager->createQuery('DELETE FROM App\Entity\PolicyRule')->execute();
            $io->text(sprintf('Cleared %d existing policies', $deleted));
        }

        $imported = 0;
        foreach ($policies as $policy) {
            $entity = new PolicyRule();
            $entity->setV0($policy['subject']);
            $entity->setV1($policy['resource']);
            $entity->setV2($policy['action']);
            $entity->setV3($policy['service_provider'] ?? null);
            $entity->setV4($policy['method'] ?? null);
            $entity->setV5($policy['license'] ?? null);

            if (isset($policy['partial_context'])) {
                $entity->setPartialContext($policy['partial_context']);
            }

            $this->entityManager->persist($entity);
            $imported++;
        }

        $this->entityManager->flush();
        $this->enforcerFactory->forceRefresh();

        $io->success(sprintf('Imported %d policies', $imported));

        return Command::SUCCESS;
    }

    /**
     * CSV format: subject,resource,action,service_provider,method,license
     *
     * @return array<array<string, mixed>>
     */
    private function readCsv(string $file): array
    {
        $policies = [];
        $handle = fopen($file, 'r');

        if ($handle === false) {
            throw new \RuntimeException("Cannot open file: $file");
        }

        $lineNumber = 0;
        while (($row = fgetcsv($handle)) !== false) {
            $lineNumber++;

            if (empty($row) || (count($row) === 1 && $row[0] === '')) {
                continue;
            }

            if ($lineNumber === 1 && in_array(strtolower(trim($row[0])), ['subject', 'p', 'ptype'], true)) {
                continue;
            }

            $offset = 0;
            if (count($row) >= 4 && trim($row[0]) === 'p') {
                $offset = 1;
            }

            if (count($row) >= $offset + 3) {
                $policies[] = [
                    'subject' => trim($row[$offset]),
                    'resource' => trim($row[$offset + 1]),
                    'action' => trim($row[$offset + 2]),
                    'service_provider' => isset($row[$offset + 3]) && trim($row[$offset + 3]) !== '' ? trim($row[$offset + 3]) : null,
                    'method' => isset($row[$offset + 4]) && trim($row[$offset + 4]) !== '' ? trim($row[$offset + 4]) : null,
                    'license' => isset($row[$offset + 5]) && trim($row[$offset + 5]) !== '' ? trim($row[$offset + 5]) : null,
                ];
            }
        }

        fclose($handle);

        return $policies;
    }

    /**
     * @return array<array<string, mixed>>
     */
    private function readJson(string $file): array
    {
        $content = file_get_contents($file);

        if ($content === false) {
            throw new \RuntimeException("Cannot read file: $file");
        }

        $data = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException('Invalid JSON: ' . json_last_error_msg());
        }

        if (!is_array($data)) {
            throw new \RuntimeException('JSON must be an array of policies');
        }

        $policies = [];
        foreach ($data as $item) {
            if (!isset($item['subject'], $item['resource'], $item['action'])) {
                continue;
            }

            $policies[] = [
                'subject' => $item['subject'],
                'resource' => $item['resource'],
                'action' => $item['action'],
                'service_provider' => $item['service_provider'] ?? null,
                'method' => $item['method'] ?? null,
                'license' => $item['license'] ?? null,
                'partial_context' => $item['partial_context'] ?? null,
            ];
        }

        return $policies;
    }
}
