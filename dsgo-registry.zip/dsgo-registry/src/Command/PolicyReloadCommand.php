<?php

declare(strict_types=1);

namespace App\Command;

use App\Service\Casbin\EnforcerFactory;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'dsgo:policy:reload',
    description: 'Force reload of policies from database',
)]
class PolicyReloadCommand extends Command
{
    public function __construct(
        private readonly EnforcerFactory $enforcerFactory,
    ) {
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        $io->title('DSGO Policy Reload');

        $this->enforcerFactory->forceRefresh();
        $this->enforcerFactory->getEnforcer();
        
        $loadedAt = $this->enforcerFactory->getLoadedAt();

        $io->success(sprintf(
            'Policies reloaded at %s',
            $loadedAt?->format('Y-m-d H:i:s') ?? 'unknown'
        ));

        return Command::SUCCESS;
    }
}
