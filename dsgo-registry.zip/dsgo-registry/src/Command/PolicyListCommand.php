<?php

declare(strict_types=1);

namespace App\Command;

use App\Repository\PolicyRuleRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'dsgo:policy:list',
    description: 'List all policies',
)]
class PolicyListCommand extends Command
{
    public function __construct(
        private readonly PolicyRuleRepository $repository,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('subject', 's', InputOption::VALUE_REQUIRED, 'Filter by subject')
            ->addOption('format', 'f', InputOption::VALUE_REQUIRED, 'Output format (table, csv, json)', 'table');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        
        $subject = $input->getOption('subject');
        $format = $input->getOption('format');

        // Get policies
        if ($subject) {
            $policies = $this->repository->findBySubject($subject);
        } else {
            $policies = $this->repository->findAll();
        }

        if (empty($policies)) {
            $io->note('No policies found');
            return Command::SUCCESS;
        }

        $rows = array_map(fn($p) => [
            $p->getSubject(),
            $p->getResource(),
            $p->getAction(),
            $p->getServiceProvider() ?? '-',
            $p->getMethod() ?? '-',
            $p->getLicense() ?? '-',
        ], $policies);

        switch ($format) {
            case 'csv':
                $output->writeln('subject,resource,action,service_provider,method,license');
                foreach ($rows as $row) {
                    $output->writeln(implode(',', $row));
                }
                break;

            case 'json':
                $data = array_map(function ($p) {
                    $item = [
                        'subject' => $p->getSubject(),
                        'resource' => $p->getResource(),
                        'action' => $p->getAction(),
                        'service_provider' => $p->getServiceProvider(),
                        'method' => $p->getMethod(),
                        'license' => $p->getLicense(),
                    ];
                    if ($p->getPartialContext() !== null) {
                        $item['partial_context'] = $p->getPartialContext();
                    }
                    return $item;
                }, $policies);
                $output->writeln(json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                break;

            case 'table':
            default:
                $io->title('DSGO Policies');
                $io->table(
                    ['Subject', 'Resource', 'Action', 'Provider', 'Method', 'License'],
                    $rows,
                );
                $io->text(sprintf('Total: %d policies', count($policies)));
                break;
        }

        return Command::SUCCESS;
    }
}
